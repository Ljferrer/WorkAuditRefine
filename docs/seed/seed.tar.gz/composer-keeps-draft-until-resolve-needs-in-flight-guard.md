---
name: composer-keeps-draft-until-resolve-needs-in-flight-guard
description: A composer that clears its draft only after the write resolves sends twice on a double tap unless it guards the pending post.
metadata:
  node_type: memory
  type: project
  keywords:
    - double tap
    - double submit
    - duplicate post
    - in-flight guard
    - posting state
    - keep draft on reject
    - composer
    - post promise
  provenance: code-verified
  slug: composer-keeps-draft-until-resolve-needs-in-flight-guard
  tags:
    - screens
    - react
    - pattern
  created: 2026-10-27
---

# Keep-the-draft-on-failure reopens the double-send window

## The pattern
- At first, `submit` cleared the draft at once. A second press saw blank text and returned.
- The post callback then changed to return the write's promise. The composer now keeps the draft until the promise resolves, so a failed post leaves the text in place.
- Between the press and the resolve, the draft is still full. A second press posts the same text again, and the thread gets two messages.
- A networked backend with real latency makes that window easy to hit. A mock that resolves fast hides it.

## The fix
- The composer holds a `posting` state. `submit` returns early when `posting` is true or the text is blank, sets `posting` before the await, and clears it in `finally`. The Post button gets `disabled={posting}`.
- A test presses Post twice on a deferred promise and expects one post call.

## Reuse
Apply the same guard to any control that keeps its input until an async write resolves. Add the two-press test with a deferred promise, since an instant fake never shows the window.
