---
name: a-bug-in-a-fail-open-step-degrades-to-silence-so-rate-it-by-its-failure-route
description: "A defect inside an error-suppressed fail-open step degrades to silent inaction, so rate it by where the failure routes, not by the defect alone"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - fail-open
    - severity
    - blast radius
    - silent no-op
    - review triage
    - error suppression
  slug: a-bug-in-a-fail-open-step-degrades-to-silence-so-rate-it-by-its-failure-route
  tags:
    - hook-design
    - fail-open
    - review
---

# Rate a bug in a fail-open step by its failure route

**Rule.** Downgrade the severity only when the broken step's failure is already handled and the result is no action. If a broken split routes through a command whose stderr is suppressed and whose failure is handled (the loop finds nothing, the script exits 0), the defect degrades to silent inaction. That can be acceptable for a fail-open hook or guard whose contract is "harmless". It still loses "should have acted".

**Escalate** when the same pattern feeds a command whose failure is not handled: one that aborts, corrupts, or silently substitutes wrong data. The bounding logic does not carry over to fail-closed or side-effecting code.

**Why:** a hook that is silent and harmless in the normal case can fail in a way that only looks like the normal case. The defect's cost is set by what the failure does next.

**How to apply:** before you flag a finding as blocking, trace where the broken step's failure goes. If it ends in a handled no-op, record it as a note. If it feeds a fail-closed or side-effecting step, fix it.
