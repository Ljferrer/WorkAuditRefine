---
name: submodule-helper-param-removal-breaks-superproject-consumer-test
description: A sweep for callers of a shared-library helper that covers only the library missed a superproject test passing the removed parameter, so the submodule bump broke it
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  slug: submodule-helper-param-removal-breaks-superproject-consumer-test
  keywords:
    - sibling sweep
    - private helper
    - dead parameter
    - consumer test
    - submodule bump
    - TypeError unexpected keyword
    - cross-repo impact
  tags:
    - submodule
    - refactoring
    - cascading-impact
    - testing
---

An automated cleanup commit removed a parameter from a private helper in a shared-library submodule. A review had called the parameter dead code.

The commit's search for other callers covered the submodule only. It found no test that names the helper.

A test in the superproject, the repo that pins the submodule, called the helper with that parameter. After the submodule bump the call would raise `TypeError` for an unexpected keyword. A review seat caught this before merge.

**Why it bites.** The submodule's own tests stay green. The break appears only in the superproject, and only once the submodule pointer moves.

**How to apply.** Before removing or renaming any parameter of a shared-library helper, grep the superproject `tests/` and handlers as well as the submodule. This includes underscore-prefixed helpers. A submodule-only search proves nothing about superproject callers.

An "unused in this module" parameter can still be the contract that a superproject test pins. Keep the parameter until the bump deletes or re-pins that test on purpose. If the superproject test must change, land the test change in the same commit as the pointer bump.

A forward revert of the cleanup is a valid fix when the parameter has no cost to keep.
