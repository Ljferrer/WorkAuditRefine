---
name: node-cli-main-guard-must-realpath-argv1-or-symlink-invocation-skips-main
description: "A bare-equality Node ESM run-as-CLI guard silently no-ops under symlink invocation, so realpath argv[1] before comparing"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - fileURLToPath import.meta.url
    - process.argv[1]
    - node CLI main guard
    - run as CLI only when invoked directly
    - silent no-op
    - ESM entry point check
    - symlink invocation
    - realpathSync
    - percent-encodable path
  slug: node-cli-main-guard-must-realpath-argv1-or-symlink-invocation-skips-main
  tags:
    - node
    - cli
    - footgun
    - fail-loud
---

The bare-equality guard `fileURLToPath(import.meta.url) === process.argv[1]` silently no-ops under **symlink invocation**. The module loader realpaths the main module for `import.meta.url`, while `process.argv[1]` keeps the symlink path the caller typed. The comparison is false, `main()` is never called, and the process exits 0 having done nothing.

Relative invocation is not the trigger: on Node 24, `process.argv[1]` arrives pre-resolved to an absolute path. A second trigger is a percent-encodable checkout path, but only for the string-concat variant `` file://${process.argv[1]} ``: string concatenation never percent-encodes, while `import.meta.url` does.

**The canonical idiom:** normalize the argv side.

```js
if (process.argv[1] && fileURLToPath(import.meta.url) === fs.realpathSync(process.argv[1])) main()
```

**Why:** this is the standard Node ESM "run as CLI only when invoked directly" idiom and it is routinely copy-pasted in its bare-equality form. Any new CLI that does so inherits the silent no-op.

**How to apply:**
- Use the `realpathSync`-both-sides form from the start.
- Lock it with a symlink-invocation regression test: symlink the CLI into a `mkdtempSync` scratch dir, spawn the symlink, assert a non-zero exit and the live `usage:` line.
