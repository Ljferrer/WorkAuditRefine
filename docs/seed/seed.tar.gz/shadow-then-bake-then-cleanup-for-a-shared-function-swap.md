---
name: shadow-then-bake-then-cleanup-for-a-shared-function-swap
description: A per-site swap to a new shared function goes shadow, then bake, then cleanup; gate the bake on a log MetricFilter
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - shadow mode
    - bake gate
    - MetricFilter
    - mismatch metric
    - incremental rollout
    - CloudWatch alarm
  slug: shadow-then-bake-then-cleanup-for-a-shared-function-swap
---

A migration swapped a legacy parse for a new shared function (`<new_func>`) at several call sites, one site at a time. The same shadow, bake and cleanup recipe repeats at each site.

**The shadow step.** Each site first lands an inert call. `<new_func>` runs beside the legacy parse and only logs a warning with a fixed token (`<MISMATCH_TOKEN>`) when its result differs from the legacy result. The shadow must not change behavior:
- If the shadow is not wrapped in try/except, its inertness rests on the new function's "never raises" contract. If a dependency pin ever breaks that contract, the shadow crashes the handler. To defend it, wrap the call and log a separate `<SHADOW_ERROR_TOKEN>`.
- Keep the shadow log line free of sensitive data (item key and flag only), and bound it to one line per mismatching item.

**The bake gate is infra, not code.** Gate promotion on a CloudWatch Logs `MetricFilter` that matches the literal mismatch token on the handler's log group, feeding an `Alarm`:
- Use threshold 0 with `GREATER_THAN_THRESHOLD`, and treat missing data as `NOT_BREACHING` so the alarm does not fire on no data. A one-hour period keeps it human-paced.
- Keep the metric static and dimension-less (`metric_value='1'`) to limit cardinality.
- Deploy the MetricFilter before any site starts its bake. Otherwise a mismatch shows up only as raw log lines, not as the alarm the rollout relies on.
- If the same construct builder runs twice in one stack, two filters on two log groups publish to one shared static metric. That is redundant but harmless, and it gives the correct aggregate gate.
