---
name: never-raises-fixture-runner-needs-degraded-sentinel
description: a never-raises fixture entrypoint needs a degraded sentinel for a partial parse failure
metadata:
  node_type: memory
  type: project
  keywords:
    - never-raises
    - degraded sentinel
    - parse failure
    - offline fixture run
    - exit code
    - OK token
    - silent fallback
  provenance: code-verified
  slug: never-raises-fixture-runner-needs-degraded-sentinel
  tags:
    - testing
    - fixture
    - pattern
---

A host-run fixture tool (`<tools>/<run_fixture>.py`) parsed each fixture page's OCR output the same way the production handler does.

Before the fix, a parse exception on a non-blank page set the parsed object to `None`. The tool still printed `FIXTURE_RUN_OK` and returned exit 0. A page could silently fall back to an empty result with no signal to the caller.

The fix adds a `FIXTURE_RUN_DEGRADED` token and a `degraded` list of page keys. `run()` returns `(page_count, degraded)`. `main()` prints `FIXTURE_RUN_DEGRADED pages=<keys>` and returns a non-zero exit when any non-blank page failed to parse, instead of the OK token.

**How to apply.** A fixture or comparison entrypoint that must never raise, so one bad item cannot crash the whole sweep, still needs a degraded or non-zero-exit path for an item-level failure. A caller who ignores the exit code and diffs two output directories anyway can still score a false match on two empty results. The non-zero exit and the DEGRADED token are the intended stop. They are not a guarantee against every downstream misuse.
