---
name: fix-the-finding-class-not-the-site
description: "Treat a review finding's fix text as a floor: sweep every sibling site of the same rule, bind restated values with a pin, and extract on the second copy, or the next review round finds the mirror case"
metadata:
  node_type: memory
  type: project
  provenance: user-confirmed
  keywords:
    - finding class not site
    - sibling sweep
    - fix text is a floor
    - mirror case
    - restated value pin
    - extract on the second copy
    - count words in comments
    - consequence line
    - review round count
  slug: fix-the-finding-class-not-the-site
  tags:
    - review-discipline
    - drift-guard
    - doc-truth
---

## The rule

A reviewer's fix text names one site. The defect is a rule that was applied at that site and missed elsewhere. Fix the rule everywhere it applies, or the next review round finds the mirror case. Before each commit of a review-driven fix, run this checklist:

1. **Sibling sweep.** Grep for every other site that carries the same construct: the same registry, the same push, the same judgment, the same restated value, the same claim in a doc or a comment. Apply the rule there too, or write in the commit why that site differs.
2. **The fix text is a floor.** Ask what the reviewer did not check: the other arm, the other order, the empty input, the boundary value (`>` against `>=`), the path with a flag the reviewer's example did not pass. Add the mirror fixture.
3. **Bind or de-mirror every restated value.** A number or a tier written by hand into prose rots silently. Either pin it (extract the restatement and compare it to the constant, and ban a bare rendering outside the pinned grammar) or replace it with a pointer to its source.
4. **Extract on the second copy.** If a fix creates a second hand copy of a rule or a scanner, move it into one helper in the same commit and migrate both callers. The fourth copy is three review rounds too late.
5. **No count words the diff can invalidate.** Never write "two", "both", "the fourth" in a comment or census header that the same change can make false. Name the members.
6. **One consequence line per commit.** State what else the change touches and why that is unaffected. It forces the sweep the fixer otherwise skips.

The reviewer's fix scopes the site. The rule scopes the diff.

**Why:** a fix applied only at the named site leaves the same defect at its siblings, and each one costs another review round.

**How to apply:** before you commit a review-driven fix, run the checklist above and name the swept sites in the commit body.
