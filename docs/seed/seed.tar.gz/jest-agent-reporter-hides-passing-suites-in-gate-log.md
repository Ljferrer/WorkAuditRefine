---
name: jest-agent-reporter-hides-passing-suites-in-gate-log
description: "From Jest 30, a failures-only agent reporter replaces the default under AI-agent env vars, so a log lists no passing suite paths unless the reporter is pinned."
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - jest 30
    - agent reporter
    - AgentReporter
    - AI_AGENT
    - reporters=default
    - per-file paths
    - execution evidence
  slug: jest-agent-reporter-hides-passing-suites-in-gate-log
  tags:
    - jest
    - test-runner
    - audit-evidence
---

# Jest prints no passing suite paths when it runs inside an AI agent

**Symptom.**
- A test step's logs end with `Test Suites: N passed, N total` and list no file paths.
- A reviewer's grep for a mapped test path finds nothing, so the run cannot be confirmed per file.
- Reviewers fall back to the aggregate count, which is soft evidence.

**Cause.**
- From Jest 30, `@jest/core` checks the env vars `AI_AGENT` and several more (`AGENT_ENV_VARS` in `@jest/core/build/index.js`). If one is set and no `reporters` option is given, it adds the `agent` reporter in place of `default`.
- `AgentReporter` (in `@jest/reporters/build/index.js`) prints a file header only when `numFailingTests > 0` or the file has an exec error.
- So a green run lists no suite path. A step that runs inside an agent hits this every time.

**Fix.** Pin the reporter in the step: `jest --ci --reporters=default`.
If `jest.config.js` pins no reporter, a bare `npx jest` still gets the agent reporter.

**Why:** a log that feeds an audit must show per-file evidence, and the agent reporter drops it for passing suites.

**How to apply:** any new test runner step whose log feeds an audit should print every suite path, pass or fail.
