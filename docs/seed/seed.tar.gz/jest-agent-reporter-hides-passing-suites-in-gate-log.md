---
name: jest-agent-reporter-hides-passing-suites-in-gate-log
description: "Jest 30 swaps in a failures-only agent reporter under AI-agent env vars, so a gate log lists no passing suite paths unless the reporter is pinned."
metadata:
  node_type: memory
  type: project
  keywords:
    - jest 30
    - agent reporter
    - AgentReporter
    - CLAUDECODE
    - reporters=default
    - gate log
    - per-file paths
    - execution evidence
  provenance: code-verified
  slug: jest-agent-reporter-hides-passing-suites-in-gate-log
  tags:
    - gate
    - jest
    - audit-evidence
  created: 2026-10-27
---

# Jest prints no passing suite paths when it runs inside an AI agent

## Symptom
- A test gate's logs ended with `Test Suites: N passed, N total` and listed no file paths.
- A reviewer's grep for a mapped test path finds nothing, so the run cannot be confirmed per file.
- Reviewers fall back to the aggregate count, which is soft evidence.

## Cause
- `@jest/core` checks the env vars `AI_AGENT`, `CLAUDE_CODE`, `CLAUDECODE` and eight more. If one is set and no `reporters` option is given, it adds the `agent` reporter in place of `default`.
- `AgentReporter` prints a file header only when `numFailingTests > 0` or the file has an exec error.
- So a green run lists no suite path. A gate that runs inside an agent hits this every time.
- Read from jest ~30.5.2: `AGENT_ENV_VARS` in `@jest/core/build/index.js` and `AgentReporter` in `@jest/reporters/build/index.js`.

## Fix pattern
- Pin the reporter in the gate step: `jest --ci --reporters=default`.
- If `jest.config.js` pins no reporter, a bare `npx jest` outside the gate still gets the agent reporter.
- Any new test runner step whose log feeds an audit should print every suite path, pass or fail.
