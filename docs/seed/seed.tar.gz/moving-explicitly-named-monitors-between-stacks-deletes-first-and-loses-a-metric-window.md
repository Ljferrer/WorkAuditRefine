---
name: moving-explicitly-named-monitors-between-stacks-deletes-first-and-loses-a-metric-window
description: "Moving explicitly named CloudWatch monitors to another stack deletes before it creates, which loses a metric window and resets alarm state"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  slug: moving-explicitly-named-monitors-between-stacks-deletes-first-and-loses-a-metric-window
  keywords:
    - move monitors between stacks
    - explicit physical name
    - delete then create
    - lost window
    - metric filter no backfill
    - INSUFFICIENT_DATA
    - alarm history
    - cleanup race
    - cut-over runbook
    - sibling stack
  tags:
    - cdk
    - cloudformation
    - monitoring
    - design
---

## Fact

A team moved every monitor (MetricFilter, Alarm, CompositeAlarm, Dashboard, QueryDefinition) that watches `<ExampleStack>` into a sibling stack.
Monitors with explicit physical names keep those names in the sibling.
Monitors with CloudFormation-generated names begin with the owning stack's name, so they become new monitors.
Two stacks cannot hold one name at once, so the original stack's deploy must delete a named monitor before the sibling creates its twin.
A move of this kind is not a refactor. It has three costs.

- **A lost metric window.** A metric filter does not read log lines from before its creation, so a line logged between the delete and the create never becomes a data point.
- **Alarm state resets.** A new alarm starts in `INSUFFICIENT_DATA` and loses its history. An alarm whose condition still holds fires again as a new transition.
- **A cleanup race CloudFormation cannot see.** If the original stack's cleanup deletes a monitor by name after the sibling created it, CloudFormation still records it as present, and a redeploy of the unchanged sibling changes nothing.

## How the move handled it

- The pipeline definition makes the sibling depend on the original stack's deploy, and a unit test pins that order for every pipeline stage that deploys both.
- An integration test asks the CloudWatch APIs for each declared name and checks that no generated-name monitor under the original stack remains.
- A small tool prints a Logs Insights query that finds the lost lines, and a runbook document covers the cut-over.

## How to apply

If you plan a move of named monitors between stacks, plan the lost window and the alarm reset first.
Sequence the deploys so the delete comes before the create, and pin that order in a pipeline test.
Add an existence check that asks the service, not CloudFormation.
Write the operator runbook before the deploy, and say what the move loses.
