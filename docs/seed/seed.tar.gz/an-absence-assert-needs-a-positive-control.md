---
name: an-absence-assert-needs-a-positive-control
description: "Pair every absence assert with a positive control that proves the collector could see the thing, or it passes vacuously"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - absence assert
    - sensitivity control
    - positive control
    - vacuous pass
    - fixture cannot carry the offender
    - vacuous negative assertion
    - shape detector
    - CFN template scan
    - synth test
    - permissive default
  slug: an-absence-assert-needs-a-positive-control
  tags:
    - testing
    - cdk-synth
    - assertion-strength
---

## Rule

An absence assert passes vacuously if its collector never finds anything. Pair it with a positive control in the same test that proves the collector can see a present instance of the same kind of thing. This applies to CFN-shape synth tests and to plain unit tests alike. Any absence assert on a collection with a permissive default (`.get(key, {})`, `.get(key, [])`) needs a control proving the collector or counter ran at all.

## Shapes

- **A fixture that can never carry the offender.** A spec says that with a feature flag off, the system picks no specialist. The test asserted no call matched the specialist, on a fixture whose input held only one ordinary item. No code path adds a specialist by itself, so the assertion passed whatever the code did. Before you trust "X is absent," ask whether the fixture can even contain X. If the input never carries it and the code never invents it, the assertion is true by construction. Fix: add a fixture that can produce the offender (here, a path that nominates the specialist), so the barred case has something to fail on.
- **A detector that matches only one rendered form.** A test helper that detects an alarm by CloudFormation shape (first matching only a `Metrics[].MetricStat.Metric.Namespace` array) can miss the same alarm rendered as a plain `cloudwatch.Metric` with a top-level `Properties.Namespace`. Its absence asserts then pass on the form it cannot see. Widen the detector to match every form the resource can render in.
- **Pure absence asserts with no control.** Tests like `test_no_<feature>_lambda` and `test_no_<feature>_metric_filter_or_alarm` only assert absence. One also keys on a single env var name, so a matching Lambda under another name passes. If CDK changes the template shape, all of them turn into no-ops with no failure signal.

## Good examples

- A synth test asserts `<DEV_QUEUE>` is in the template blob before asserting `<PROD_QUEUE>` is absent.
- A unit test asserts `body['<counts>']['<present_key>'] == 1` before its `<absent_key>` absence assert.

**Why:** an absence test that cannot fail gives false confidence, especially once the shape it scans changes.

**How to apply:** when you write or review an absence assert, ask whether the same collector runs against a present instance in the same test, and whether the fixture can carry the offender at all. If not, add one. Even a coarse control (at least one `AWS::Lambda::Function` or `AWS::IAM::Policy` found) catches the vacuous pass.
