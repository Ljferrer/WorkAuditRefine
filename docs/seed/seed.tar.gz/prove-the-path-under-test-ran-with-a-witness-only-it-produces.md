---
name: prove-the-path-under-test-ran-with-a-witness-only-it-produces
description: "A test that names a path must prove that path ran with an effect only it produces, such as an injection hook's fired record or a log line only that branch writes"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - once hook
    - fired assert
    - failure injection
    - race test
    - hook never fires
    - label count witness
    - discriminating witness
    - branch-only log line
    - vacuous test
  slug: prove-the-path-under-test-ran-with-a-witness-only-it-produces
  tags:
    - testing
    - fixture
---

A test that claims "path P ran" must witness a side effect that only P produces.

**Shape 1: an injection hook whose result is dropped.** A test helper, `<once_hook>(env, op, matches, action)`, runs `action` on the first matching fake-table op and returns the list of call records. An empty list means the hook never fired. Several tests dropped that return value. If the hook never fired, their outcome asserts still held (tokens, a replay of the seeded name, a held clock, two acceptances). The race path would then go untested with every test green.

The hooks fire today only because the claim writes with `put_item` (matched by `Item`) and the marker read uses `get_item` (matched by `Key`). A later move of the claim to `update_item` would make the `<is_marker_put>` matcher miss with no test turning red.

Fix: bind `fired = <once_hook>(...)` and add `assert fired` after the call under test.

**Shape 2: a label count that a retry also reaches.** A test proved "the escalation path ran" by seeing a dispatch label at least twice. But a fix pass and a full re-review applied that label a second time even with the escalation branch deleted. The count could not see a removed branch.

Fix: witness the branch itself. The code logs a specific line only inside the escalation branch, and a different line only when the specialist nomination was not barred. The test asserts the first and refuses the second.

**Why:** an injection test whose injection never ran still passes on its outcome asserts, and a repeated label is shared by every path that re-runs the step. Neither proves anything about the path it names.

**How to apply:** pair every negative or injection test with a proof that the injection ran. For "path P ran," pick a witness only P can produce, never a count of something other paths also emit.
