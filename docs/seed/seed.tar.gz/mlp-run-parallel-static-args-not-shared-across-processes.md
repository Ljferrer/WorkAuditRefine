---
name: mlp-run-parallel-static-args-not-shared-across-processes
description: "A fork-per-item parallel helper copies static_args dicts, so child mutations never reach parent or siblings"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  slug: mlp-run-parallel-static-args-not-shared-across-processes
  keywords:
    - static_args
    - multiprocessing
    - fork
    - shared state
    - short circuit
    - Process
    - copy-on-write
    - Manager dict
  tags:
    - multiprocessing
    - gotcha
---

## The gotcha

A `<run_parallel>()` helper launches **one `multiprocessing.Process` per
`iter_arg`** (`Process(target=target_func, args=args)`). Every argument
passed through `static_args` is therefore copied into each child
independently (forked copy-on-write; the `spawn` start method pickles a
copy, same result). If a caller passes a **mutable dict** in `static_args`
expecting it to act as shared state across the fan-out (a short-circuit
latch, a once-per-run log guard, an accumulator), every child mutates its
own private copy. The parent process and sibling or later children never
see the change.

Only values that are valid **independent of the process** stay correct. For
example, an absolute `time.monotonic()` deadline float survives the copy
faithfully (CLOCK_MONOTONIC is process-independent). So a wall-clock budget
still holds even though a latch built on the same dict does not.

## Where this bit a real caller

A `<handler>` builds a `<page_state>` dict once per page and passes it as a
`static_args` entry, fanning out one process per pending item on that page.
A `<matcher>` mutates two fields on that dict, expecting page-wide effect:

- `<page_state>['short_circuit']` is meant to stop all further remote calls
  for the page after one connect timeout. It only stops further calls
  **within the same child**. An unreachable endpoint costs one wave of
  timeouts per `max_parallel`-sized batch instead of one total.
- `<page_state>['budget_logged']` is meant to log a "budget expired" token
  once per page. It logs once **per item** whose child hits the expired
  deadline, inflating a log-metric-filter count by up to N (pending items)
  instead of 1.

**Why:** a plain mutable dict silently degrades from "shared latch" to
"process-local no-op", with no error or warning at any layer.

**How to apply:** before passing a mutable object into a per-process
fan-out to carry cross-invocation state, ask whether the intended effect is
run-scoped (needs true sharing) or single-invocation-scoped (local is fine).
If real sharing is required, use a `multiprocessing.Manager().dict()` (or
equivalent) instead of a plain dict. Or evaluate the shared condition in
the **parent** before dispatching each child, and stop dispatching once it
trips.
