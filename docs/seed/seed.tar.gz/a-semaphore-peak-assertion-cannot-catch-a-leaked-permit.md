---
name: a-semaphore-peak-assertion-cannot-catch-a-leaked-permit
description: "A leaked semaphore permit lowers the peak instead of raising it, so a peak-only assertion passes; also assert the counter drains after rejected dispatches"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - counting semaphore
    - permit leak
    - drain assertion
    - leak guard
    - finally release
    - rate limiter testing
    - peak assertion
  slug: a-semaphore-peak-assertion-cannot-catch-a-leaked-permit
  tags:
    - concurrency
    - testing-pattern
---

# A semaphore's peak assertion cannot catch a leaked permit

**Rule.** A counting semaphore gates a dispatch seam. The seam acquires a permit, makes the call, and releases the permit in a `finally`, so a rejected or thrown call never leaks one. Test it with two assertions, not one:
1. A peak/FIFO/results test that settles the run and checks the observed peak.
2. A leak-guard test that drives several rejected dispatches through the seam, then asserts the permit count is back at N and the waiting count is 0 once the run settles.

**Why:** if the `finally` is missing, or a later edit moves the release outside it, a leaked permit does not raise the observed peak. It silently shrinks the pool of permits in circulation. A test that only asserts `peak <= N` cannot tell a draining semaphore from one that is leaking itself shut. The assertion still passes while the ceiling gets stricter over a long run.

**How to apply:** whenever a fix consolidates several throttle or pacing call sites into one shared gate, add the drain test that exercises the rejection path and re-checks the counter's resting state. Never rely on a peak bound alone.
