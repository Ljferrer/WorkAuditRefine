---
name: fork-per-item-parallel-helper-pitfalls
description: "A fork-per-item parallel helper copies static_args dicts, so child mutations never reach parent or siblings; it also has a pipe contract and a test seam"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - static_args
    - multiprocessing
    - fork
    - shared state
    - short circuit
    - Process
    - Manager dict
    - Pipe
    - spawn
  slug: fork-per-item-parallel-helper-pitfalls
  tags:
    - multiprocessing
    - gotcha
---

## Static args are copied, not shared

A `<run_parallel>()` helper launches **one `multiprocessing.Process` per `iter_arg`**. Every argument passed through `static_args` is copied into each child independently (forked copy-on-write; the `spawn` start method pickles a copy, same result). If a caller passes a **mutable dict** in `static_args` expecting shared state across the fan-out (a short-circuit latch, a once-per-run log guard, an accumulator), every child mutates its own private copy. The parent and sibling or later children never see the change.

Only values that are valid **independent of the process** stay correct. An absolute `time.monotonic()` deadline float survives the copy (CLOCK_MONOTONIC is process-independent), so a wall-clock budget still holds even though a latch on the same dict does not.

One caller passed a per-page state dict this way. Its short-circuit latch stopped further calls only within the same child, so an unreachable endpoint cost one wave of timeouts per batch instead of one total. Its "log once" flag logged once per item, inflating a log-metric count by up to N.

**Why:** a plain mutable dict silently degrades from "shared latch" to "process-local no-op", with no error or warning at any layer.

**How to apply:** before passing a mutable object into a per-process fan-out to carry cross-invocation state, ask whether the intended effect is run-scoped (needs true sharing) or single-invocation-scoped (local is fine). If real sharing is required, use a `multiprocessing.Manager().dict()` (or equivalent). Or evaluate the shared condition in the **parent** before dispatching each child, and stop dispatching once it trips.

## Pipe contract

A common helper shape is `run_parallel(iter_args, static_args, target_func, iter_args_first, max_parallel)`:
- It calls `target_func(*iter_arg, *static_args, conn)`. It appends `conn` itself, so never put `conn` in `static_args`.
- The target must end with `conn.send(result); conn.close()`. It must not `return` the result. The helper returns the sent values in input order.
- Check which parameters have defaults before calling.
- The target must be module-level and picklable (no closures), because multiprocessing pickles it.

## Test seam

Under macOS `spawn`, each child re-imports the module and loses monkeypatched fakes, so the test passes under Linux `fork` in CI and flakes locally. Test the fan-out and merge by monkeypatching the parallel helper to a serial fake. Test the per-item function in-process with a stub `conn` that records `.send()` and `.close()`.
