---
name: shape-suite-absence-assert-needs-positive-sensitivity-control
description: "Pair every synth-test absence assert with a positive control, or it passes vacuously when the template changes"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  slug: shape-suite-absence-assert-needs-positive-sensitivity-control
  keywords:
    - absence assert
    - sensitivity control
    - shape suite
    - synth test
    - vacuous pass
    - CFN template scan
    - MetricFilter
    - positive control
    - pytest unit test
  tags:
    - testing
    - cdk-synth
    - shape-suite
---

## Rule

An absence assert passes vacuously if its collector never finds anything.
Pair it with a same-test positive control that proves the collector can
see a present instance of the analogous thing. This applies to CFN-shape
synth tests and to plain unit tests alike. Any absence assert on a
collection with a permissive default (`.get(key, {})`, `.get(key, [])`)
needs a control proving the collector or counter ran at all.

## Instances

- Good: a synth test, `test_<flag_off>_with_sensitivity_control`, asserts
  `<DEV_QUEUE>` is in the template blob before asserting `<PROD_QUEUE>` is
  absent.
- Unguarded, same file: three tests (`test_no_<feature>_lambda`,
  `test_no_<feature>_invoke_grant`, `test_no_<feature>_metric_filter_or_alarm`)
  are pure absence asserts. `test_no_<feature>_lambda` also keys on one env
  var name, so a matching Lambda under another name passes. If CDK changes
  the template shape, all three turn into no-ops with no failure signal.
- Fixed recurrence: a plain unit test now asserts
  `body['<counts>']['<present_key>'] == 1` before its `<absent_key>`
  absence assert.

**Why:** an absence test that cannot fail gives false confidence once the
shape it scans changes.

**How to apply:** when writing or reviewing an absence assert, ask whether
the same collector loop is exercised against a present instance in the same
test. If not, add one. Even a coarse control (at least one
`AWS::Lambda::Function` or `AWS::IAM::Policy` found) catches the vacuous
pass.

Same family: the seed lesson `weak-test-assertion-passes-without-feature-being-exercised`.
