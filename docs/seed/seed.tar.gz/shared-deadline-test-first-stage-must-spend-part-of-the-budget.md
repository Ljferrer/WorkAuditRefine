---
name: shared-deadline-test-first-stage-must-spend-part-of-the-budget
description: "A shared-deadline regression passes vacuously if stage one is served at once, so make stage one spend part of the budget"
metadata:
  node_type: memory
  type: project
  keywords:
    - shared deadline
    - sequential composition
    - vacuous test
    - fake clock
    - poll budget
    - test-fidelity
    - remaining budget
  provenance: agent-unverified
  slug: shared-deadline-test-first-stage-must-spend-part-of-the-budget
  tags:
    - testing
    - test-fidelity
---

A test named for a shared deadline across sequential stages proves nothing
unless stage one spends part of that deadline.

**The trap.** Code computes one deadline and passes it to stage one and then
stage two, so stage two should get only the remainder. If the test serves
stage one on its first poll, the fake clock stays at 0 and stage two gets the
whole budget. The same asserts (total wait == deadline, one acceptance per
item) also hold when stage two wrongly gets a fresh per-stage budget. The
composition property goes unproven.

**The shape that proves it.**
- Give the fake clock a `sleep` that advances it, and bind it to both the
  code under test and the caller.
- Make stage one's terminal result land late (e.g. after 3 polls), so the
  caller's poll sleeps advance the clock.
- Record `t = clock.now` after stage one and assert `0 < t < deadline`.
- For stage two, never deliver a terminal result, and assert the recorded
  wait is `deadline - t`, `clock.now == deadline`, and any stored
  timestamp equals `start + t`.

**Why:** the bug being guarded (each stage getting its own full budget, so
the total wait is a multiple of the deadline) is invisible when stage one
costs zero time.

**How to apply:** for any "shared budget across N sequential calls" test,
make every stage but the last consume a nonzero, asserted slice of the
budget, then assert the last stage gets exactly the remainder.
