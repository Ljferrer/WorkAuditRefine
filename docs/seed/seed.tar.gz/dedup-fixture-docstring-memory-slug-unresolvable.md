---
name: dedup-fixture-docstring-memory-slug-unresolvable
description: A checked-in docstring that cites a private memory slug by name gives a repo reader no way to resolve it
metadata:
  node_type: memory
  type: project
  keywords:
    - fixture provenance
    - memory slug citation
    - docs/learnings
    - operator ruling
    - unresolvable reference
  provenance: code-verified
  slug: dedup-fixture-docstring-memory-slug-unresolvable
  tags:
    - documentation
    - testing
    - war-practice
---

## Pattern

A test module's docstring cited its fixture-provenance ruling as
`(memory \`<slug>\`)`. That slug only resolves inside the operator's private
auto-memory (`type: feedback`, no in-repo home), so a repo reader has no way
to look it up. A sibling citation to a `docs/learnings/<file>.md` path
resolved fine.

## How to apply

When a docstring or comment needs to cite an operator ruling for provenance,
cite it by date and/or PR number (e.g. "operator ruling YYYY-MM-DD"), not by a
private memory slug. A memory slug is meaningful only to the agent tooling
that indexes it; it is opaque to anyone reading the checked-in file. If the
ruling has an in-repo `docs/learnings/` counterpart, cite that file path
instead.
