---
name: dup-grouping-alarm-token-split-pattern
description: "Never-raises handlers: split log tokens by meaning, keep them non-substring for MetricFilters, mirror across files"
metadata:
  node_type: memory
  type: project
  keywords:
    - never-raises handler
    - log token split
    - MetricFilter literal matching
    - CloudWatch alarm design
    - defect vs expected-state
    - lazy alarm
    - alarm posture
    - N-way pairwise non-substring
    - comment-lag mirror gap
  provenance: code-verified
  slug: dup-grouping-alarm-token-split-pattern
  tags:
    - observability
    - cloudwatch
    - alarm-design
    - step-functions
---

## Pattern

A never-raises handler (every failure still writes a status file and returns
200) that logs one alarm token for different meanings should split it into
literal tokens, one per meaning. Each gets its own `logs.MetricFilter` and
`cloudwatch.Alarm`:

- A defect token (e.g. `<STEP>_FAILED`, `<STEP>_DB_WRITE_FAILED`) gets a tight
  posture: short period, low threshold, one datapoint.
- An expected-state token (e.g. `<STEP>_NO_INPUT`) gets a lazy posture: long
  period, higher threshold, two datapoints. A single hit is normal pipeline
  ordering; only a sustained rate pages.

**Pairwise non-substring is load-bearing.** `FilterPattern.literal` matches
any event containing the term, so if one token contained another, both
filters would count it. With N tokens, every pair must be non-substring; add a
unit test (e.g. `test_alarm_tokens_pairwise_non_substring`) that checks the
whole token set.

**Mirror comments on both sides.** The handler defines the constants and the
stack defines the filters. Put a comment on each side naming the other, so
the pair changes together.

**Comment lag when the family grows.** Adding a token means updating every
existing sibling comment, not just the new block (e.g. an older filter comment
still saying "non-substring of the FAILED literal", singular, after a third
token joined). No test reads prose comments.

**Envelope hoist.** Resolve the output bucket and key as the first statements
in the single try block. Otherwise an early failure skips the status write the
alarm design depends on.

**Why:** one token for two meanings either pages on normal ordering or hides
real defects, and a substring overlap corrupts both metrics.

**How to apply:** when adding a log token to an alarm family, keep it
non-substring of every sibling, extend the pairwise test, and sweep every
sibling comment in both the handler and the stack.
