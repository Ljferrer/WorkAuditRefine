---
name: consolidate-exts-v2-timeout
description: A handler that fetches items one at a time can pass its timeout only on a retry, because per-type checkpoints shrink each attempt; fan the fetch out and add a retry
metadata: 
  node_type: memory
  type: project
  keywords: [timeout, sequential S3 fetch, redrive, checkpointing, run_parallel fan-out, step functions retry, multiprocessing pipe]
  slug: consolidate-exts-v2-timeout
  tags: [timeout, run_parallel, sfn-retry, step-functions, multiprocessing]
---

A Lambda handler (`<handler>`) timed out at its 900s limit on large inputs. It fetched "missing" items from S3 one at a time, per item type. At ~190 ms per item, a few thousand missing items in one type took ~500s, and two such types passed 900s.

**Why a retry "eventually" succeeds.** The handler wrote each type's result to S3 inside its per-type loop, and loaded any existing result at the start of the next run. Each timed-out attempt therefore shrank the next attempt's work. A retry passed once enough types were already checkpointed. That is luck, not a fix: one slow type alone can still exceed the limit.

**The fix pattern:**
- **Fan out the per-item fetch.** Move the per-item body into module-level functions and run them through a fork-per-item parallel helper. An 8-way fan-out cut ~500s per type to ~65s. Keep the record shapes and the per-type checkpoint unchanged.
- **Add a Step Functions retry to the long step.** With per-type checkpoints, a retry self-heals. Without one, a single timeout is `ExecutionFailed` and needs a manual redrive. If the state machine is built in more than one place, add the retry in every builder.

**Gotcha: a Pipe-based parallel helper.** A common `run_parallel(iter_args, static_args, target_func, iter_args_first, max_parallel)` shape works like this:
- It calls `target_func(*iter_arg, *static_args, conn)`. It appends `conn` itself, so never put `conn` in `static_args`.
- The target must end with `conn.send(result); conn.close()`. It must not `return` the result. The helper returns the sent values in input order.
- Check which parameters have defaults. In the instance here, `iter_args_first` was a required positional and `max_parallel` defaulted to 5.
- The target must be module-level and picklable (no closures), because multiprocessing pickles it.

**Test seam.** Under macOS `spawn`, each child re-imports the module and loses monkeypatched fakes, so the test passes under Linux `fork` in CI and flakes locally. Test the fan-out and merge by monkeypatching the parallel helper to a serial fake. Test the per-item function in-process with a stub `conn` that records `.send()` and `.close()`.
