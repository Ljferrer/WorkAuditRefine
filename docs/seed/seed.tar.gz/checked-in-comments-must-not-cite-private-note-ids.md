---
name: checked-in-comments-must-not-cite-private-note-ids
description: A checked-in comment or docstring that cites a private note id gives a repo reader no way to resolve it
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - private note citation
    - unresolvable reference
    - provenance comment
    - docstring
    - operator ruling
    - in-repo reference
  slug: checked-in-comments-must-not-cite-private-note-ids
  tags:
    - documentation
---

A checked-in docstring or comment that cites a ruling by a private note id, such as `(memory \`<slug>\`)`, cannot be resolved by a repo reader. That id only resolves inside one person's private notes, and there is no in-repo home for it. A citation to an in-repo file path resolves fine.

**Why:** a private note id is meaningful only to the tooling that indexes it. It is opaque to anyone reading the checked-in file.

**How to apply:** when a comment needs to cite a ruling for provenance, cite it by date and/or PR number (for example "operator ruling YYYY-MM-DD"). If the ruling has a counterpart file in the repo, cite that file path instead.
