---
name: git-diff-name-only-hides-a-rename-source-so-scope-checks-need-no-renames
description: "git diff --name-only prints only a rename's destination, so a footprint check needs --no-renames"
metadata:
  node_type: memory
  slug: git-diff-name-only-hides-a-rename-source-so-scope-checks-need-no-renames
  type: project
  keywords:
    - no-renames
    - name-only
    - rename detection
    - file footprint
    - changed files
    - scope check
  provenance: code-verified
  tags:
    - git
    - scope
  created: 2026-10-29
---

# `git diff --name-only` is rename-blind on the source side

**Fact.** Porcelain `git diff` detects renames by default.
With `--name-only` it then prints only the destination path.
A file deleted by a rename drops out of the list.

**Why it matters.** Suppose a review step reads a changed-file list and keeps earlier approvals when the list sits inside the footprint of the open findings.
An author can rename a file from outside the footprint onto a path a finding names.
The list then shows only footprint files, and reviewers never re-judge the lost file.
A reviewer's independent re-check that uses the same rename-blind command misses the rename too.

**Rule.** Every name-only diff that feeds a scope, footprint or ownership decision uses `--no-renames`, as in `git diff --no-renames --name-only <pre> <tip>`.
Keep the author-side cross-check command and the tool-side source command identical, or a rename forces a needless full re-review.
