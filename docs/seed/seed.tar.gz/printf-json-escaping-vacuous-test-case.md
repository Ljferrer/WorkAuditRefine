---
name: printf-json-escaping-vacuous-test-case
description: "printf-interpolated JSON payloads make embedded-quote test cases vacuous"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - jq --arg
    - invalid payload
    - silent parse failure
    - shell metacharacters
    - embedded quotes
    - string interpolation
    - hook exits zero
  slug: printf-json-escaping-vacuous-test-case
  tags:
    - test-design
    - json
    - escaping
    - bash
---

A test helper that builds a JSON payload by raw `printf` interpolation produces invalid JSON for any input with double quotes or backslashes, and a hook that swallows parse errors then passes the test without reaching the code under test.

```sh
printf '{"agent_type":"worker","tool_input":{"command":"%s"}}' "$1"
```

Given `[ "$x" = ">" ]`, this yields `{"command":"[ "$x" = ">" ]"}`. The hook parses with `jq -r ... 2>/dev/null || true`, so `cmd` becomes empty, the hook hits `[ -z "$cmd" ] && exit 0`, and the test passes. It passes because the payload was unparseable, not because the quoted-`>` false-positive guard fired. The test asserts only exit 0, so it validates nothing.

**Why:** the assertion is correct but the payload construction corrupts every input with shell metacharacters (quotes, brackets, backslashes, paths with spaces, regex patterns). Every such test is silently vacuous.

**How to apply:**
- Build the payload with `jq --arg`, so `jq` handles all escaping:

```sh
worker_cmd() {
  jq -nc --arg c "$1" \
    '{"agent_type":"worker","tool_input":{"command":$c}}'
}
```

- Or check that the payload parses before asserting the hook's exit code, so a malformed payload fails loudly in the helper.
