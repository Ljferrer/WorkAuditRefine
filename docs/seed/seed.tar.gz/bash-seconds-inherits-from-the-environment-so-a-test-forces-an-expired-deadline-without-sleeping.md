---
name: bash-seconds-inherits-from-the-environment-so-a-test-forces-an-expired-deadline-without-sleeping
description: "A test can expire a bash script's SECONDS deadline by exporting SECONDS, but it reaches only the pre-check arms"
metadata:
  node_type: memory
  type: project
  keywords:
    - bash SECONDS
    - deadline test
    - expired pre-check
    - sleep shim flake
    - whole-second granularity
    - mid-call arm
    - test fixture
  provenance: code-verified
  slug: bash-seconds-inherits-from-the-environment-so-a-test-forces-an-expired-deadline-without-sleeping
  tags:
    - hooks
    - testing
    - bash-3.2
  created: 2026-10-24
---

# Export SECONDS to expire a deadline in a test, and know what it cannot reach

**Technique.** A bash script that measures its own deadline on `SECONDS` can be forced past the deadline from outside. Run it as `SECONDS=1000 <PREFIX>_DEADLINE_SECONDS=900 bash "$HOOK"`. Bash counts on from an inherited `SECONDS`, so the first `expired` check fires at once. Have the script's reason string print the deadline in force, so the test can tell a clamped value from an unclamped one. The test needs no sleep, no `git` shim and no wall-clock margin. The source lesson did not run this test on its own: the evidence was a green suite with the test present, where a failed inheritance would have failed it.

**Why it beats a slow shim.** The earlier shape used a deadline of 2 and a `git` shim that slept in `status`. `SECONDS` ticks in whole wall-clock seconds, so a deadline of 2 can fire after 1.0 s of real time. Under load the pre-check can fire before the slow call, and the test passes through the wrong branch or goes red with no defect.

**What it cannot reach.** Expiry is immediate, so the test exercises only the pre-checks at entry to each step. It never reaches branches that fire mid-call, such as a per-call watchdog kill or a check inside a per-path loop. A test for a mid-call branch needs a call that is slow on purpose, such as a `git` shim that sleeps 5 s against a 2 s deadline. That brings back the granularity problem, so give it a margin of several seconds, not one.

**Weak pin.** A test for a default deadline once grepped a bare number, and a header comment satisfied it. Pin a literal on its code line, such as `case "$DEADLINE" in`, never on a number a comment can repeat.
