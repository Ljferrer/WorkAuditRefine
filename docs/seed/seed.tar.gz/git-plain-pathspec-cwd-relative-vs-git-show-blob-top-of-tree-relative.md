---
name: git-plain-pathspec-cwd-relative-vs-git-show-blob-top-of-tree-relative
description: "A plain git pathspec resolves against the current directory, but git show <rev>:<path> is top-of-tree, so a script using one repo-root path for both needs :(top) on the pathspec"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - git pathspec
    - cwd-relative
    - top-of-tree
    - ":(top)"
    - git diff --name-only
    - git show rev:path
    - fail-open check
    - subdirectory invocation
  slug: git-plain-pathspec-cwd-relative-vs-git-show-blob-top-of-tree-relative
  tags:
    - git
    - shell
    - gotcha
---

`git diff -- <path>` is cwd-relative; `git show <rev>:<path>` is not. A script that uses one repo-root-relative path string in both places resolves it two different ways.

A plain pathspec passed to `git diff` (and most git commands that take pathspecs) resolves against the current directory prefix. Run from a subdirectory, the repo-root path matches nothing, the file list comes back empty, and a fast-path guard exits 0: the check is bypassed. The `rev:path` blob read always resolves from the top of the tree, so that half works from any directory, and the inconsistency stays invisible.

**Why:** a test suite driven only through `--repo <dir>` or `git -C <dir>` always starts at the repo root, so it can pass fully while the bug is live whenever production runs from a subdirectory.

**How to apply:**
- Anchor the diff-side pathspec with git's `:(top)` magic, which forces top-of-tree resolution from any cwd and is safe under `git -C <root>`:
  `git diff --name-only "$base...$branch" -- ":(top)$FILE"`
- Or convert both sides to cwd-relative consistently. Never assume the same path string resolves the same way.
- Add a fixture that invokes the script from a subdirectory of the target repo.
