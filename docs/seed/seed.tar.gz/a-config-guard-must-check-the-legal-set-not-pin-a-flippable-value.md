---
name: a-config-guard-must-check-the-legal-set-not-pin-a-flippable-value
description: Assert a config switch is in its legal set and check the shipped value once at review, or a later config-only flip turns the guard red
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - standing pin
    - config flag
    - legal set
    - flip PR
    - drift guard
  slug: a-config-guard-must-check-the-legal-set-not-pin-a-flippable-value
  tags:
    - drift-guard
    - config
    - test-fidelity
---

Assert that each switch value is in the legal set (for example `"0"` or `"1"`), and pin neither value.

**Why:** a standing pin on a switch that a later config-only change flips turns that change red, so the planned flip fails the test.

**How to apply:**
- Check the legal set in the test.
- Check the shipped value once, in a one-time check at review time.
- Never pin a value that a planned config-only change flips.
