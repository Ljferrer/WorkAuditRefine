---
name: git-probing-hook-requires-fixtures-outside-any-git-repo
description: "An unconditional git probe in a previously git-free hook makes every test fixture root need to live outside any git working tree"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - test hermeticity
    - mktemp fixture
    - git probe
    - ancestor repo
    - TMPDIR
    - git-common-dir
    - hook test coupling
    - fixture root outside repo
  slug: git-probing-hook-requires-fixtures-outside-any-git-repo
  tags:
    - testing
    - hermeticity
    - git
    - shell
---

# A hook that starts probing git unconditionally needs its test fixtures pinned outside any git repo

**Rule.** When a previously git-free script or hook starts running `git` unconditionally against a caller-supplied or environment-derived root, audit every test fixture builder for it. Confirm the fixture root cannot land inside an ancestor git repo. Do this either by construction (a `mktemp` convention known to be outside any checkout) or with an explicit assertion in the test harness.

**Why:** the hook's tests built every fixture under a fresh `mktemp -d`. While the hook never invoked `git`, a fixture's location relative to any enclosing checkout did not matter. After the hook began running `git -C "$root" rev-parse --path-format=absolute --git-common-dir` against every fixture, a fixture root inside a git working tree would resolve to that ancestor repo's main checkout, not the fixture's own root. That silently re-roots the scan and breaks injection-path assertions. `mktemp -d` defaults to `/var/folders` on macOS and `/tmp` on Linux CI, both outside any repo, so it is safe today. It is a latent coupling, not a guarantee. A different `TMPDIR` or test runner could break it. BSD `mktemp` ignores `TMPDIR`, so do not rely on redirecting it.

**How to apply:** put a fatal hermeticity guard in the test setup, right after the fixture `cd`. It runs the hook's own probe against the fixture root and aborts if an enclosing repo, working tree or bare, is found. A fixture root inside an ancestor checkout then fails loudly at setup, not far from the cause.
