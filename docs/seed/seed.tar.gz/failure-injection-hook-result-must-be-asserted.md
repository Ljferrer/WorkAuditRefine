---
name: failure-injection-hook-result-must-be-asserted
description: "A failure-injection test must assert that its injection hook fired, or the race path goes untested while the outcome asserts stay green"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  slug: failure-injection-hook-result-must-be-asserted
  keywords:
    - once hook
    - fired assert
    - failure injection
    - vacuous test
    - race test
    - hook never fires
    - positive control
    - test-fidelity
  tags:
    - testing
    - fixture
---

A test helper, `<once_hook>(env, op, matches, action)`, runs `action` on the
first matching fake-table op and returns the list of call records. An empty
list means the hook never fired.

Several tests dropped that return value. If the hook never fired, their
outcome asserts still held (tokens, a replay of the seeded name, a held
clock, two acceptances). The race path would then go untested with every
test green.

**The trigger.** The hooks fire today only because the claim writes with
`put_item` (matched by `Item`) and the marker read uses `get_item` (matched
by `Key`). A later move of the claim to `update_item` would make the
`<is_marker_put>` matcher miss with no test turning red.

**The fix.** Bind `fired = <once_hook>(...)` and add `assert fired` after
the call under test.

**Why:** an injection test whose injection never ran still passes on its
outcome asserts, so it proves nothing about the path it names.

**How to apply:** pair every negative or injection test with a proof that
the injection ran. Same family as
the seed lesson `weak-test-assertion-passes-without-feature-being-exercised`.
