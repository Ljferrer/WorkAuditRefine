---
name: s3-absent-object-detection-conflates-transient-and-denied
description: "A shared S3 helper returns None on any ClientError, and GetObject-only IAM gives AccessDenied for a missing key"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  slug: s3-absent-object-detection-conflates-transient-and-denied
  keywords:
    - ClientError
    - NoSuchKey
    - NoSuchBucket
    - AccessDenied
    - 403
    - GetObject
    - ListBucket
    - HeadObject
    - absent object
    - throttle
    - retry ladder
  tags:
    - s3
    - boto3
    - error-handling
    - iam
    - gotcha
---

Two pitfalls stack when a handler must tell "the S3 object is absent" apart
from "the S3 read failed transiently, retry".

## Pitfall 1: a shared S3 helper swallows every `ClientError` code

A shared helper (`<pkg>/<s3_helper>.py`) whose `<stream_file>()` returns `None`
and `<assert_object_exists>()` returns `False` on any `ClientError`, without
reading `e.response['Error']['Code']`, makes a throttle (503 SlowDown), a
transient 500 and an `AccessDenied` all look like a real `NoSuchKey`. A caller
that treats that falsy return as "absent" and takes a terminal branch
misroutes a transient fault. A `HeadObject` follow-up through the same kind of
helper has the same gap.

## Pitfall 2: GetObject without ListBucket answers a missing key with 403

S3 returns `403 AccessDenied`, not `404 NoSuchKey`, for `GetObject` on a
missing key when the role lacks `s3:ListBucket` on the bucket. An allowlist
like `ABSENT_CODES = ('NoSuchKey', 'NoSuchBucket', '404')` then never matches,
and the "absent" branch is unreachable.

Fix pattern: grant `s3:ListBucket` on the bucket, scoped by an `s3:prefix`
condition to `<prefix>/*`, and have the reader use a plain boto3 client that
checks the error code against `ABSENT_CODES`.

**Why:** a falsy helper return or a 403 hides the real cause, so a
transient fault or an IAM gap can pass for a deleted object, or the reverse.

**How to apply:** before branching on "S3 read failed" as "object absent",
check the actual `Error.Code`, not the helper's truthiness. Confirm the
calling role holds `s3:ListBucket` (prefix-scoped is enough) on the bucket.
A related gap: a helper that catches only `ClientError` lets botocore
transport errors such as timeouts reach the caller uncaught.
