---
name: reduce-checker-reply-cap-must-scale-with-numbered-items
description: "An LLM reply that answers per numbered item needs max_tokens sized to the item count, not a fixed 1024"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - max_tokens
    - max_tokens truncation
    - truncated JSON
    - per-item verdict
    - reply size linear
    - digit tokens
    - stub lane
    - LLM judge
  slug: reduce-checker-reply-cap-must-scale-with-numbered-items
  tags:
    - llm
    - testing
---

An LLM checker prompt changed from "list the failures" (a short reply) to "answer for every numbered item" (a `stated` number per item, plus the short failure list). A fixed `max_tokens` of 1024 fit the old reply. It does not fit the new one on large inputs.

Some tokenizers spend about one token per digit, so a few hundred numbered items fill 1024 tokens (an estimate, not a measurement). A cut reply fails `json.loads` in the verdict parser, which reads it as "check missed", and the conservative fallback path runs for every item. Nothing errors; the feature silently turns off on exactly the large inputs it targets. Every unit stub returned an uncapped reply, so no test saw it.

**Why:** a batch judge that changes from "list the failures" to "answer for each item" changes its reply size from constant to linear.

**How to apply:**
- A helper sizes the cap from the input, for example `max(1024, 64 + 8 * (n_lines + n_pairs))`, stamped on every built prompt as `max_tokens`.
- The caller sends `min(built['max_tokens'], LANE_MAX_TOKENS)`, where `LANE_MAX_TOKENS` mirrors the transport's own cap. A mirror test pins them equal.
- A test drives a 400-item group through a stub that cuts the reply at the payload's `max_tokens` whenever a one-token-per-digit cost exceeds it. A stub that always returns a full reply proves nothing about the cap.
