---
name: an-ancestor-walk-test-must-run-from-a-cwd-verified-free-of-the-marker
description: "A relative-path ancestor-walk test false-allows when its cwd holds the marker, so run it from a verified marker-free directory"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - ancestor walk
    - marker file
    - false allow
    - mktemp
    - TMPDIR
    - fixture isolation
    - relative path
  slug: an-ancestor-walk-test-must-run-from-a-cwd-verified-free-of-the-marker
  tags:
    - testing
    - cwd
    - bash
    - guard-design
---

# An ancestor-walk test must run from a cwd verified free of the marker

**Rule.** A test that checks "a relative path with no real marked ancestor is denied" must run the hook from a directory verified free of the marker file. Root that directory in a fixture the suite controls, and precondition-check its ancestor chain. A bare `mktemp -d` is not enough, because its ancestry depends on `TMPDIR`.

**Why:** the hook code was correct. The test ran from a cwd that held the marker file at its root. The walk for `relative/sub/file.txt` goes `relative/sub`, then `relative`, then `.`. At `.` it found the cwd's own marker and allowed the path. The test expected a deny, so it failed, but the fault was in the fixture. Running from the repo root can also mask a real regression with a false allow. On Linux or CI, `mktemp -d` can land under a marked ancestor when `TMPDIR` points inside a marked tree.

**How to apply:**
- Create a marker-free fixture directory at suite setup and run the relative-path case from inside it.
- Walk the chosen directory's ancestors before the case. If any holds the marker, print a precondition-failed message to stderr and fail loudly, so an environment that cannot be isolated never false-allows.
- Comment the clean directory as load-bearing, not incidental.
