---
name: config-switch-guard-list-holders-no-standing-value-pin
description: A guard for a config switch holds its holders in a list and pins no flippable value
metadata:
  node_type: memory
  type: project
  keywords:
    - config holder guard
    - exactly one config entry
    - same-named entries collapse
    - json duplicate keys
    - standing value pin
    - config-only flip PR
    - drift guard test
  provenance: code-verified
  slug: config-switch-guard-list-holders-no-standing-value-pin
  tags:
    - drift-guard
    - config
    - test-fidelity
---

## Fact

A test that says "exactly one config entry ships these switch keys" has three
traps.

1. **Name-keyed dict.** A walk that stores `holders[name] = keys` merges two
   entries that share a name. `len(holders) == 1` then passes with two
   holders. Return a list of `(name, keys)` pairs and assert
   `[name for name, _ in holders] == [EXPECTED_ENTRY]`.
2. **Duplicate keys in one object.** `json.loads` (and JS `JSON.parse`) keeps
   the last of two equal keys in the same JSON object. Neither a dict nor a
   list of holders can see the first. Only a count of the quoted key in the
   file text can.
3. **Standing value pin.** Assert each value is in the legal set (e.g. `"0"`
   or `"1"`) and pin neither. A standing pin on a switch that a later
   config-only PR flips turns that PR red. Pin the shipped value in a one-time
   check at review time instead.

When an audit finds trap 1 in a new guard, sweep older sibling guards built
the same way; the fix does not reach them on its own.

## How to apply

- Write a new "one entry holds these keys" guard with a list of
  `(name, keys)` pairs.
- If duplicate keys in one object matter, add a text count of the quoted key.
- Never pin a value that a planned config-only PR flips.
