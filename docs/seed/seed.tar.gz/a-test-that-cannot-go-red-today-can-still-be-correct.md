---
name: a-test-that-cannot-go-red-today-can-still-be-correct
description: "A test that never goes red for the current code, or does not discriminate alone, can still be a valid guard; check for future-regression intent and sibling tests first"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - vacuous test
    - future regression guard
    - decoy fixture
    - discrimination
    - sibling test
    - weak assertion
    - review calibration
    - retired text grep guard
    - add-only surface
    - old-absent half
  slug: a-test-that-cannot-go-red-today-can-still-be-correct
  tags:
    - review-calibration
    - test-quality
---

A test can look weak (it never goes red, or it does not discriminate on its own) and still be correct. Check these three patterns before you rate it a defect.

**Pattern A: a guard for a future regression.** An absence assertion (for example, "this decoy path must never appear in the output") can be non-vacuous even when it never goes red against the current parser. The decoy may be shaped to matter only for a future parser feature. Example: a backticked table-cell token that today's link-only extractor cannot read anyway, but a future backtick-cell extractor might. If the nearby comment documents this forward-looking intent, keep the assertion.

**Pattern B: discrimination split across sibling fixtures.** One fixture may give the same output (for example, `[]`) under two possible root causes, such as backtick-absence keying versus zero-files keying. It does not discriminate alone. But if an adjacent fixture in the same suite exercises the other branch (for example, a mixed case that goes red if the fallback fires despite a backtick), the pair provides the discrimination.

**Pattern C: an old-text-absent check on an add-only surface.** A doc grep guard gives each surface two halves: retired text absent, new text present. Some surfaces only ever added text, such as a new section or a dated note. On those rows the retired sentences were never there, so the absent half cannot go red today.
- That half still guards the future: it goes red if someone later writes the retired text into that region. It just cannot catch a stale surface.
- What carries the row is the new-text-present half plus fail-closed extraction. A missing anchor throws, an empty region fails, and an empty token list fails.
- A shared token read from the code under test at load time sits in a try/catch. On failure, every row that needs it gets a sentinel no file contains. Each row then fails on its own line, and the whole test file never dies at import.

**Why:** rating a valid future guard as a defect wastes a fix and can remove real coverage.

**How to apply:** when an assertion looks like it proves little in isolation, read (1) its comment for future-regression intent, (2) the adjacent tests in the same section for split discrimination, and (3) for a retire-the-text guard, which rows' old half the surface never held. Judge those rows only by their new half and fail-closed extraction.
