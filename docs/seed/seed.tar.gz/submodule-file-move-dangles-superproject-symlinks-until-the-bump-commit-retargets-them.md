---
name: submodule-file-move-dangles-superproject-symlinks-until-the-bump-commit-retargets-them
description: Moving or renaming a file in a shared-library submodule leaves superproject symlinks to it dangling until the submodule bump commit retargets them
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - submodule bump
    - symlink retarget
    - dangling symlink
    - file move
    - packaging
    - ImportError
  slug: submodule-file-move-dangles-superproject-symlinks-until-the-bump-commit-retargets-them
  tags:
    - submodule
    - symlink
    - packaging
---

## Rule

When a change in a shared-library submodule moves or renames a file that superproject symlinks target, those links dangle until the bump commit retargets them.
Put the retarget in the same commit as the submodule pointer bump. Never bump first and retarget later.

**Why:** the submodule's own symlink-resolution test walks only the submodule tree, so it cannot see links in the superproject.
A dangling link fails hard where a module imports the moved file at module scope.
It fails silently where a caller catches `ImportError`. That caller drops a feature and only records a field in an error dict.
A packaging test can cover the shims, but only for the contexts its trigger names.

**How to apply:**

1. Find the links with git, using `git ls-files -s` for mode 120000 or `git grep` for the old file name. In a checkout whose submodule is not populated, a dangling link is invisible to file-read and search tools.
2. A review item with a superproject fix site cannot be fixed in a change that touches only the submodule, because the submodule worktree has no such site. Carry it in the step list for the superproject bump.
