---
name: port-plan-literals-lose-to-live-source-capture-at-deployed-sha
description: "A plan's claims about the source system of a port were wrong five times in one phase, so capture fixtures from the deployed commit"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  slug: port-plan-literals-lose-to-live-source-capture-at-deployed-sha
  keywords: [port, parity, fixture capture, deployed commit, detached worktree, lockfile, byte-exact fixture, plan literal wrong]
  tags: [porting, fixtures, plan-vs-code, testing]
---

A plan that ports code from another system states that system's behavior from memory.
In one phase, five such statements failed against the live source or the capture.
They covered an LLM request token limit, a retrieval model name, the operation order of a third-party string helper, a list-selection rule under a non-unique parent, and a page cap with retrieval counts.
In every case the port followed the live source and the audit confirmed it.
The binding arbiter is the byte-exact fixture render, not the plan sentence.

**Why:** a plan sentence about the source system is a hypothesis, and a test built on a false premise either fails or gets inverted into a vacuous check.

**How to apply:**

- Treat every plan sentence about the source system as a hypothesis. Read the source or the capture before you write the check.
- Capture fixtures from the commit that the deployed function reports at capture time, for example through a `DEPLOYED_COMMIT_SHA` environment variable. A sibling clone and the plan's pin can lag it.
- Run the capture from a detached scratch worktree at that commit, after a lockfile-exact install such as `npm ci`.
- Never switch the branch of the operator's checkout of the source repo. Commit nothing there and remove the scratch worktree afterward.
- Do not trust an existing clone's installed dependencies. One clone held an older SDK than its lockfile, which would have recorded wrong SDK defaults.
- When a test asserts that a plan constant equals a captured value and the premise is false, raise the conflict early and ask the operator for a ruling.
