---
name: dynamodb-free-name-claim-uses-attribute-type-null
description: "A DynamoDB conditional claim that treats an absent or NULL attribute as free must use attribute_type(..., NULL), not an equality test"
metadata:
  node_type: memory
  type: project
  keywords:
    - attribute_type
    - attribute_not_exists
    - NULL operand
    - conditional put
    - ConditionExpression
    - legacy NULL value
    - ValidationException
    - Incorrect operand type
    - race test
  provenance: code-verified
  slug: dynamodb-free-name-claim-uses-attribute-type-null
  tags:
    - dynamodb
    - idempotency
---

Older code stored a pre-submit marker item with a NULL-typed name attribute. A conditional claim on that marker must therefore treat both an absent and a NULL name as free.

The free-name condition is `(attribute_not_exists(#jn) OR attribute_type(#jn, :null))`, with `{':null': 'NULL'}` as the value (the type code string). The held-name claim is `#jn = :held`.

An equality test against a NULL operand does not express this. The in-repo test fake rejected it, and a reviewer reported that live DynamoDB rejects it too ("Incorrect operand type ... NULL"). That live behavior was reviewer-reported, not run.

**Test the race, not only the shape.** A test has two callers race over a stale NULL-name marker: the second reads the NULL marker while the first already holds a name. With an unconditional put it would submit a second name, so an `acceptances == 1` assertion fails. That proves the conditional claim on the legacy path, which a test of the expression string alone cannot.
