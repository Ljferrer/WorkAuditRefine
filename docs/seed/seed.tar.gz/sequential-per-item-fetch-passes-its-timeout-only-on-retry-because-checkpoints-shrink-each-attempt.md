---
name: sequential-per-item-fetch-passes-its-timeout-only-on-retry-because-checkpoints-shrink-each-attempt
description: A handler that fetches items one at a time can pass its timeout only on a retry, because per-type checkpoints shrink each attempt; fan the fetch out and add a retry
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - timeout
    - sequential S3 fetch
    - redrive
    - checkpointing
    - fan-out
    - step functions retry
    - Lambda 900s limit
  slug: sequential-per-item-fetch-passes-its-timeout-only-on-retry-because-checkpoints-shrink-each-attempt
  tags:
    - timeout
    - sfn-retry
    - step-functions
---

A Lambda handler timed out at its 900s limit on large inputs. It fetched "missing" items from S3 one at a time, per item type. At ~190 ms per item, a few thousand missing items in one type took ~500s, and two such types passed 900s.

**Why a retry "eventually" succeeds.** The handler wrote each type's result to S3 inside its per-type loop, and loaded any existing result at the start of the next run. Each timed-out attempt therefore shrank the next attempt's work. A retry passed once enough types were already checkpointed. That is luck, not a fix: one slow type alone can still exceed the limit.

**How to apply:**
- **Fan out the per-item fetch.** Move the per-item body into module-level functions and run them through a fork-per-item parallel helper. An 8-way fan-out cut ~500s per type to ~65s. Keep the record shapes and the per-type checkpoint unchanged.
- **Add a Step Functions retry to the long step.** With per-type checkpoints, a retry self-heals. Without one, a single timeout is `ExecutionFailed` and needs a manual redrive. If the state machine is built in more than one place, add the retry in every builder.
