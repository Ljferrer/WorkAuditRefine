---
name: a-diff-guard-must-read-gitmodules-at-the-ref-not-the-working-tree
description: "A diff guard must read .gitmodules at the diff refs with git config --blob, not from the working tree"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - git config --blob
    - submodule guard
    - checked-out file
    - diff endpoint mismatch
    - declared paths misclassified
    - gitlink check
    - cat-file -e
    - ref snapshot
  slug: a-diff-guard-must-read-gitmodules-at-the-ref-not-the-working-tree
  tags:
    - submodule
    - gitmodules
    - shell-guard
---

# A diff guard reads `.gitmodules` at the ref, not the working tree

A guard that classifies submodule paths in a diff must read `.gitmodules` as of the ref it is judging, using `git config --blob "<ref>:.gitmodules"`. It must not use `git config -f` on the checked-out file.

**Why:** a working-tree read diverges from the diff endpoints the guard reasons about. A branch that edits `.gitmodules` itself can then make the guard misclassify which paths are declared.

**How to apply:**
- Probe existence first with `git cat-file -e "<ref>:.gitmodules"`. Absent means a clean skip.
- Then read with `git config --blob "<ref>:.gitmodules"`. A read failure after a successful probe is an error exit, not a clean skip.
- Do not keep a working-tree fallback.
- Default any new path-discrimination on a similar guard to a ref-snapshot read from the start.
