---
name: readme-demirror-guard-intersects-backticked-spans-with-ast-constants
description: A README de-mirror guard intersects backticked spans with module constants read by AST
metadata:
  node_type: memory
  type: project
  keywords:
    - README restates no value
    - de-mirror guard
    - doc drift guard
    - backticked spans
    - ast.literal_eval
    - ast.parse without import
    - _FIELD suffix
    - pointer not mirror
  provenance: code-verified
  slug: readme-demirror-guard-intersects-backticked-spans-with-ast-constants
  tags:
    - drift-guard
    - documentation
    - pattern
---

## Pattern

A rule forbade the README from restating any of a module's stage, source or
exit values; the README points at `<pkg>/<module>.py` instead. A first guard
checked only seven old phrases, so a later edit could add a backticked
`exhausted` and stay green.

The fixed guard:

- Reads `<pkg>/<module>.py` with `ast.parse` and `ast.literal_eval`. It does
  not import the module, because the module has heavy import-time
  dependencies.
- Collects the string constants named `SOURCE_*`, `STAGE_*` and `EXIT_*`, and
  skips names that end in `_FIELD`.
- For each guarded README section,
  `set(re.findall(r'`([^`]+)`', section_text)) & values` must be empty.
- `assert values` is the sensitivity floor. It fails if the module stops
  defining those constants.

## Naming rule the guard depends on

`EXIT_FIELD = 'dedup_exit'` is a field name, and the same test requires the
README to name it. So a constant that holds a field name must end in
`_FIELD`; a constant that holds a value must use a value prefix and must not
end in `_FIELD`. A new constant that breaks this either turns the guard red
or lets a mirrored value in unseen.

## Limits

- The guard checks backticked spans only. A value written in plain words
  passes.
- It does not check meaning.
- A new constant whose value equals a word the README already backticks in
  those sections turns the guard red. Unquote the README word, or point at
  the module.

## How to apply

Use this shape for any doc rule of the form "the README names the fields and
points at the module for the values". Read the module by AST, split names
from values by suffix, and intersect the values with the section's
backticked spans.
