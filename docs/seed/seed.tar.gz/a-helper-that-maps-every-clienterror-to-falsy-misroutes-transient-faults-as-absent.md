---
name: a-helper-that-maps-every-clienterror-to-falsy-misroutes-transient-faults-as-absent
description: "A boto3 helper that returns None or False on every ClientError makes throttles, 5xx and denials look like a missing object"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - ClientError
    - Error.Code
    - NoSuchKey
    - throttle
    - transient fault
    - boto3 helper
    - absent object
    - HeadObject
  slug: a-helper-that-maps-every-clienterror-to-falsy-misroutes-transient-faults-as-absent
  tags:
    - s3
    - boto3
    - error-handling
    - gotcha
---

# A helper that maps every ClientError to a falsy return misroutes transient faults as absent

**Rule.** Branch on `e.response['Error']['Code']`, not on a helper's truthiness. A shared S3 helper whose stream function returns `None`, or whose existence check returns `False`, on any `ClientError` without reading the code makes a throttle (503 SlowDown), a transient 500 and an `AccessDenied` all look like a real `NoSuchKey`. A `HeadObject` follow-up through the same kind of helper has the same gap.

**Why:** a caller that treats the falsy return as "absent" and takes a terminal branch misroutes a transient fault. A retryable error then reads as a deleted object.

**How to apply:**
- Before branching on "S3 read failed" as "object absent", check the actual `Error.Code` against an absent-code allowlist.
- Let every other code reach the retry path.
- A helper that catches only `ClientError` lets botocore transport errors such as timeouts reach the caller uncaught. Handle those too.
