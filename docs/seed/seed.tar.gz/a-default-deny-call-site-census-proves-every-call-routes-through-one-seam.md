---
name: a-default-deny-call-site-census-proves-every-call-routes-through-one-seam
description: "To prove every call goes through one wrapper, count the call sites in the source and require that they all sit inside the wrapper"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - call-site census
    - default deny
    - single seam
    - bypass
    - source text test
    - retired helper
  slug: a-default-deny-call-site-census-proves-every-call-routes-through-one-seam
  tags:
    - testing-pattern
    - refactoring
---

# A default-deny call-site census proves every call routes through one seam

**Rule.** When all calls to some function must go through one wrapper, test the source text. Count every `fn(` call site in the whole file. Require that count to equal the count of `fn(` calls inside the wrapper body. Use an exact count, not "at least". A new site that bypasses the wrapper then fails the test.

**Why:** a behavior test only exercises the paths it drives. A bypassing call site added later leaves behavior tests green while it skips the shared ceiling or guard.

**How to apply:** the same census proves a retired mechanism is gone.
- Count of the old helper's occurrences, definition plus call sites, must be exactly zero.
- No call site may still pass the old parameter. The limit lives only at the seam.
- Run the census on the stripped source text, so comments and strings do not count as call sites.

Use it for any "all calls go through one wrapper" rule, such as a shared throttle, a logger, or a permission check.
