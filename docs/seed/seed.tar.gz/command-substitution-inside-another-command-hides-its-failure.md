---
name: command-substitution-inside-another-command-hides-its-failure
description: "for m in $(cmd) and dirname \"$(cmd)\" both hide a failed cmd, so capture it first with x=$(cmd) && and check it"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - for loop command substitution
    - swallowed exit status
    - capture then check
    - dirname of failed substitution
    - plausible 0
    - fail-open anchor
    - git rev-parse --git-common-dir
  slug: command-substitution-inside-another-command-hides-its-failure
  tags:
    - shell
    - git
    - tests
---

# Command substitution inside another command hides its failure

**The shell fact.** In `for m in $(cmd); do ...; done`, bash ignores the exit status of `cmd`.
If `cmd` fails with no output, the loop runs zero times and the line exits 0. If it prints and then fails, the loop runs over what it printed and the failure is lost.
A read that then falls back to a default (for example an empty range) reports a plausible value, not an error.

The same holds when a substitution feeds another command. `dirname "$(failing-cmd)"` prints `.`, never an empty string, so a failed probe looks like a real result.

**Why:** the failure of the inner command never reaches the exit status, so the caller sees a plausible value instead of an error.

**How to apply:** capture first, check, then use the value.

```sh
ms=$(cmd) && for m in $ms; do ...; done
common="$(git rev-parse --path-format=absolute --git-common-dir 2>/dev/null)" && [ -n "$common" ] && root="$(dirname "$common")"
```

A failed `cmd` now fails the whole command. In a fail-open caller, a failed probe leaves the old value untouched.
Use the composed one-liner only where the inner command cannot fail.
