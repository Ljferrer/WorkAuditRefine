---
name: die-process-exit-inside-try-skips-finally-cleanup
description: "A die() helper that calls process.exit inside a try block skips the enclosing finally, so scratch dirs leak on every error path; throw a tagged Error and exit only in main()"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - process.exit
    - finally not called
    - try finally skipped
    - die helper
    - scratch dir leak
    - mkdtempSync
    - fail-fast CLI
    - cleanup skipped
    - tagged Error throw
    - single exit point
  slug: die-process-exit-inside-try-skips-finally-cleanup
  tags:
    - node
    - cli-tooling
    - process-exit
    - cleanup
    - temp-files
---

# `process.exit()` inside a `try` body never runs the enclosing `finally`

**Rule.** `process.exit()` terminates without unwinding the stack. A `try { ... } finally { cleanup }` around it is dead code on that path. A shared "fail fast" helper that exits, reachable inside the try directly or transitively, defeats every scratch-dir `finally` cleanup even though the try/finally looks leak-proof.

**Why:** the cleanup is safe for every in-band throw or return, so the leak shows up only on error paths.

**How to apply:**
- Before trusting a try/finally region, check whether anything reachable inside the try can call `process.exit()`.
- Fix: make `die()` throw a tagged error, such as `Object.assign(new Error(msg), { exitCode: code })`. Let `main()`'s catch be the only `process.exit` site, so it runs after every `finally` has unwound. Rethrow untagged errors unchanged.
- Test it with a subprocess run under a scoped `TMPDIR`, asserting that no scratch entries survive a failing command.

**Known residuals of the throw-based pattern:**
- A `finally` body that itself throws, such as `fs.rmSync` hitting EACCES or EBUSY, replaces the tagged error. `main()` then rethrows it untagged, and the process exits 1 with a raw stack instead of the contract code.
- `main()`'s single try/catch assumes every verb stays fully synchronous. A tagged throw inside a Promise in a future `async` verb becomes an unhandled rejection that skips the catch.
