---
name: failed-cd-in-a-compound-command-runs-the-rest-in-the-main-checkout
description: "A failed git worktree add followed by cd does not stop a compound shell command, so the rest runs in the original checkout"
metadata:
  node_type: memory
  type: feedback
  provenance: user-confirmed
  keywords:
    - worktree guard
    - failed cd
    - set -e does not stop
    - wrong checkout
    - git worktree add
    - show-toplevel assertion
    - staged in the wrong repo
  slug: failed-cd-in-a-compound-command-runs-the-rest-in-the-main-checkout
  tags:
    - git
    - shell
    - worktree
---

A failed `cd` does not stop the rest of a compound command. If `git worktree add "$P" <branch>` fails (a branch can be checked out in only one worktree, so a second `worktree add` for it fails), `$P` is never created and `cd "$P"` fails too. Every later step then runs in the current directory, the main checkout, and a `git add` stages there.

`set -e` does not save you: a failing `cd` inside a compound or `eval`-style command does not abort the rest.

**Why:** the wrong tree can hold uncommitted work that must never be staged, and it can sit on a different base than you expect.

**How to apply:**
- Before any `git add` or `commit` in a script that changed directories, assert where you are, not only that the last command returned zero:

```
cd "$P" || { echo "FATAL: cd failed"; exit 1; }
[ "$(git rev-parse --show-toplevel)" = "$P" ] || { echo "FATAL: wrong worktree"; exit 1; }
[ "$(git rev-parse --abbrev-ref HEAD)" = "$BRANCH" ] || { echo "FATAL: wrong branch"; exit 1; }
```

- If a worktree for the branch already exists, reuse it after `git fetch` and `git reset --hard origin/<branch>` instead of adding a second one.
