---
name: a-leading-zero-is-octal-inside-bash-arithmetic
description: "A digit check and [ -lt ] accept 08, but $((08)) fails as octal, so normalize once with $((10#$v)) after validation"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - octal
    - leading zero
    - bash arithmetic
    - 10#
    - input validation
    - numeric override
  slug: a-leading-zero-is-octal-inside-bash-arithmetic
  tags:
    - bash
    - validation
---

# A leading zero is octal inside `$((...))`

**Rule.** Test brackets such as `[ "$v" -lt 600 ]` read decimal. Arithmetic expansion `$((...))` reads a leading zero as octal. A value like `08` passes a digit check and a bracket test, then fails inside `$((...))`. Normalize once after validation: `v=$((10#$v))`.

**Why:** a script validated an override with a digit check and `[ -lt 600 ]`, and both accepted `08`. A new `$((DEADLINE - SECONDS))` then read `08` as octal and failed, so every run with that override failed. Earlier the variable was only read by `[ -ge ]`, so nothing had shown the gap.

**How to apply:** when you add an arithmetic use of an existing variable, re-read how that variable is validated. Apply `10#` once, right after the clamp or validation step, so every later use sees a clean decimal.
