---
name: superseding-an-adr-leaves-stale-pointers-in-readme
description: A sweep that retires a README claim can leave a second README pointer at the superseded ADR.
metadata:
  node_type: memory
  type: project
  keywords:
    - README
    - ADR
    - superseded
    - doc cascade
    - stale pointer
    - comment lag
    - docs sweep
  provenance: agent-unverified
  slug: superseding-an-adr-leaves-stale-pointers-in-readme
  tags:
    - docs
    - adr
    - audit-pattern
  created: 2026-10-28
---

Pattern: a doc sweep fixes the one README row it targets and leaves other rows that cite the retired decision.

A new architecture decision record (ADR) superseded an older one. A task rewrote the README row that stated the old claim. A setup bullet in the same README still pointed at the old ADR.

The author had scoped this out with "no other README rows". Reviewers ruled that a scope note is not a barrier, because the file was already touched.

Sibling drift came with it: a README sentence still described a feature as it stood before a later change landed, and a status paragraph called already landed work "next".

Do this when a plan supersedes an ADR: Grep the README and `docs/` for the old ADR filename and for the retired claim, then fix every hit in the same task.
