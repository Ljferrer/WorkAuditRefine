---
name: agent-sandbox-probe-needs-git-dash-c-because-the-shell-cwd-resets
description: "A sandbox probe must use git -C <sandbox> on every call, because the shell tool resets cwd between calls and a bare git push hits the real remote"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - sandbox escape
    - git -C
    - stray push
    - cd does not persist
    - ls-remote
    - junk ref
    - prompt-enforced scope
  slug: agent-sandbox-probe-needs-git-dash-c-because-the-shell-cwd-resets
  tags:
    - sandbox
    - git
    - shell
---

A probe that runs `cd <sandbox>` in one shell call and a bare `git push` in a later one can push to the real remote. The shell tool resets cwd to the session default between calls, so the later command runs in the session repo. A shell variable that resolved empty made it worse.

**Why:** a "work only in a throwaway copy" scope is enforced by the prompt, not by a sandbox. Nothing stops a stray command from escaping it.

**How to apply:**
- Use absolute sandbox paths and `git -C <sandbox>` for every git call. Never rely on `cd` plus a later relative command.
- After any run of executed git probes, check `git ls-remote --heads origin` and the working tree for stray refs and files before you trust the result.
