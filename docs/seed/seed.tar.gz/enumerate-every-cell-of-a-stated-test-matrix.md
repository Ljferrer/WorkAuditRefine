---
name: enumerate-every-cell-of-a-stated-test-matrix
description: "A test matrix written from natural examples misses the boundary cells, so list every cell and give each AND'd condition its own negative test"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - cartesian product
    - boundary combination
    - combinatorial coverage
    - test enumeration
    - silent gap
    - contract edges
    - conjunct isolation test
    - negative test per condition
  slug: enumerate-every-cell-of-a-stated-test-matrix
  tags:
    - testing
    - matrix-coverage
    - drift-guard
---

## Rule

When a spec states a matrix ("cover A × B"), people fill the cells that match the most natural examples. They miss the boundary combinations, and those are the cells that mark the contract's edges.

After you write matrix-style tests, list ALL cells in a comment or table. The test-row count should equal rows × columns. A comment that names each cell prevents silent gaps. Review misses these gaps because each cell that is present looks correct on its own.

The same holds for a predicate built from k AND'd conditions (for example, a runtime check, a feature flag, and a gate pair that resolves true). It needs one negative test per conjunct: flip that one condition off and assert the result is absent. One combined positive test proves nothing about which conjunct is load-bearing.

**Why:** the missing cells are exactly the ones that tell the contract's edges apart.

**How to apply:** count rows against rows × columns, and name each cell. When a build predicate has more than one AND'd condition, write one negative test per conjunct.
