---
name: submodule-reads-use-git-show-at-the-gitlink-not-the-working-tree
description: "A submodule working tree can lag the commit the superproject pins, so read submodule code with git show at the pinned SHA"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords: [submodule, gitlink, git show, git ls-tree, stale working tree, plan evidence, worktree]
  slug: submodule-reads-use-git-show-at-the-gitlink-not-the-working-tree
  tags: [git, submodules, planning, evidence]
---

A superproject pins each submodule to one commit, called the gitlink.
The main checkout's submodule working tree is not kept at that commit.
Worktrees often have no submodule checkout at all.
Evidence read from a stale submodule tree states behavior the deployed code no longer has.

In one planning session, a plan claimed that a shared query helper catches every SQL error and returns an empty list.
That claim came from the stale working tree.
At the pinned commit the helper raises a typed exception instead.

**Why:** a plan or audit that reads an older submodule tree describes code that is not what the superproject builds and deploys.

**How to apply:**

- Get the pinned SHA with `git ls-tree HEAD <shared-lib submodule path>`.
- Read a file at that SHA with `git -C <main checkout>/<shared-lib submodule path> show <sha>:<path>`.
- List or search the tree at that SHA with `git ls-tree -r <sha>` or `git grep <pattern> <sha>`.
- Apply the same rule to every other submodule in the repo.
- Cite the SHA next to any claim about submodule behavior in a plan or audit.
