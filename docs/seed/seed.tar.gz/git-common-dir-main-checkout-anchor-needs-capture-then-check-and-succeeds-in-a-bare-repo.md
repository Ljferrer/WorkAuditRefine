---
name: git-common-dir-main-checkout-anchor-needs-capture-then-check-and-succeeds-in-a-bare-repo
description: "The git rev-parse --path-format=absolute --git-common-dir main-checkout anchor needs capture-then-check, and its probe succeeds inside a bare repo"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - git-common-dir
    - git rev-parse --path-format=absolute
    - main checkout anchor
    - bare repo
    - fail-open
    - two-step capture form
    - worktree anchor idiom
  slug: git-common-dir-main-checkout-anchor-needs-capture-then-check-and-succeeds-in-a-bare-repo
  tags:
    - git
    - fail-open
    - shell
    - worktree
---

# The git-common-dir main-checkout anchor: capture then check, and it succeeds in a bare repo

The idiom resolves a linked worktree's cwd to the main checkout: the dirname of the shared git common dir. It is meant to be fail-open. Any probe failure must leave the caller's cwd-relative behavior untouched.

**1. Use the two-step capture-then-check form.**

```sh
common="$(git -C "$root" rev-parse --path-format=absolute --git-common-dir 2>/dev/null)" && [ -n "$common" ] && root="$(dirname "$common")"
```

The assignment carries git's exit status, then the non-empty check gates `dirname`. The composed one-liner `root=$(dirname "$(git rev-parse ...)")` breaks fail-open: `dirname` of a failed or empty substitution returns `.`, so a non-git cwd silently gets `root=.`.
The one-liner is fine only where git cannot fail, such as prose for a caller that always runs inside a repo.

**2. The probe succeeds in a bare repo.** `git rev-parse --path-format=absolute --git-common-dir` returns the bare repo's own git dir, so the anchor moves to `dirname(bare-dir)`. It does not fall through.
Comments that list "git absent / not a repo / bare" as fail-open cases are wrong about "bare". Drop "bare" from that list, or say that a bare layout resolves to a dir that carries none of the expected markers, so the caller still behaves fail-open one level down.

**Why:** a caller whose marker does exist at `dirname(bare-dir)` would get a real bug, not a cosmetic one.

**How to apply:** copy the two-step form for any new caller that must keep today's behavior on a failed probe, and do not claim "bare" fails the probe.
