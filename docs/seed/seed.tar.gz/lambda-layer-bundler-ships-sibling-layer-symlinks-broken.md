---
name: lambda-layer-bundler-ships-sibling-layer-symlinks-broken
description: "A Lambda layer bundler that packs one layer folder alone ships a symlink to a sibling layer as a dangling link, so share a module by placing its one copy in a layer the functions already attach; container-image functions need a symlink per shared module"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - Lambda layer
    - symlink
    - bundler
    - SAM build
    - container image lambda
    - Dockerfile COPY
    - ImportModuleError
    - layer limit
  slug: lambda-layer-bundler-ships-sibling-layer-symlinks-broken
  tags:
    - packaging
    - lambda
    - cdk
---

A bundler that builds each Lambda layer from its own folder sees nothing outside that folder. A symlink in one layer that points into a sibling layer folder is copied as a dangling link. The module is then missing at runtime, and the import fails only after deploy. A zip Lambda can attach at most 5 layers, so a new layer may also hit the limit.

**Container-image functions are the opposite case.** If a handler's `Dockerfile` does `COPY *.py`, shared modules reach the image only as symlinks committed in the handler directory (git mode `120000`). A new shared module is not importable just because it sits in the layer directory. Each consuming handler directory needs its own symlink. Without it, the Lambda fails at load with `Runtime.ImportModuleError: No module named '<module>'`. A local gate with no `cdk synth` or deploy cannot catch this; only a deploy shows it.

**Why:** a plan to share one module between handlers first proposed a symlink to the sibling layer and then a brand-new layer. Both failed review. Reproducing the build in the SAM build image showed the broken link. The accepted fix moved the one copy into a layer the handlers already attach.

**How to apply:**

1. To share a module between zip Lambdas, put its one copy in a layer those Lambdas already attach.
2. Use symlinks into the layer tree only for container-image functions, because their build copies from the full repo. Check each handler's Dockerfile and symlink set before the swap.
3. Before trusting a packaging plan, reproduce the build in the SAM build image and list the module in the resulting layer.
4. Count the layers on each function against the limit of 5 before proposing a new one.
