---
name: optional-fast-dependency-fallback-runs-untested-on-a-layer-that-omits-it
description: "A module with an optional fast dependency and a pure-Python fallback silently runs the slow fallback on a Lambda layer that omits the dependency, and no test forces that path"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - optional dependency
    - rapidfuzz
    - ImportError fallback
    - Levenshtein
    - zip Lambda
    - layer requirements
    - test parity
    - performance
  slug: optional-fast-dependency-fallback-runs-untested-on-a-layer-that-omits-it
  tags:
    - packaging
    - test-gap
    - performance
    - zip-lambda
---

A shared module that does `from rapidfuzz.distance import Levenshtein` and falls back to a pure-Python DP on `ImportError` runs the slow path on any Lambda whose layer omits rapidfuzz. The light layer that ships the module lists none of it. Only a heavier layer lists it, and a zip Lambda cannot attach that layer because it installs far past Lambda's 250 MB unzipped limit.

Local test runs take the fast path, because the dev requirements list rapidfuzz. A grep for the fallback helper names and for `rapidfuzz` in the library's tests finds nothing, so no test forces the fallback.

**Why:** the slow path ships untested, and nothing pins that both paths give equal distances.

**How to apply:**
1. Add a test that blocks the `rapidfuzz` import, reloads the module, and compares caller output on fixture inputs with the fast path.
2. Time the caller with the fallback on the densest fixture before relying on a feature knob for long inputs.
3. Fix a speed problem by adding the dependency to the light layer's requirements or by capping the work per input. Pick after measuring.
4. In general, any `try: import fast / except ImportError: slow` needs one test per branch.

Verify the layer requirements still omit the dependency before acting.
