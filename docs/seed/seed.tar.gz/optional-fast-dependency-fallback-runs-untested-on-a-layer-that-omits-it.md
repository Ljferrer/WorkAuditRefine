---
name: optional-fast-dependency-fallback-runs-untested-on-a-layer-that-omits-it
description: "A module with an optional fast dependency and a pure-Python fallback silently runs the slow fallback on a Lambda layer that omits the dependency, and no test forces that path"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  slug: optional-fast-dependency-fallback-runs-untested-on-a-layer-that-omits-it
  keywords:
    - optional dependency
    - rapidfuzz
    - ImportError fallback
    - Levenshtein
    - zip Lambda
    - layer requirements
    - test parity
    - performance
  tags:
    - packaging
    - test-gap
    - performance
    - zip-lambda
---

## Fact

A shared module, <shared-lib submodule>/<layer>/<matcher>.py, tries `from rapidfuzz.distance import Levenshtein` and falls back to a pure-Python DP on `ImportError`. The requirements file of the layer that ships this module lists none of rapidfuzz. Only a different, heavier layer lists it.

A zip Lambda cannot attach that heavier layer, because it installs far past Lambda's 250 MB unzipped limit. So a zip Lambda that gets the module from the light layer runs the slow path.

The superproject dev requirements list rapidfuzz, so local test runs take the fast path by default. A grep for the fallback helper names and for `rapidfuzz` in the shared library's tests finds nothing. No test forces the fallback.

## What is not known

- Whether the two paths give equal distances. An auditor claimed they do, and no test pins that claim.
- How slow the fallback is. One caller scans every Markdown token for each OCR word and scores each pair, so the worst case is words times tokens. Nobody timed it on a zip Lambda.
- Whether the shared library's own gate interpreter has rapidfuzz.

## How to apply

1. Add a test that blocks the `rapidfuzz` import, reloads the module, and compares caller output on fixture inputs with the fast path.
2. Time the caller with the fallback on the densest fixture before relying on a feature knob for long inputs.
3. Fix a speed problem by adding the dependency to the light layer's requirements or by capping the work per input. Pick after measuring.
4. In general, any `try: import fast / except ImportError: slow` needs one test per branch.

Verify the layer requirements still omit the dependency before acting.
