---
name: jest-expo-passwithnotests-red-at-base
description: "The jest-expo preset sets passWithNoTests, so a path-filtered jest check passes with no test file until jest.config.js overrides it."
metadata:
  node_type: memory
  slug: jest-expo-passwithnotests-red-at-base
  type: project
  keywords:
    - jest-expo
    - passWithNoTests
    - No tests found
    - red at base
    - acceptance check
    - path filter
    - jest exit 0
    - missing test file
  provenance: code-verified
  tags:
    - jest
    - gate
    - acceptance-check
    - expo
  created: 2026-10-27
---

# The jest-expo preset hides a missing test file

## Fact
The jest-expo preset sets `jestPreset.passWithNoTests = true` in `node_modules/jest-expo/jest-preset.js`.
Jest merges preset keys under the project config.
So `npx jest src/<pkg>/<module>` exits 0 with "No tests found" if the test file is absent or misnamed.

## Why it matters
An acceptance check that is a path-filtered jest run is meant to fail before the work is done ("red at base").
With the preset default, a task that forgets or misnames its test file reads as green.
A gate running `jest --ci` also stays green if every test is deleted.

## Fix
Set `passWithNoTests: false` in `jest.config.js`.
Add a test that runs `jest --ci src/no-such-module` in a child process and expects exit 1 and the text "No tests found".
Delete the override and that test goes red.
The test asserts the real exit code, which rules out a jest CLI default that differs from the preset.

## How to apply
When a plan names a path-filtered test runner as an acceptance check, prove the runner fails on zero matches.
Do this in the bootstrap task, before any task owns a test file.
