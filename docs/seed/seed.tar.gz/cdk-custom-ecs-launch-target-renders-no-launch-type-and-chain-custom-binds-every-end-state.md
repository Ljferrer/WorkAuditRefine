---
name: cdk-custom-ecs-launch-target-renders-no-launch-type-and-chain-custom-binds-every-end-state
description: A CDK custom IEcsLaunchTarget that returns a CapacityProviderStrategy renders no LaunchType, and Chain.custom binds a caller's next() to every end state
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - IEcsLaunchTarget
    - CapacityProviderStrategy
    - LaunchType
    - Fargate Spot
    - Chain.custom
    - CDK Step Functions
  slug: cdk-custom-ecs-launch-target-renders-no-launch-type-and-chain-custom-binds-every-end-state
  tags:
    - step-functions
    - ecs
    - fargate
    - cdk
---

A custom `IEcsLaunchTarget` whose `bind` returns `CapacityProviderStrategy` renders no `LaunchType`. Use it for a Fargate capacity-provider launch target.

`sfn.Chain.custom(stage_task, [spot_task, twin_task], twin_task)` starts at the stage task and makes a caller's `.next()` bind both end states.

**How to apply:** when a task needs a capacity-provider strategy instead of a launch type, write a custom launch target. When a chain forks into a primary and a fallback task, build it with `Chain.custom(start, ends, last)`.
