---
name: sfn-catch-into-rebuilt-pass-drops-untracked-keys
description: "A Step Functions Catch landing past a Parameters-rebuilding Pass with no ResultPath silently drops any key that Pass omits"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  slug: sfn-catch-into-rebuilt-pass-drops-untracked-keys
  keywords:
    - Catch
    - add_catch
    - ResultPath
    - Parameters
    - Pass state
    - States.Runtime
    - ItemSelector
    - Distributed Map
    - allowlist
    - idempotent stamp
  tags:
    - step-functions
    - asl
    - regression
---

## Fact

A Step Functions `Pass` that uses `Parameters` with no `ResultPath` rebuilds
the whole state. Any upstream key not in its literal key list is dropped. A
`Catch` that re-enters a state downstream of such a `Pass` can therefore lose
a key that the happy path still carries.

## Instance

In a `<state-machine>`, a `Pass` before `<HeadHandler>` stamps a
`<version_key>`, and a chunk Distributed Map's `ItemSelector` reads
`'<version_key>.$': '$.<version_key>'`. `<PrepareSaveInput>` (a `Parameters`
`Pass`) rebuilds the event without that key. `<SaveStep>`'s catch re-entered
`<HeadHandler>` on the rebuilt object. The next Map evaluation then raised
`States.Runtime` for the missing path, and no `Retry` or `Catch` (not even
`States.ALL`) intercepts that error. A save-error recovery retry failed the
whole execution. Review caught this before merge.

## Fix pattern

Build one idempotent stamp `Pass`, `<StampVersion>`
(`result_path='$.<version_key>'`), and point every catch in the chain at it,
not at `<HeadHandler>`. A unit test asserts every `Catch` `Next` resolves to
the stamp state.

**Why:** a comment claiming a key is "always present" does not survive a
catch-back path through a rebuilding `Pass`, and the resulting
`States.Runtime` failure cannot be caught.

**How to apply:** when a new top-level key rides execution input and is read
downstream by name (a Map `ItemSelector`, a Lambda event), walk every
`Catch` `Next` target forward. Flag any intervening `Pass` with `Parameters`
and no `ResultPath`. Route such catches through an idempotent stamp, and pin
it with a test on every catch target, not only the happy path.
