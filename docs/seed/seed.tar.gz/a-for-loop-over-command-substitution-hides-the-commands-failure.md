---
name: a-for-loop-over-command-substitution-hides-the-commands-failure
description: "for m in $(cmd) ignores a failed cmd, so capture it first with ms=$(cmd) &&"
metadata:
  node_type: memory
  type: project
  keywords:
    - for loop command substitution
    - swallowed exit status
    - rev-list --first-parent --merges
    - bounded merge walk
    - tip..integration
    - PATH git wrapper
    - plausible 0
  provenance: code-verified
  slug: a-for-loop-over-command-substitution-hides-the-commands-failure
  tags:
    - shell
    - git
    - tests
  created: 2026-10-30
---

# A for loop over command substitution hides the command's failure

**The shell fact.** In `for m in $(cmd); do ...; done`, bash ignores the exit status of `cmd`.
If `cmd` fails with no output, the loop runs zero times and the line exits 0. If it prints and then fails, the loop runs over what it printed and the failure is still lost.
A read that then falls back to a default (here, an empty range) reports a plausible value, not an error.

**The fix.** Capture first and chain: `ms=$(cmd) && for m in $ms; do ...; done`.
A failed `cmd` now fails the whole command.

**Example.** A shell command walked merge commits to find a task's merge commit M.
The first spelling used `for m in $(git rev-list ...)`, so a failed walk read as a count of 0.

**Bound the merge walk.** To find a merge M whose second parent is the task tip, walk `rev-list --first-parent --merges "$tip..<integration>"`.
M can never be an ancestor of the tip, so the bound never loses it.
An unbounded walk made one `rev-parse` spawn per first-parent merge in history.
A branch already at the integration tip gets an empty walk.

**Testing a single git failure.** The failed-walk arm can look untestable. It is not.
Put a node `git` wrapper first on `PATH` that exits 128 only for the exact call (for example `rev-list` plus `--first-parent` plus `--merges`).
Delegate every other call to the real git.
Then run the exact command text through `bash -c` and assert a non-zero status.
Prove it red by rewriting the capture back to the `for m in $(...)` form and asserting exit 0.
