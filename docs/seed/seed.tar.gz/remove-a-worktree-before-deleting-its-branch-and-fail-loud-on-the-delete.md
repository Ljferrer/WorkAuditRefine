---
name: remove-a-worktree-before-deleting-its-branch-and-fail-loud-on-the-delete
description: "Remove the worktree that has a branch checked out before deleting the branch, and let the delete fail loud"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - branch delete refused
    - checked out worktree
    - worktree remove
    - warn swallow
    - silent footgun
    - teardown order
    - integration branch cleanup
  slug: remove-a-worktree-before-deleting-its-branch-and-fail-loud-on-the-delete
  tags:
    - teardown
    - worktree
    - git
    - fail-loud
---

# Remove a worktree before deleting its branch, and fail loud on the delete

**Rule 1: order.** Git refuses to delete a branch that is checked out in a worktree. Any teardown that deletes a branch must remove the worktree first, by path, so it works whether the worktree is on the branch or detached.

**Rule 2: fail loud.** Delete the branch with the real exit status propagated. A `|| warn` swallow on a branch delete is a silent footgun.

**Why:** a swallowed delete failure leaves the branch behind and reports success.

**How to apply:** in a teardown, reap the worktree by path, then delete the branch, and let a non-zero exit stop the script. A teardown that keeps the worktree and branch on purpose (for example for held work) skips both steps together.
