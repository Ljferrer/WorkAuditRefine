---
name: no-fixture-fires-guard-test-calls-the-guards-own-functions-in-harness-run
description: "A test that no fixture fires a degrade token must call the guard's own functions in the shared harness and opt in per token"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - no fixture fires
    - degrade token test
    - shared test harness
    - autouse fixture
    - expected tokens
    - restated predicate
    - positive control
    - pytest request.node
  slug: no-fixture-fires-guard-test-calls-the-guards-own-functions-in-harness-run
  tags:
    - tests
    - test-fidelity
    - pytest
    - pattern
---

When no fixture in a handler's test suites may fire a degrade token (a log line such as `<TOKEN_A>` or `<TOKEN_B>` that production emits instead of raising), this assertion is the only strict half left once strictness moves from a raise to logs and alarms. Four rules make it hold.

1. **Put the check in the shared runner.** The suite's shared `Harness.run` calls a `guards()` check after every run. Any other test module that imports `Harness` gets the check too.
2. **Call the guard's own functions.** The check runs the production guard functions against the run's real inputs and asserts every degrade count is zero. Restating the predicates in the test over hand-built inputs misses branches and crediting logic of the real guard, and stays green if the production predicate drifts.
3. **Opt in per token, not per test.** An autouse fixture fails any test whose captured log holds a degrade line. A `degrade_token` fixture records each token a test expects on `request.node`, and the autouse check exempts only those tokens. Turning the whole guard off for any test that uses `degrade_token` lets a stray, different token through.
4. **Add a positive control:** a test proves the guard fails when a token fires with no expectation, or with only the other token expected.

**Why:** a guard test that restates the predicate or exempts whole tests can stay green while the guard is broken.

**How to apply:** put the check in the shared harness, drive it with the production guard functions, and exempt tokens individually.
