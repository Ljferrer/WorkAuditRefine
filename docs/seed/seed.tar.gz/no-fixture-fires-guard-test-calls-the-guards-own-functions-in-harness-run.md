---
name: no-fixture-fires-guard-test-calls-the-guards-own-functions-in-harness-run
description: "A test that no fixture fires a degrade token must call the guard's own functions in the shared harness and opt in per token"
metadata:
  node_type: memory
  type: project
  keywords:
    - no fixture fires
    - degrade token test
    - shared test harness
    - autouse fixture
    - expected tokens
    - restated predicate
    - positive control
    - pytest request.node
  provenance: code-verified
  slug: no-fixture-fires-guard-test-calls-the-guards-own-functions-in-harness-run
  tags:
    - tests
    - test-fidelity
    - pytest
    - pattern
---

## Pattern

A plan required that no fixture in a handler's test suites fires a degrade token (a log line such as `<TOKEN_A>` or `<TOKEN_B>` that production emits instead of raising).
Once strictness moves from a raise to logs and alarms, this assertion is the only strict half left.
Four rules made it hold.

1. **Put the check in the shared runner.**
   The suite's shared `Harness.run` calls a `guards()` check after every run.
   Any other test module that imports `Harness` gets the check too.
2. **Call the guard's own functions.**
   The check runs the production guard functions themselves against the run's real inputs and asserts every degrade count is zero.
   The first version restated the predicates in the test over hand-built inputs.
   It missed one branch of the real guard and some of its crediting logic,
   and it would have stayed green if the production predicate drifted.
3. **Opt in per token, not per test.**
   An autouse fixture fails any test whose captured log holds a degrade line.
   A `degrade_token` fixture records each token a test expects on `request.node.<expected_tokens>`, and the autouse check exempts only those tokens.
   The first version turned the whole guard off for any test that used `degrade_token`.
   A test that planted one defect then missed a stray, different token.
4. **Add a positive control.**
   A test proves the guard fails when a token fires with no expectation, or with only the other token expected.

Related: the seed lesson `weak-test-assertion-passes-without-feature-being-exercised`.
