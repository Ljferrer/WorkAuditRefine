---
name: stranded-upstream-makes-safe-branch-d-refuse-a-merged-branch
description: "A stranded remote tip makes `git branch -d` refuse a local branch that IS merged — unset the upstream, don't escalate to -D"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - git branch -d refuses
    - unset-upstream
    - stranded upstream
    - branch -D force delete
    - pre-rebase remote tip
    - merged into upstream not HEAD
    - branch cleanup
  slug: stranded-upstream-makes-safe-branch-d-refuse-a-merged-branch
  tags:
    - git
    - cleanup
    - worktree
---

# A stranded remote tip makes `git branch -d` refuse a branch that is already merged

`git branch -d` refused local branches whose remote tips were stranded pre-rebase SHAs, even though each local tip was provably reachable from the main branch (`git merge-base --is-ancestor <tip> <main>` is true, tested at delete time).

**Mechanism.** When a branch has an upstream, `git branch -d` does not check "merged into HEAD". It requires the branch to be fully merged into its upstream, and falls back to HEAD only when no upstream is set. If the branch was rebased locally and the remote ref kept the pre-rebase commit, the two tips sit on divergent histories and neither is an ancestor of the other. So `-d` refuses. The refusal says nothing about safety: the content is in the main branch.

**The rule: remove the confounder, don't lower the bar.** `git branch -D` is the force verb and disables git's own merged check. That check is an independent second opinion worth keeping when deleting refs. Instead:

```sh
git branch --unset-upstream <branch>   # drop the stranded tracking ref
git branch -d <branch>                 # now -d compares against HEAD and PASSES
```

With no upstream, `-d` falls back to the merged-into-HEAD check, so git re-verifies the deletion instead of being overridden.

**Why:** a cleanup that reads `-d`'s refusal as "unmerged work" will either leave these branches for a human forever, or escalate to `-D` and give up the safety check without authorization. The refusal is an artifact of the tracking ref, not a data-loss signal.

**Remote side.** The local branch is deletable, but the stranded remote ref it tracked stays. Report it, and clear it only by a deliberate manual `git push origin --delete`.
