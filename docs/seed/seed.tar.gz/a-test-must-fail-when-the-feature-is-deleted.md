---
name: a-test-must-fail-when-the-feature-is-deleted
description: "Delete the feature in your head or by mutation; every assertion that names it must go red, or the test proves only no crash"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - vacuous test
    - false green
    - delete and trace
    - mutation proof
    - prove the guard red
    - independent oracle
    - self-referential test
    - shared exit code
    - fallback deny path
    - negative match on undefined
    - dead regex branch
    - inert tiebreak
  slug: a-test-must-fail-when-the-feature-is-deleted
  tags:
    - testing
    - assertion-strength
    - guard-test
---

**Rule:** before you trust a green test, delete the guard or feature (in your head, or by mutation) and trace whether every assertion still passes. If it does, the test proves "no crash," not "feature works."

**Prove each guard red.** Mutate the thing it guards (delete the arm, flip the comparison, change one digit in a restated value) and watch the exact assertion fail. A guard that was never red is a hope. When a test has several arms, make a mutation that should turn only one arm red, and confirm that it does before you call that arm covered. Enumerate the arms from the code's own branches, never from a reviewer's list. A weak line left beside a discriminating witness can make a test look weaker than it is, so read the whole test.

**Give every guard an oracle that does not share the code under test.** A test that compares a function's output against a value computed by the same function is self-referential and stays green on the bug it should catch. Find a second mechanism (a different scanner, a compiler, a census of names) and rest the guard on that.

Failure shapes:

- **Contains-assertion** matching text already in the base string: assert a token unique to the threaded value (a serialized key or number, a clause heading).
- **Shared exit code:** the guard-fired path and a fallback path (for example, an empty diff) both exit 1. Build a fixture where only the guard produces that exit.
- **Multi-step guard:** a case satisfied by step N masks all steps after N. Add a case only the target step can satisfy. A fixture detail that is inert for the pass path can still be load-bearing for the red proof, so judge against both. Example: when a reject pattern is widened, a branch that has a second, independent deny path (such as an ancestor-walk fallback) denies the new input before and after the widening, so only a branch that falls through to allow can prove the widening.
- **Dead regex alternate:** a branch that embeds a literal `${...}` placeholder never matches rendered output. Drop it or test the template before rendering.
- **Negative match on a keyed lookup:** `/x/.test(undefined)` returns false. Add an `assert.ok(x)` presence guard before any negative match.
- **Substring of the old form:** after a reword, a positive `includes` on a substring of the removed form is vacuous alone. Pair it with a negative absence assert on the superset form.
- **Wrong loop-exit path:** a test titled for a guard term may exit through a different branch entirely. Trace end to end. Unreachability may mean the guard is defensive-dead, not that the fixture is wrong.
- **Inert tiebreak from a hardcoded-empty fixture field:** if a fixture helper hardcodes a sort key (for example, `date: ''`) for every row, that function's tiebreak is a no-op, and an order-equivalence assertion passes only because the input was already hand-ordered. Give each row a distinct value, or add a fixture only the tiebreak can pass.

**Why:** green no-op tests survive feature deletion and rot silently.

**How to apply:** run the delete-and-trace check on every new guard or threading assertion. Prove each arm red by a mutation that targets only that arm. Pair positives with negatives, and negatives with presence guards.
