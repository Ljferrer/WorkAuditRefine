---
name: zsh-dollar-var-colon-path-triggers-parameter-modifiers-so-brace-it
description: "In zsh, an unbraced $T:path in a git <rev>:<path> argument triggers parameter modifiers (:h, :s) and mangles the path; write \"${T}:path\""
metadata:
  node_type: memory
  type: feedback
  provenance: code-verified
  keywords:
    - zsh
    - parameter modifier
    - git show
    - rev colon path
    - bad substitution
    - dirname modifier
    - vacuous result
    - brace expansion
  slug: zsh-dollar-var-colon-path-triggers-parameter-modifiers-so-brace-it
  tags:
    - zsh
    - git
    - shell
---

In zsh, `$T:hooks/foo.sh` is not "the value of `T`, then `:hooks/foo.sh`". After `$T:`, zsh reads a parameter modifier: `:h` is dirname, `:s` is substitute, and `:r`, `:t` and `:e` are live too. In `git show $T:hooks/validate.sh`, one case produced a mangled path (`.ooks/...`) that git rejected, and another gave a `bad substitution` error.

**Why:** the command fails or reads the wrong path, and a downstream pipeline sees empty input. A check on that output can then pass vacuously.

**How to apply:**
- Always brace the variable in a `<rev>:<path>` argument: `git show "${T}:path"`.
- Treat `$T:anything` as modifier territory in zsh.
- Check that a dump succeeded (exit code, byte size) before trusting any count taken from it.
