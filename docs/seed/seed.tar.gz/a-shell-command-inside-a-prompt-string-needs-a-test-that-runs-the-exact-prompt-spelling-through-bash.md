---
name: a-shell-command-inside-a-prompt-string-needs-a-test-that-runs-the-exact-prompt-spelling-through-bash
description: A git command spelled in an agent prompt needs a test that runs that exact text through bash
metadata:
  node_type: memory
  type: project
  keywords:
    - shell quoting
    - unquoted format
    - trailers:key
    - prompt literal
    - argv fixture
    - bash syntax error
  provenance: code-verified
  slug: a-shell-command-inside-a-prompt-string-needs-a-test-that-runs-the-exact-prompt-spelling-through-bash
  tags:
    - tests
    - prompt-surface
    - shell
---

# A shell command inside a prompt string needs a test that runs the exact prompt text

**The trap.** A prompt can tell an agent to run a literal git command.
One prompt first spelled `git show -s --format=%(trailers:key=<Trailer-Key>) <ref>` unquoted.
In bash an unquoted `(` in that word is a syntax error, and zsh rejects it too.
An agent that copied the literal got no trailer, so every merge confirmation failed closed and the task could stall.

**Why the tests stayed green.** The real-git fixture helper read the trailer through a `spawnSync` argv array.
An argv array never meets shell quoting, so it passes with either spelling.
A fix quoted the format, and a later review found that no test would catch a revert of that fix.

**The fix pattern.** Extract the command text from the prompt itself.
Replace its placeholder and run it through `bash`, then assert exit 0 and the expected output.

**Rule.** If a prompt string carries a shell command, test the prompt's own spelling through a shell.
A fixture that rebuilds the same command as argv proves the git semantics only, never the quoting.
Check sibling commands in other prompts for the same spelling too.
