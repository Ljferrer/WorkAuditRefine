---
name: container-insights-family-metrics-are-per-task-datapoints
description: "Container Insights family metrics are one datapoint per task per minute: use Sum or SampleCount, never Average"
metadata:
  node_type: memory
  type: project
  provenance: "code-verified (Sept 2026: a Sum integration matched the daily ECS cost line; Average undercounted roughly 30x)"
  slug: container-insights-family-metrics-are-per-task-datapoints
  keywords:
    - CloudWatch Container Insights
    - ECS/ContainerInsights
    - task family metrics
    - Sum
    - Average
    - SampleCount
    - Maximum
    - vCPU-hours
    - Fargate cost attribution
  tags:
    - cloudwatch
    - ecs
    - fargate
    - cost-analysis
    - metrics
---

Container Insights per-family metrics in `ECS/ContainerInsights` are emitted
once per running task per minute, not pre-summed per family. `Average`
therefore returns the per-task size (0.5 vCPU for a small task) whatever the
fan-out. An integration over `Average` undercounted a high-fan-out
`<service>`'s steps by roughly 30x. `Sum` at period 60 is the fleet's
reserved units that minute; vCPU-hours = Σ Sum/1024/60. `SampleCount` is
task-minutes, and `Maximum` is the largest single task's value (the right
number for "can we shrink memory").

**Why:** an ECS cost analysis first reported the `<service>`'s share of the
Fargate bill from `Average` and got a tiny fraction. CloudTrail RunTask
counts contradicted it. `Sum` gave a figure roughly 30x larger, which tracked
Cost Explorer's daily ECS line within the residual from other always-on
services.

**How to apply:** for any per-family or per-cluster Container Insights
integration use `Sum` and `SampleCount`. Validate against Cost Explorer daily
before quoting a share. Dimension-less metrics blend deployments the same
way, so check which dimensions a metric carries before aggregating it.
