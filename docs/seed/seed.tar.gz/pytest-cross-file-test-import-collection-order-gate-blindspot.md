---
name: pytest-cross-file-test-import-collection-order-gate-blindspot
description: "A module-level import between two test files can pass the gate on collection order alone, and each file's own task check command misses it"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  slug: pytest-cross-file-test-import-collection-order-gate-blindspot
  keywords:
    - pytest collection order
    - ImportError partially initialized module
    - cross-file test import
    - circular import test files
    - module-level import test file
    - task check command gap
    - gate false green
  tags:
    - testing
    - pytest
---

## Fact

`tests/unit/test_<feature_a>.py` added a module-level import of literals
from `tests/unit/test_<feature_b>.py`, which already imported from the
first file. The full suite passes when pytest collects
`test_<feature_a>.py` first (the alphabetical default in this case).
Collect `test_<feature_b>.py` first, as any command that lists it earlier
does, and pytest raises
`ImportError: cannot import name '<LITERAL>' from partially initialized module`
at collection, before any test runs.

The task's own check command never listed `test_<feature_b>.py`, so its
gate never caught the collision it introduced. The full-suite gate stayed
green only because pytest's default collection order happened to import
the two files in the safe direction.

The fix: a leaf module, `tests/unit/<feature>_test_literals.py`, that
imports no test module. Both test files now import shared literals from
that leaf module instead of from each other.

## How to apply

Never add a module-level `from test_x import y` between two test files.
Shared literals belong in a leaf fixture or literals module that imports no
test module.

Before trusting a green gate on a new cross-test import, run each touched
test file alone in a fresh process (`pytest tests/unit/test_a.py`, not just
the full suite). A full-suite pass can hide a collection-order-dependent
`ImportError` that a different collection order, or a different check's
file list, would catch.

A task's check command should include every test file it edits, not just
the one it primarily targets.
