---
name: forked-process-test-asserts-need-controls-that-run-in-the-child
description: "In a forked-process test, an assert on the child's behavior needs a control that ran in the child"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - forked process test
    - multiprocessing child
    - vacuous assert
    - spy membership assert
    - positive control
    - child-side control
    - absence assert
    - pid compare
  slug: forked-process-test-asserts-need-controls-that-run-in-the-child
  tags:
    - testing
    - test-fidelity
    - fork
---

## Rule

When a test forks a child process and asserts something about what the child did, the control must run in the child. A control that runs in the test process proves nothing about the child. An audit found four such asserts in one harness test file. Each held for a reason unrelated to the child.

## Examples

1. **Spy checked by membership.** A spy over `<builder>()` asserted that one expected call appeared in the call list. The handler's own setup code makes that same call in every child, so the assert held even if the code under test hard-coded the value. The fix made the stand-in return a distinguishable value, recorded the pid, and counted calls per process.
2. **Constant compared with its own literal.** Asserting that a `PATCHED_NAMES` constant equals its literal says nothing about what the child patched. The fix had the child write out the names whose identity differs from the parent's module, and the test compared that list.
3. **Absence with no positive control.** An assert that no S3 put happened passed because the input carried no request id, so the put could never fire. The fix wrapped the routing helper to add the id and asserted that the child's log lines arrived first.
4. **A count that cannot fail.** `threading.active_count() >= 1` holds in every process. The test also needs `row['pid'] != os.getpid()`.

## How to apply

- Before you trust an assert on a forked child, ask what in the test process could make it true without the child.
- Make the stand-in's output distinguishable from the real one, or count calls by pid.
- Put the positive control where the negative assert's evidence is produced, in the same process, the same file and the same routing.
- When two exits name the same thing, also assert each exit's own substring.
