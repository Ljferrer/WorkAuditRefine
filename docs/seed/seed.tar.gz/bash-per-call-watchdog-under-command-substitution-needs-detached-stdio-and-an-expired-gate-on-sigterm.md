---
name: bash-per-call-watchdog-under-command-substitution-needs-detached-stdio-and-an-expired-gate-on-sigterm
description: "A bash 3.2 watchdog around one call inside $(...) needs detached stdio, an empty pid seed and an expired gate on exit 143"
metadata:
  node_type: memory
  type: project
  keywords:
    - bounded
    - watchdog
    - command substitution
    - orphan sleep
    - exit 143
    - octal 08
    - "10#"
    - PATH shim test
  provenance: code-verified
  slug: bash-per-call-watchdog-under-command-substitution-needs-detached-stdio-and-an-expired-gate-on-sigterm
  tags:
    - hooks
    - bash
    - watchdog
    - guard-design
  created: 2026-10-26
---

# Four traps in a per-call bash watchdog

**Rule.** To bound one blocking call in a bash 3.2 script, run the call as a background child with its output sent to a temp file. Start a watchdog subshell that sleeps for the time left, then sends SIGTERM to the child. `wait` the child, then cancel the watchdog. Call this wrapper `bounded`. It solves the problem that a deadline checked only between steps cannot stop one long blocking call.

**Trap 1: the watchdog holds the caller's pipe.** Every bounded call runs inside a caller's `$(...)`. The watchdog subshell and its `sleep` inherit that pipe as stdout. If the cancel TERM lands between `sleep &` and `_s=$!`, the trap kills nothing and the `sleep` lives on. The `$(...)` then blocks until the deadline and reports a false timeout. Fix: send the watchdog's stdout and stderr to `/dev/null`, and set `_s=""` before the trap. Without the seed, `kill "$_s"` aborts under `set -u`. This came from reading the code. Nobody ran the race, so treat the mechanism as a labeled hypothesis. The fix costs nothing.

**Trap 2: exit 143 is not proof of a timeout.** `wait` reports 143 for any SIGTERM. A version that returned the timeout code for every 143 misread a SIGTERM from elsewhere, such as a `core.fsmonitor` helper that kills its parent, as a timeout. That matters when only a timeout offers a fail-open choice and a git error does not. The correct line is `[ "$_crc" = 143 ] && expired && return 3`, where `expired` tests `SECONDS >= DEADLINE`. It is sound because the watchdog sleeps the whole remaining deadline in whole seconds, so the deadline has passed at its kill. Pin it with a wall-time test oracle that shares no code with the script.

**Trap 3: a leading zero is octal inside `$((...))`.** A digit check and `[ -lt 600 ]` read decimal, so an override of `08` passed both. The new `$((DEADLINE - SECONDS))` read `08` as octal and failed, so every run with that override failed. Earlier the variable was only read by `[ -ge ]`, so nothing had shown the gap. Fix: `DEADLINE=$((10#$DEADLINE))` once, after the clamp. A new arithmetic use of an old variable needs a fresh look at how the variable is validated.

**Trap 4: do not claim "spawns no grandchild".** `git status` runs a child status per submodule, and it runs an fsmonitor hook if one is set. The kill reaches only the direct child. The script still returns on time because the grandchild writes only to the killed git's output, never to a pipe the script reads. Say that in the script header instead of denying the grandchild.

**How to test it.** Use a PATH shim `git` that runs the real git, then sleeps past the deadline for selected arguments, or kills its own process with TERM for others. Run the script under a short deadline through an env override. Each such test row waits out that deadline, so the rows add real wall time. The shim sleeps after real git returns, so the watchdog always kills the call first. A per-record `expired` check that runs after the call therefore has no discriminating row in this setup. For a cheaper test of a pre-call expiry, note that bash `SECONDS` inherits from the environment, so a test can force an expired deadline without sleeping.

**Check what stays uncovered.** Only wrapped calls are bounded. Here `git rev-parse HEAD` and `git worktree list` stayed unbounded, so list every blocking call in the script and decide for each one.
