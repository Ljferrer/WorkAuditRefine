---
name: run-parallel-poll-budget-fanout-breach
description: "A per-call poll budget holds for one call; a fan-out helper with cap P runs N calls in ceil(N/P) waves"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  slug: run-parallel-poll-budget-fanout-breach
  keywords:
    - poll budget
    - fan-out serialization
    - max_parallel
    - multiprocessing
    - ECS task timeout budget
    - wave count ceil(N/P)
    - safe by construction
    - shared deadline
  tags:
    - concurrency
    - timeouts
    - audit-finding
---

**The shape.** A per-call poll/wait budget is often proven safe against an
outer timeout by a single-call argument ("polling up to 1200s fits our 3600s
ECS task budget"). That holds only when one such call is in flight at a time.
When the same call fans out through a multiprocessing helper such as
`<run_parallel>()`, which backfills up to `max_parallel=P` processes, N items
run in `ceil(N/P)` waves. Each wave can pay the full poll budget. The outer
budget is breached whenever `ceil(N/P) * per_call_budget > outer_budget`.

**Sequential composition breaks it the same way.** Calling the budgeted
primitive more than once in series inside one outer window also multiplies
the budget. A `<pipeline-step>` handler made two 1200s queue polls per item
(detect, then transcribe) inside one 3600s task. The fix shares one deadline,
derived from the invocation context, across both calls.

**Reference fix.** Size the per-call budget with a `<derive_poll_budget>()`
helper: `(task_budget - headroom) / ceil(n/p)`, capped at a default per-call
budget and floored at a minimum per-call budget, and have the per-call runner
pass the derived value.

**How to apply:** when a "safe by construction" poll budget sits behind a
fan-out helper or any bounded fan-out, or is called more than once per outer
window, count the calls per window. Check
`ceil(N/max_parallel) * per_call_budget <= outer_budget` with the realistic max
N. Better, derive the per-call budget from a shared deadline. A change to
`max_parallel` or batch size can flip a safe budget to unsafe, the same way a
concurrency knob shared by several runtimes changes all of them at once.
