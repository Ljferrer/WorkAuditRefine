---
name: agent-token-rotation-needs-authorizer-cache-ttl-zero
description: A rotated API token dies at once only if the AppSync Lambda authorizer ttlOverride and the stack resultsCacheTtl are both zero.
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - lambda authorizer
    - resultsCacheTtl
    - ttlOverride
    - token rotation
    - API token
    - appsync cache
    - revoke
    - authorizer cache
  slug: agent-token-rotation-needs-authorizer-cache-ttl-zero
  tags:
    - infra
    - appsync
    - auth
---

# Two settings keep rotation immediate

AppSync caches a Lambda authorizer result for its TTL. A cached result keeps an old API token alive after rotation.

- The authorizer returns `ttlOverride: 0` on success.
- The stack sets `resultsCacheTtl` to `Duration.seconds(0)` on the Lambda authorizer config.
- Both must stay zero. Raising either one lets a rotated token work until the cache expires.

**Why:** the authorizer cache answers before the Lambda runs, so a revoked token still passes until the entry expires.

**How to apply:** keep a test that proves rotation takes effect at once, and do not raise either TTL without a replacement revoke path.
