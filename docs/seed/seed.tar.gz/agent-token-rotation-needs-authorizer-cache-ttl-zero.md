---
name: agent-token-rotation-needs-authorizer-cache-ttl-zero
description: A rotated agent token dies at once only if the AppSync Lambda authorizer ttlOverride and the stack resultsCacheTtl are both zero.
metadata:
  node_type: memory
  slug: agent-token-rotation-needs-authorizer-cache-ttl-zero
  type: project
  keywords:
    - lambda authorizer
    - resultsCacheTtl
    - ttlOverride
    - token rotation
    - agent token
    - appsync cache
    - revoke
    - authorizer cache
  provenance: code-verified
  tags:
    - infra
    - appsync
    - auth
  created: 2026-10-27
---

# Two settings keep rotation immediate

## Fact
- AppSync caches a Lambda authorizer result for its TTL. A cached result keeps an old agent token alive after rotation.
- The authorizer returns `ttlOverride: 0` on success.
- The stack sets `resultsCacheTtl` to `Duration.seconds(0)` on the Lambda authorizer config.
- Both must stay zero. Raising either one lets a rotated token work until the cache expires.

## Guard
- Keep a test that proves rotation takes effect at once, and run it from a name-filtered acceptance check.
- A name-filtered check goes red if you rename that test. Keep the filter token in the title.
