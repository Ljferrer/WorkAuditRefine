---
name: lambda-retry-attempts-covers-async-invokes-only
description: "A Lambda retryAttempts setting applies only to async invokes; Step Functions invokes synchronously, so only its Retry blocks retry"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - retryAttempts
    - async invoke
    - synchronous invoke
    - Step Functions Retry
    - EventInvokeConfig
    - retry_attempts
  slug: lambda-retry-attempts-covers-async-invokes-only
  tags:
    - step-functions
    - lambda
    - retry
---

# A Lambda `retry_attempts` setting covers async invokes only

A config `retry_attempts` governs only asynchronous invokes.
Step Functions calls the Lambda synchronously, so the only retries are the state machine's own `Retry` blocks.

**Why:** reading the function config alone can lead to the claim "no retry" for a step while a Retry ladder in the stack code does retry it.

**How to apply:** before you write "no retry" for a Lambda step, read the stack's retry list as well as the config props.
