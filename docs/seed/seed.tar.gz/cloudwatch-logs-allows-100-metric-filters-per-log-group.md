---
name: cloudwatch-logs-allows-100-metric-filters-per-log-group
description: "CloudWatch Logs caps metric filters at 100 per log group and will not raise it, so pin a per-log-group filter count in a test"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - metric filter quota
    - 100 per log group
    - MetricFilter
    - log group
    - quota
    - filter budget test
  slug: cloudwatch-logs-allows-100-metric-filters-per-log-group
  tags:
    - cdk
    - cloudwatch
    - testing
---

# CloudWatch Logs allows 100 metric filters per log group

CloudWatch Logs allows 100 metric filters per log group, and AWS does not raise that quota. It sits below the 500-resource stack limit, so adding filters to one log group can hit it with no stack near 500.

A one-MetricFilter-per-token idiom spends this quota fast.

**Why:** the stack-size test does not see this ceiling, and the failure shows up only at deploy.

**How to apply:** if a change adds filters to any log group, also run a test that counts filters per log group against a filter budget.
