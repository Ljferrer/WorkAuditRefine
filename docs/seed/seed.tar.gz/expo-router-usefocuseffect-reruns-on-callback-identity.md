---
name: expo-router-usefocuseffect-reruns-on-callback-identity
description: "expo-router useFocusEffect re-runs its callback on every identity change while the route is focused, so a callback that depends on loaded data can clear a navigation latch."
metadata:
  node_type: memory
  type: project
  keywords:
    - useFocusEffect
    - expo-router
    - focus effect
    - useCallback deps
    - navigation latch
    - router.push
    - router.replace
    - ref instead of state
    - stale latch
  provenance: code-verified
  slug: expo-router-usefocuseffect-reruns-on-callback-identity
  tags:
    - routes
    - expo-router
    - react
---

# A focus callback with data deps re-runs while the route is still in front

## The trap
- The `useFocusEffect` bundled with expo-router (deps `[effect, navigation]`) runs its callback on mount and again whenever the callback identity or `navigation` changes, as long as `navigation.isFocused()` is true.
- `router.push` only queues a navigation. The route stays focused for at least one more commit.
- In one route, the focus callback read a loaded state value. A user action changed that state while a push to another route was pending. The callback ran again, lowered a "left this route" latch, and called `router.replace`, which raced the pending push.
- The route test mocked `useFocusEffect` to never auto-run, so no test saw it.

## Fix pattern
- Keep loaded data in a ref that the load function writes.
- Build the callback with `useCallback` over stable inputs only (here `[id, router]`), so the effect runs on real focus events.
- Use one function for every caller, such as the focus effect and a failed action's `.catch`: lower the latch, then replace if the ref says so.

## How to test
Mock `useFocusEffect` with an identity-aware `useEffect`, so the mock re-runs when the callback identity changes. Have the test's router mock return a stable object.
