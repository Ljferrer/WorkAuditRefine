---
name: plain-git-check-ignore-reads-the-index-so-a-walk-that-mirrors-ripgrep-skips-must-use-no-index
description: "Plain git check-ignore reads the index, so a hook walk that mirrors ripgrep skips must ask with --no-index"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - check-ignore
    - "--no-index"
    - ripgrep
    - grep walk-down
    - excluded dir
    - tracked content
    - vacuous fixture
  slug: plain-git-check-ignore-reads-the-index-so-a-walk-that-mirrors-ripgrep-skips-must-use-no-index
  tags:
    - hooks
    - audit
    - git
    - testing
---

# Ask git by pattern, not by index, when a hook predicts what ripgrep skips

**Rule.** A hook that must predict whether ripgrep enters a folder asks git with `check-ignore --no-index`. Plain `check-ignore` reads the index. Once any file under an excluded dir is tracked, the plain call says that dir is not ignored. ripgrep still skips it. A walk built on the plain call then under-touches, and an under-touch is a fail-open hole.

**The case.** A guard hook tracks which work trees a Grep tool call would touch, by predicting which ones the tool's ripgrep would enter. The work trees sit under `<excluded-dir>/worktrees/`, `<excluded-dir>/` is excluded, and one config file under `<excluded-dir>/` is tracked.

**Evidence.** Once a file under `<excluded-dir>/` is tracked, plain `check-ignore` calls `<excluded-dir>` not ignored. It still calls `<excluded-dir>/worktrees` ignored. `--no-index` calls both ignored.

**Why:** the index records tracked files, ripgrep does not read it, and the two answers diverge exactly where the hook needs them to agree.

**Companion traps.**
1. **Ask from the folder's parent with a `./<name>/` operand.** The `./` keeps a leading `:` from reading as pathspec magic. The trailing `/` lets a `dir/` pattern match. The repo that holds the folder answers, and git's leading-directory check makes a folder under an ignored dir ignored too.
2. **A folder with a `.git` entry is a repo root.** It is never ignored, and the hook spawns nothing for it. Any non-zero `check-ignore` exit reads as not ignored, so an error or a folder no work tree holds marks the work tree below. That is the over-touch direction.
3. **ripgrep applies no ignore rule at or below an explicit search root.** So the walk has two cases. A root at or under an ignored dir marks every work tree below it. Any other root marks a work tree unless a folder strictly below the root, on the path down, is ignored.
4. **Pin the flags with a structural test row.** `--no-index` never reads the index, so no behavior row can fail on it. The row greps the hook's non-comment `check-ignore` lines and checks that each carries the flags.

**Accepted gaps.** ripgrep honors more ignore files than git does (`.ignore`, `.rgignore`, global excludes), so the hook can mark a work tree ripgrep never enters. That is the safe side. The tool's Grep flags were read from its shipped binary strings, so re-read them at each upgrade.

**How to apply.** Before you add a hook arm that decides "would tool X enter folder F":
- Read X's ignore flags from the shipped binary.
- Ask git with `--no-index` and `-c core.fsmonitor=false`.
- Add an oracle test row that runs real git, independent of the hook, and goes red if the plain and `--no-index` answers agree.
