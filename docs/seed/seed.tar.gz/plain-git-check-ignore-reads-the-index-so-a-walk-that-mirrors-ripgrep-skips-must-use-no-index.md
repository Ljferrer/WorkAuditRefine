---
name: plain-git-check-ignore-reads-the-index-so-a-walk-that-mirrors-ripgrep-skips-must-use-no-index
description: "Plain git check-ignore reads the index, so a hook walk that mirrors ripgrep skips must ask with --no-index"
metadata:
  node_type: memory
  type: project
  keywords:
    - check-ignore
    - "--no-index"
    - ripgrep
    - grep walk-down
    - excluded dir
    - tracked content
    - fsmonitor
    - vacuous fixture
  provenance: code-verified
  slug: plain-git-check-ignore-reads-the-index-so-a-walk-that-mirrors-ripgrep-skips-must-use-no-index
  tags:
    - hooks
    - audit
    - git
    - testing
  created: 2026-10-27
---

# Ask git by pattern, not by index, when a hook predicts what ripgrep skips

**Rule.** A hook that must predict whether ripgrep enters a folder asks git with `check-ignore --no-index`. Plain `check-ignore` reads the index. Once any file under an excluded dir is tracked, the plain call says that dir is not ignored. ripgrep still skips it. A walk built on the plain call then under-touches, and an under-touch is a fail-open hole.

**The case.** A guard hook tracks which work trees a Grep tool call would touch, by predicting which ones the tool's ripgrep would enter. The work trees sit under `<excluded-dir>/worktrees/`, `<excluded-dir>/` is excluded, and one config file under `<excluded-dir>/` is tracked.

**Evidence.** Observed on git 2.54.0. Once a file under `<excluded-dir>/` is tracked, plain `check-ignore` calls `<excluded-dir>` not ignored. It still calls `<excluded-dir>/worktrees` ignored. `--no-index` calls both ignored.

**Companion traps.**
1. **Run every `check-ignore` with `-c core.fsmonitor=false`.** `check-ignore` and `ls-files -v` each run a configured `core.fsmonitor` command, as `status` does. `GIT_OPTIONAL_LOCKS=0` does not stop them. `rev-parse`, `worktree list` and `hash-object` never run it.
2. **Ask from the folder's parent with a `./<name>/` operand.** The `./` keeps a leading `:` from reading as pathspec magic. The trailing `/` lets a `dir/` pattern match. The repo that holds the folder answers, and git's leading-directory check makes a folder under an ignored dir ignored too.
3. **A folder with a `.git` entry is a repo root.** It is never ignored, and the hook spawns nothing for it. Any non-zero `check-ignore` exit reads as not ignored, so an error or a folder no work tree holds marks the work tree below. That is the over-touch direction.
4. **ripgrep applies no ignore rule at or below an explicit search root.** So the walk has two cases. A root at or under an ignored dir marks every work tree below it. Any other root marks a work tree unless a folder strictly below the root, on the path down, is ignored.
5. **Place the tracked fixture file off the walk path.** Commit `<excluded-dir>/config.json`, never a file under `<excluded-dir>/worktrees/`. A tracked file under the walk path makes plain `check-ignore` call every folder on that path not ignored. The test row would then pass under the regression it exists to catch.
6. **Pin the flags with a structural test row.** `--no-index` never reads the index, so no behavior row can fail on it. The row greps the hook's non-comment `check-ignore` lines and checks that each carries both flags.
7. **Make each negative row prove it can fail.** It first asserts the work tree is in the start record, so the "not touched" check has something to miss.

**Accepted gaps.** ripgrep honors more ignore files than git does (`.ignore`, `.rgignore`, global excludes), so the hook can mark a work tree ripgrep never enters. That is the safe side, but a sibling's normal edit can then trip a false tamper alert. The tool's Grep flags were read from its shipped binary strings, so the rule is bound to that version. Re-read them at each upgrade.

**How to apply.** Before you add a hook arm that decides "would tool X enter folder F":
- Read X's ignore flags from the shipped binary.
- Ask git with `--no-index` and `-c core.fsmonitor=false`.
- Add an oracle test row that runs real git, independent of the hook, and goes red if the plain and `--no-index` answers agree.
- Put the tracked fixture file off the walk path.
