---
name: negative-grep-guard-can-trip-on-prose-comment
description: "A negative-grep drift guard can trip on a prose comment with the same literal; reword the comment, keep the guard"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  slug: negative-grep-guard-can-trip-on-prose-comment
  keywords:
    - negative grep guard
    - drift guard false positive
    - confinement test
    - prose comment collision
    - regex over source text
    - tokenize
    - guard authoring pattern
  tags:
    - test-authoring
    - audit-finding
    - pattern
---

## The rule

A negative-grep guard (e.g. `test_<literal>_is_confined_to_<N>_sites`) that
runs a regex over raw source text cannot tell code from a comment that names
the guarded literal. It will flag the comment as a new site.

- Fix it in the guard: strip comments with Python's `tokenize`, not with a
  regex `#` carve-out. A regex carve-out is fooled by `#` inside strings and
  becomes an escape hatch.
- Joining logical lines (bracket continuations) also stops a
  split-across-lines statement from hiding.
- Docstrings and string literals are still tokens, so they still match. In
  those, paraphrase the literal (say "an explicit false opt-out", not the
  literal assignment).
- Keep a raw-line fallback when the tokenizer fails, never a silent skip.

**Why:** a raw-text guard fired on a comment during a feature build.
Rewording fixed that one hit, but the next comment would trip it again.

**How to apply:** when you write a confinement or negative-grep guard over
Python source, scan tokenized logical lines with `COMMENT` tokens removed,
via a small `<logical_lines>()` helper.
