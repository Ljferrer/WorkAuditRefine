---
name: a-dirname-ancestor-walk-never-terminates-on-a-relative-path
description: "A shell loop that walks up with dirname and stops only at / never ends on a relative path; add a progress guard"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - infinite loop
    - dirname walk
    - progress guard
    - hook stall
    - relative path
    - never terminates
    - parent dir traversal
  slug: a-dirname-ancestor-walk-never-terminates-on-a-relative-path
  tags:
    - hooks
    - bash
    - gotcha
---

An ancestor walk shaped like this never terminates for a relative path:

```sh
while [ "$d" != "/" ] && [ -n "$d" ]; do ... d="$(dirname "$d")"; done
```

`dirname` of a relative path converges to `.`, and `dirname .` is `.`. It never reaches `/`, so the loop spins forever. In a PreToolUse hook that stalls every Write/Edit.

**Fix:** a progress guard.

```sh
prev=""
while [ -n "$d" ] && [ "$d" != "$prev" ]; do
  [ -e "$d/.marker" ] && exit 0
  [ "$d" = "/" ] && break
  prev="$d"; d="$(dirname "$d")"
done
```

The `prev` guard stops the loop once `dirname` stops making progress, at `.` or `/`.

**Why:** a hook payload's `file_path` can be relative, and pasted shell that assumes absolute input compiles and looks right but hides the infinite loop.

**How to apply:** for any `dirname`-based ancestor walk in shell, never gate solely on `[ "$d" != "/" ]`. Either normalize to an absolute path up front, or add a `prev` progress guard. Add a regression test for the relative-path case.
