---
name: negative-assert-on-a-fixture-that-cannot-carry-the-offender-is-vacuous-and-a-label-count-a-fix-round-also-satisfies
description: "A negative assertion on a fixture that cannot contain the offender cannot fail, and a label count that a retry also reaches proves nothing"
metadata:
  node_type: memory
  slug: negative-assert-on-a-fixture-that-cannot-carry-the-offender-is-vacuous-and-a-label-count-a-fix-round-also-satisfies
  type: project
  keywords:
    - vacuous negative assertion
    - fixture cannot carry the row
    - label count witness
    - fix round relabel
    - discriminating witness
    - weak test
    - delete the feature
    - retired text grep guard
    - add-only surface
    - old-absent half
    - mutation test
  provenance: code-verified
  tags:
    - testing
    - assertion-strength
  created: 2026-10-21
---

# Three vacuous-test shapes

All three test assertions looked strong and could not fail for the reason they named.

**Shape 1: a negative assertion over a fixture that cannot carry the offender.** A spec says that with a feature flag off, the system assigns no specialist reviewer. The first test asserted that no call matched the specialist reviewer, on a fixture whose roster held one ordinary reviewer. No code path adds a roster row by itself, so the assertion passed whatever the code did.
- Check before trusting "X is absent": can the fixture even contain X? If the input never carries it and the code never invents it, the assertion is true by construction.
- Fix: add a fixture that can produce the offender. Here, a lone reviewer at low confidence nominates the specialist through an escalation path. With the specialist barred, the code falls back to the default roster, and the assertion now has something to fail on.

**Shape 2: a label-count witness that a retry also reaches.** A test proved "the escalation path ran" by seeing a dispatch label at least twice. The lone reviewer requested changes, so the fix pass and the full re-review applied that label a second time even with the escalation branch deleted. The count could not see a removed branch.
- Fix: witness the branch itself. The code logs a specific line only inside the escalation branch, and a different line only when the nomination was not barred. The test asserts the first and refuses the second.
- Rule: a witness for "path P ran" must be a side effect that only P produces. A repeated dispatch label is shared by every path that re-runs the step.

**Check each arm by mutation.** When a test has several arms, make a mutation that should turn only one arm red, and confirm that it does before you call that arm covered. A weak line left beside a discriminating witness can make a test look weaker than it is, so read the whole test.

**Shape 3: an old-text-absent check on an add-only surface.** A doc grep guard gives each surface two halves: retired text absent, new text present. Some surfaces only ever added text, such as a new section or a dated note. On those rows the retired sentences were never there, so the absent half cannot go red today.
- That half still guards the future: it goes red if someone later writes the retired text into that region. It just cannot catch a stale surface.
- What carries the row is the new-text-present half plus fail-closed extraction. A missing anchor throws, an empty region fails, and an empty token list fails.
- A shared token read from the code under test at load time sits in a try/catch. On failure, every row that needs it gets a sentinel no file contains. Each row then fails on its own line, and the whole test file never dies at import.
- Rule: when you review a retire-the-text grep guard, find the rows whose old half the surface never held. Judge those rows only by their new half.

**Why.** A test that cannot go red gives false confidence in the exact behavior it names.

**How to apply.** Delete the feature in your head, or by mutation. The assertion must fail. If it still passes, change the fixture or the witness.
