---
name: cdk-closed-set-and-conjunct-isolation-test-pattern
description: a CDK synth test needs an exact closed-set pin and one test per alarm-gate conjunct
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  slug: cdk-closed-set-and-conjunct-isolation-test-pattern
  keywords:
    - CDK synth test
    - closed set assertion
    - conjunct isolation test
    - alarm shape
    - CloudWatch alarm Metrics MetricStat
    - test fidelity
    - sensitivity control
    - negative test per condition
  tags:
    - autoindex
    - testing
    - cdk-synth
    - test-fidelity
    - pattern
---

A CDK synth test suite for a Step Functions/ECS step closed three related
test-fidelity gaps, each raised independently across several audit rounds.

**Closed-set pin.** An End state that says "no ASL or task-definition key
changes beyond the named additions" needs
`assert set(run['Parameters']) == <EXPECTED_PARAMETER_KEYS>` (and the same for
override env names), not just an assert that the named keys are present. A
presence-only check lets an unrelated key leak in without failing.

**Conjunct isolation.** An alarm built behind several AND'd conditions (e.g. a
runtime check, a feature flag on the step, and a gate pair resolving true)
needs one test per conjunct that flips that one condition off and asserts the
alarm and its filters are absent. One combined-positive test proves nothing
about which conjunct is load-bearing.

**Shape coverage.** A test helper that detects an alarm by CloudFormation shape
(first matching only a `Metrics[].MetricStat.Metric.Namespace` array) can miss
the same alarm rendered as a plain `cloudwatch.Metric` with a top-level
`Properties.Namespace`. Widen the helper to match both forms.

**How to apply.** When an End state says "no other key changes," pin the
closed key set with `==`, never with `in` or a presence check. When an alarm's
build predicate has more than one AND'd condition, write one negative test per
conjunct. When writing a CFN-shape detector for an alarm or filter, check
whether the resource can render in more than one shape, and match all of them.
An absence assertion also needs a positive sensitivity control: a sibling test
proving the detector finds the resource when it should exist.
