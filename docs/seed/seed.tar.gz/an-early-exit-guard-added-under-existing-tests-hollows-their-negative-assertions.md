---
name: an-early-exit-guard-added-under-existing-tests-hollows-their-negative-assertions
description: "A new early-exit guard makes old 'nothing written' assertions pass because the guard refuses first, so re-aim each fixture at the guarded branch"
metadata:
  node_type: memory
  slug: an-early-exit-guard-added-under-existing-tests-hollows-their-negative-assertions
  type: project
  keywords:
    - vacuous assertion
    - early exit guard
    - negative assertion
    - never mkdir
    - fixture move
    - existsSync
    - sibling sweep
    - path anchor refusal
    - test erosion
  provenance: code-verified
  tags:
    - testing
    - guard
    - fix-round
  created: 2026-10-28
---

# A new early-exit guard hollows the old "nothing was written" tests

**Pattern.** You add a guard that returns early on an input shape. Old tests that assert a negative ("no log written", "no directory created") may now pass because the guard refused first. They no longer reach the branch they were written to watch.

**What happened.** A change added `<path_guard>()`, which refuses a directory path outside a required anchor, and moved the test fixtures under that anchor.
- One test built a missing path as `join(local, 'no-such-dir')`. That path no longer ended in the anchor, so the guard refused it before `fs.statSync`. The assertion `!existsSync(missing)` passed with or without a `mkdirSync` mutation. It was the only oracle for a never-create-the-directory rule.
- The fix repaired that test and missed its sibling. The sibling still used a bare temp directory, so its `!existsSync(join(local, <log_file>))` held because the guard refused the append, not because the feature-disabled branch writes nothing. A later review caught it.

**Why the first sweep missed it.** The fixer listed the absent-log assertions but did not ask whether the new guard now refused each one.

**How to apply.**
- After you add an input-shape guard, list every test that asserts an absence. For each one, check that its input passes the new guard, so the code under test still runs.
- Build the negative fixture so it passes the guard and stays absent for the right reason. For a missing directory, use a path that matches the anchor and does not exist.
- Delete the feature in your head. For a never-create rule, insert a `mkdirSync` after the guard. The test must go red.
- Keep one positive case beside the negative: a refused append still returns its normal result, and an accepted one writes a line.
