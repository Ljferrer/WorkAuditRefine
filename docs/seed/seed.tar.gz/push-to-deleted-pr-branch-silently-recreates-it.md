---
name: push-to-deleted-pr-branch-silently-recreates-it
description: "Push after PR merge recreates dead branch, misses PR"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - git push
    - new branch token
    - merged PR
    - deleted branch
    - cherry-pick
    - stale local ref
    - PR comment succeeds
  slug: push-to-deleted-pr-branch-silently-recreates-it
---

A `git push` issued moments after a PR merged and its remote branch was deleted **recreates the dead branch** with exit 0. The commit never enters the PR, and even `gh pr comment` on the merged PR still succeeds, so nothing errors. The one tell: the push output says `* [new branch]` for a branch you believe already exists remotely.

**Why:** both tool outputs read as success, so the miss goes unnoticed until someone points it out.

**How to apply:** when pushing a follow-up to a PR branch, check the PR state **before** the push, as its own command: `gh pr view <n> --json state`. Chained *after* the push in one compound command, it detects the miss but does not prevent it. Treat `[new branch]` in the push output as the tell. If the PR merged, cherry-pick the commit onto a fresh `origin/<base>`, open a new PR, and delete the resurrected branch. Verify its only unique commits are the cherry-picked ones via `git rev-list <branch> ^origin/<base>`.
