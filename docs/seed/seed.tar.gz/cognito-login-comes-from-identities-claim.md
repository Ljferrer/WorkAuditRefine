---
name: cognito-login-comes-from-identities-claim
description: "Read a Cognito caller's GitHub login from the identities claim, never from the user-writable preferred_username."
metadata:
  node_type: memory
  type: project
  keywords:
    - cognito
    - identities claim
    - preferred_username
    - github login
    - impersonation
    - appsync identity
    - oidc shim
    - federated identity
    - user attribute
  provenance: code-verified
  slug: cognito-login-comes-from-identities-claim
  tags:
    - infra
    - security
    - auth
    - cognito
---

# Trust `identities[0].userId`, not `preferred_username`

## Fact
- The Cognito user pool maps `preferred_username` from the OIDC shim's claim, so a user can later rewrite that attribute.
- The `identities` claim records the federated subject from the shim's `sub`, and the user cannot rewrite it.
- The Lambda router takes the login from `identities[0].userId` only when that entry's `providerName` is `GitHub`.
- A caller with no `identities` claim, or another provider's entry, is rejected.
- AppSync may pass `identities` as a JSON string, so the router parses it before use.
