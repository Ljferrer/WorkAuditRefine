---
name: a-base-resolved-by-bare-name-needs-a-local-ref-not-only-origin
description: "A base resolved by bare name needs a local ref, and a sha:refs/heads push creates only the remote one"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - local ref
    - origin-only branch
    - not a valid object name
    - git branch base
    - git push refs/heads
    - needed a single revision
    - stacked branch cut
  slug: a-base-resolved-by-bare-name-needs-a-local-ref-not-only-origin
  tags:
    - git
    - branches
    - provisioning
---

# A script that cuts a branch from a bare base name needs a local ref

**Symptom.** `git branch <new-branch> <base>` fails with `fatal: not a valid object name: '<base>'`. `git rev-parse --verify <base>` says `fatal: Needed a single revision`.

**Cause.** `<base>` exists only on origin. A `git push origin <sha>:refs/heads/<base>` creates the remote ref and no local one, and a bare name resolves only locally.

**Fix.** Create the local ref at the intended tip, then retry:
```
git branch <base> <tip-sha>
git rev-parse --verify <base>    # now resolves
```
Keep it checked out nowhere.

**Why:** the push gives you only the origin half of the branch. Any later step that resolves the base by bare name needs the local half too.

**How to apply:** when you cut a branch from another branch's tip, run `git branch <new> <tip-sha>` and then `git push origin <new>`. That gives both a local ref and the origin branch. A direct `git push origin <sha>:refs/heads/<new>` gives only the origin ref.
