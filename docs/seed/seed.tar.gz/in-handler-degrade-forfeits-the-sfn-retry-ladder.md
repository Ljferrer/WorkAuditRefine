---
name: in-handler-degrade-forfeits-the-sfn-retry-ladder
description: "Turning a raise into an in-handler degrade forfeits the Step Functions retry ladder, so a transient fault longer than the handler's own backoff budget drops data"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - Step Functions retry
    - add_retry
    - degrade instead of raise
    - exponential backoff
    - jitter
    - Lambda timeout budget
    - retry ladder
  slug: in-handler-degrade-forfeits-the-sfn-retry-ladder
  tags:
    - step-functions
    - lambda
    - retry
---

A Lambda step can fail in two ways.
It can raise, and the state machine's Retry blocks then re-run it.
It can degrade in place, which means it catches the fault, drops the affected item, logs a token, and returns normally.
A degrade never reaches the Retry blocks.

Example: a handler replaced a raise with a degrade. The degrade retried the page read with capped exponential backoff and jitter inside a 60 second budget.
The old raise rode a Step Functions ladder of about 310 seconds of waits (5 attempts, 10 second interval, backoff rate 2).
So a transient database or object store fault longer than about 60 seconds now drops the item.
An alarm reports the drop and a runbook says to re-run the job.
A waking Aurora cluster or Data API throttling can take tens of seconds to clear, so this is realistic.

**Budget arithmetic:** the handler's read budget plus a reserve for prompt building must stay at or under the Lambda timeout.
A unit test should pin that sum against the configured timeout.
The budget bounds the sleeps, not the last read, so one read that starts inside the budget can finish past it.
A hard cap needs a remaining-time argument passed down through the shared query helpers.

**Why:** a degrade trades the state machine's long retry ladder for the handler's own short budget, so transient faults that the ladder would have absorbed now lose data.

**How to apply:**
- When a change turns a raise into a degrade, list which retries the raise used to get.
- Size the degrade's wait against that ladder, or keep the raise for transient fault classes.
- If you change the budget, re-run the test that pins it against the Lambda timeout.
