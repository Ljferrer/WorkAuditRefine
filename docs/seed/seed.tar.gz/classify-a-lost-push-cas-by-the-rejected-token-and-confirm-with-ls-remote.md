---
name: classify-a-lost-push-cas-by-the-rejected-token-and-confirm-with-ls-remote
description: "Push first, then advance the local ref only after ls-remote confirms; classify a lost push by the [rejected] token, never by non-fast-forward"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - compare-and-swap
    - non-fast-forward
    - rejected token
    - follower ref
    - ls-remote verify
    - concurrent runs
    - git push
  slug: classify-a-lost-push-cas-by-the-rejected-token-and-confirm-with-ls-remote
  tags:
    - CAS
    - git-push
    - shell
---

**Rule.** Use the push as the compare-and-swap. Push first with the named-source form (`git push origin HEAD:refs/heads/<branch>`). Advance the local ref only after an exit-0 push AND `git ls-remote origin` confirms origin holds `<new-sha>`. Classify a rejected push by the `[rejected]` token. Never classify by `"non-fast-forward"`, which is not reliably emitted. Never infer success from the absence of `[rejected]` alone.

**Why:** keying on the wrong token misroutes a lost race between "retry on the new tip" and "escalate".

**How to apply:** treat `[rejected]` as "another writer won, so rebase and retry". Treat any other failure, an unresolvable HEAD or `<new-sha>`, or an origin that does not hold the new sha after the push as "escalate". Trust only `[rejected]` plus exit codes.
