---
name: trailing-newline-deny-row-cannot-go-red-test-the-interior-newline-bypass
description: A trailing-newline deny row in a command guard can never pass; the real bypass is an interior newline joining two commands
metadata:
  node_type: memory
  slug: trailing-newline-deny-row-cannot-go-red-test-the-interior-newline-bypass
  type: project
  keywords:
    - read-only git guard
    - newline bypass
    - command substitution
    - trailing newline stripped
    - chain-operator rule
    - bash 3.2
    - deny test row
  provenance: code-verified
  tags:
    - hooks
    - command-guard
    - test-fixtures
    - bash
  created: 2026-10-20
---

# A trailing-newline deny row proves nothing; test the interior newline

**Gotcha.** A guard hook that allows only read-only git commands reads its command with `cmd="$(get '.tool_input.command')"`. Bash strips trailing newlines from `$(...)`. So `git diff HEAD` plus a trailing newline reaches the guard as one bare read command. That is no bypass. A test row that asserts exit 2 for it can never be met. Drop such a row and say why in a comment.

**The real bypass.** A newline joins a second command. The guard's residue assignment also strips a newline-only residue to empty. So the verb parser saw only the first verb. `git log HEAD`, newline, `git push` read as allowed through the `log\ *` verb arm. That claim came from reading the guard, not from a re-run.

**Fix and tests.**
- Add an explicit `case "$cmd" in *$'\n'*)` pre-check before the residue assignment.
- Route it to the existing chain-operator deny text.
- Pin it with test rows: `git log HEAD`, newline, `git push`; the same with `echo pwned` as the second command; the deny text does not name the metacharacter rule; the deny text teaches "one bare git command".

**Two traps.**
- The pre-check's deny text is a hand copy of the classifier's chain-operator literal. Pin the teaching text on the copy too.
- Sibling comments saying "the char check is the first check after the empty-command guard" went stale once the pre-check landed. Grep ordering claims when you insert a check.

**Test-writing note.** Write the payload as JSON with an escaped newline inside the printf string. The hook then decodes a real newline.
