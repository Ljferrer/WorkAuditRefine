---
name: a-one-holder-guard-must-collect-a-list-and-count-duplicate-json-keys-in-the-text
description: A test that exactly one entry holds some keys must collect (name, keys) pairs in a list and count the quoted key in the file text
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - duplicate holder
    - dict collapse
    - duplicate JSON key
    - json.loads last wins
    - text count
    - config guard
  slug: a-one-holder-guard-must-collect-a-list-and-count-duplicate-json-keys-in-the-text
  tags:
    - drift-guard
    - config
    - test-fidelity
---

A test that says "exactly one config entry ships these switch keys" has two traps.

1. **Name-keyed dict.** A walk that stores `holders[name] = keys` merges two entries that share a name. `len(holders) == 1` then passes with two holders. Return a list of `(name, keys)` pairs and assert `[name for name, _ in holders] == [EXPECTED_ENTRY]`.
2. **Duplicate keys in one object.** `json.loads` (and JS `JSON.parse`) keeps the last of two equal keys in the same JSON object. Neither a dict nor a list of holders can see the first. Only a count of the quoted key in the file text can.

**Why:** both traps let a guard pass while two holders exist.

**How to apply:**
- Write a new "one entry holds these keys" guard with a list of `(name, keys)` pairs.
- If duplicate keys in one object matter, add a text count of the quoted key.
- When a new guard turns out to have trap 1, sweep older sibling guards built the same way; the fix does not reach them on its own.
