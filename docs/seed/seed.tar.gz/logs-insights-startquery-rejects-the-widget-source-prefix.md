---
name: logs-insights-startquery-rejects-the-widget-source-prefix
description: "CloudWatch Logs Insights StartQuery rejects the dashboard widget form's SOURCE prefix and a query that opens with a pipe, so run any printed query through StartQuery once before a runbook depends on it"
metadata:
  node_type: memory
  type: project
  keywords:
    - Logs Insights
    - StartQuery
    - SOURCE command
    - MalformedQueryException
    - logGroupNames
    - runbook query
    - dashboard widget
  provenance: code-verified
  slug: logs-insights-startquery-rejects-the-widget-source-prefix
  tags:
    - monitoring
    - logs-insights
    - cloudwatch
---

**Rule.** Run a Logs Insights query that a tool prints through `StartQuery` once before a runbook depends on it. The dashboard widget form and the API form differ.

`StartQuery` rejects the widget form's `SOURCE '<log group>'` prefix with `MalformedQueryException`. It also rejects a query that opens with `|`. Pass log groups as `--log-group-names` and open the query with `fields`.

**Noisy tokens.** Tokens that log constantly get no clause in a "was anything lost" query. Otherwise the answer "no rows" could never hold.

**How to apply.**

1. Test each printed query with a real `StartQuery` call in the target region before documenting it.
2. Read a result only when `status` is `Complete`.
3. Check coverage before you trust an empty result. A zero on tokens or on log groups proves nothing.
4. Keep the log group list separate from the query text so the same query works in the console and through the API.
