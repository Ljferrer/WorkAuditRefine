---
name: a-trailer-in-its-own-paragraph-is-unparsed-when-an-attribution-paragraph-follows
description: A trailer set as its own paragraph is lost once an agent appends a Co-Authored-By paragraph
metadata:
  node_type: memory
  slug: a-trailer-in-its-own-paragraph-is-unparsed-when-an-attribution-paragraph-follows
  type: project
  keywords:
    - git trailers last paragraph
    - trailer unparsed
    - Co-Authored-By paragraph
    - own final paragraph
    - one final trailer block
    - interpret-trailers
    - commit message shape
  provenance: code-verified
  tags:
    - git
    - prompts
  created: 2026-10-30
---

# A trailer in its own paragraph is unparsed when an attribution paragraph follows

**The git fact.** `%(trailers:...)` and `git interpret-trailers` read trailers only from the last paragraph of a commit message.
A trailer line in any earlier paragraph is plain body text to git.

**The trap.** A prompt told an agent to put a machine-read trailer, `<Tool-Trailer>:`, in its "OWN final paragraph".
Agents then append a separate `Co-Authored-By` paragraph after it.
The machine-read trailer is no longer in the last paragraph, so every trailer read returns nothing.

**Example.** One commit carried `<Tool-Trailer>: <value>`, then a blank line, then a `Co-Authored-By` paragraph.
`%(trailers:key=<Tool-Trailer>,valueonly)` returned nothing for it, so a counter seeded from that trailer read 0, not 1.
A later commit kept the trailer in the same block as `Co-Authored-By`, and it parsed.

**The fix.** Ask for "one final trailer block" that holds every trailer, attribution lines included.
Never ask for a trailer "paragraph" of its own.

**Rule.** If a machine reads a trailer, ask for one final block with all trailers.
If you test a trailer read, include a fixture with an attribution paragraph after the trailer.
