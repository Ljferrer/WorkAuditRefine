---
name: read-only-git-commands-can-write-the-index-or-run-fsmonitor
description: "A read-only git call in a live worktree can write its index or run core.fsmonitor, so pass GIT_OPTIONAL_LOCKS=0 and -c core.fsmonitor=false"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - GIT_OPTIONAL_LOCKS
    - no-optional-locks
    - index.lock
    - git status
    - stale index
    - core.fsmonitor
    - check-ignore
    - ls-files -v
    - sibling worktree
    - read-only git
  slug: read-only-git-commands-can-write-the-index-or-run-fsmonitor
  tags:
    - hooks
    - git
    - worktree
    - concurrency
---

# A "read-only" git call is not read-only: it can lock a live index or run fsmonitor

**Rule.** When a hook or script runs `git status` in worktrees it does not own, export `GIT_OPTIONAL_LOCKS=0` (git's `--no-optional-locks`). Without it, `status` refreshes a stat-stale index and writes it back under `<gitdir>/index.lock`. A concurrent `git add`, `git commit` or `git rebase` in that worktree then dies with `index.lock: File exists`.

**fsmonitor.** `check-ignore`, `ls-files -v` and `status` each run a configured `core.fsmonitor` command. `GIT_OPTIONAL_LOCKS=0` does not stop that. Pass `-c core.fsmonitor=false` on those calls. `rev-parse`, `worktree list` and `hash-object` never run it.

**Why:** a guard hook that fingerprints worktree state can run `status` in every task worktree, including ones where other agents are working. The output is the same either way, so the opt-out costs nothing.

**How to apply:**
- Set both opt-outs on every git call a hook makes in a worktree it does not own.
- Test with the right oracle. A pre-existing `index.lock` is NOT the oracle: `git status` skips the refresh silently when it cannot take the lock, in both modes, so that test row never goes red.
- The working oracle:
  - Give a tracked file an old mtime (content unchanged) to stale the index.
  - Run each code path that calls `git status`.
  - Compare `cksum` of the index before and after.
  - Run a plain `git status` afterward as the sensitivity check: it must write the stale index, or the oracle is vacuous.
