---
name: s3-getobject-without-listbucket-answers-a-missing-key-with-403
description: "Without s3:ListBucket, GetObject on a missing key returns 403 AccessDenied, not 404, so an absent-code allowlist never matches"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - s3:ListBucket
    - AccessDenied
    - 403 vs 404
    - GetObject
    - IAM
    - missing key
    - NoSuchKey
    - s3:prefix
  slug: s3-getobject-without-listbucket-answers-a-missing-key-with-403
  tags:
    - s3
    - iam
    - gotcha
---

# GetObject without ListBucket answers a missing key with 403

**Rule.** S3 returns `403 AccessDenied`, not `404 NoSuchKey`, for `GetObject` on a missing key when the role lacks `s3:ListBucket` on the bucket. An allowlist like `ABSENT_CODES = ('NoSuchKey', 'NoSuchBucket', '404')` then never matches, and the "absent" branch is unreachable.

**Why:** a 403 hides the real cause, so an IAM gap can pass for a denied object, or a missing object can pass for a permissions fault.

**How to apply:**
- Grant `s3:ListBucket` on the bucket, scoped by an `s3:prefix` condition to `<prefix>/*`.
- Have the reader use a plain boto3 client that checks the error code against `ABSENT_CODES`.
- When debugging an unexpected 403 on a read, or writing an IAM policy for a reader, check this grant first.
