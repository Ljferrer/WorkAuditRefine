---
name: xargs-word-splits-on-spaces-so-a-newline-path-list-needs-a-read-loop
description: "Piping a newline-joined path list through xargs splits on every space, so iterate with while IFS= read -r instead"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - xargs
    - word splitting
    - spaces in paths
    - while read
    - IFS
    - newline list
    - ls -t
  slug: xargs-word-splits-on-spaces-so-a-newline-path-list-needs-a-read-loop
  tags:
    - shell
    - xargs
    - word-splitting
---

# `xargs` word-splits on all whitespace, not just newlines

**Rule.** A script that builds a newline-joined path list and pipes it through `xargs` (for example `printf '%s' "$list" | xargs ls -t`) splits on every space as well. A path or directory name containing a space fragments into several arguments and breaks the pass. A comment that rules out newlines in names says nothing about spaces: `IFS` newline splitting and `xargs` word splitting are different mechanisms.

**Why:** roots such as a session working directory are externally supplied, so spaces are not within the script's control.

**How to apply:**
- When you review a newline-joined list piped to `xargs` for a sort, filter or batch call, check whether the comment that justifies newline splitting also covers spaces.
- Iterate the list directly with `while IFS= read -r path; do ...; done`, or feed `ls -t` through a here-string, so no word-splitting seam exists.
