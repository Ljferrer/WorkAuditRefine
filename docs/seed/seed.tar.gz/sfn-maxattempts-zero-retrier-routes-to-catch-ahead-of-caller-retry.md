---
name: sfn-maxattempts-zero-retrier-routes-to-catch-ahead-of-caller-retry
description: "A leading MaxAttempts: 0 retrier makes Catch fire at once, ahead of a later States.ALL retrier"
metadata:
  node_type: memory
  type: project
  provenance: "code-verified (throwaway synth, Sept 2026; rendered Retry [(<fallback-errors>, 0), (States.ALL, 5)] and Catch <fallback-errors> -> on-demand twin)"
  slug: sfn-maxattempts-zero-retrier-routes-to-catch-ahead-of-caller-retry
  keywords:
    - MaxAttempts 0
    - Retry
    - Catch
    - States.ALL
    - Fargate Spot
    - on-demand fallback
    - SpotInterrupted
    - capacity provider strategy
    - CDK Chain.custom
  tags:
    - step-functions
    - ecs
    - fargate
    - cdk
---

A shared ECS task factory had an error-states contract that lets callers
attach a `States.ALL` retrier to every run state. A Spot-to-on-demand fallback
Catch on the Spot state would never fire for `SpotInterrupted`, because that
caller retrier claims it first. Fix: the factory (`<pkg>/<ecs_task_factory>.py`)
adds `spot_task.add_retry(errors=FALLBACK_ERRORS, max_attempts=0)` before
returning. Step Functions matches retriers in order, uses only the first match,
retries zero times, and falls to the Catch.

Also verified: a custom `IEcsLaunchTarget` whose `bind` returns
`CapacityProviderStrategy` renders no `LaunchType` (use this for a Fargate
capacity-provider launch target).
`sfn.Chain.custom(stage_task, [spot_task, twin_task], twin_task)` starts at
the stage task and makes a caller's `.next()` bind both end states.

**Why:** Fargate never replaces Spot with on-demand (ECS docs), and a retrier
matches on error name only, so a throttle and a capacity shortage are
indistinguishable at the Spot state.

**How to apply:** keep the throttle retrier off the Spot state (put it on the
on-demand twin). In the original instance the fallback error set was
`ECS.AmazonECSException`, `AmazonECS.Unknown`, `SpotInterrupted`,
`States.HeartbeatTimeout`; put its `MaxAttempts: 0` retrier ahead of any
caller retrier.
