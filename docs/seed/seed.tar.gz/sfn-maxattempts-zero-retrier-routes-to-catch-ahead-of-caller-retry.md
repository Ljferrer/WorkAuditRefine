---
name: sfn-maxattempts-zero-retrier-routes-to-catch-ahead-of-caller-retry
description: "A leading MaxAttempts: 0 retrier makes Catch fire at once, ahead of a later States.ALL retrier"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - MaxAttempts 0
    - Retry
    - Catch
    - States.ALL
    - Fargate Spot
    - on-demand fallback
    - SpotInterrupted
  slug: sfn-maxattempts-zero-retrier-routes-to-catch-ahead-of-caller-retry
  tags:
    - step-functions
    - ecs
    - fargate
    - cdk
---

A shared ECS task factory lets callers attach a `States.ALL` retrier to every run state. A Spot-to-on-demand fallback Catch on the Spot state would then never fire for `SpotInterrupted`, because that caller retrier claims it first. Fix: the factory adds `spot_task.add_retry(errors=FALLBACK_ERRORS, max_attempts=0)` before returning. Step Functions matches retriers in order, uses only the first match, retries zero times, and falls to the Catch.

**Why:** Fargate never replaces Spot with on-demand (ECS docs), and a retrier matches on error name only, so a throttle and a capacity shortage are indistinguishable at the Spot state.

**How to apply:** keep the throttle retrier off the Spot state (put it on the on-demand twin). Put the `MaxAttempts: 0` retrier for the fallback error set ahead of any caller retrier. The set here was `ECS.AmazonECSException`, `AmazonECS.Unknown`, `SpotInterrupted`, `States.HeartbeatTimeout`.
