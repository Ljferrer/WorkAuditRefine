---
name: cross-process-hash-probe-seeded-children-timeout-salted-job-name
description: A cross-process request_hash test runs children under distinct PYTHONHASHSEED values with a timeout and expects the job_name to differ
metadata:
  node_type: memory
  type: project
  keywords:
    - PYTHONHASHSEED
    - cross-process hash
    - request_hash stable
    - subprocess probe
    - TimeoutExpired
    - salted job_name
    - set order dependency
    - hash stability test
  provenance: code-verified
  slug: cross-process-hash-probe-seeded-children-timeout-salted-job-name
  tags:
    - testing
    - fixture
---

A durable-identity fix can rest on one fact: a restarted task rebuilds the
same `request_hash`, so it finds the same pending marker. An in-process test
cannot prove that; prove it across real processes.

**The probe shape.**
- Start two fresh interpreters with `subprocess.run`. Each imports the test
  module and calls a probe function that builds the payload through the real
  code, then prints one JSON line.
- Run each child under its own `PYTHONHASHSEED` (e.g. `'1'` and `'2'`) and a
  `timeout=` (e.g. 120). Python salts `str` hashing per process, so `set`
  iteration order differs between seeds; an ambient fixed seed, or an unseeded
  `for _ in range(2)` loop, can hide a set-order dependency in the hash input.
  A hung child without a timeout stalls the gate.
- The JSON carries the hash plus whatever proves the hash covered the right
  input (e.g. a count of the payload parts the hash must include).

**The asserts.**
- The payload carries the expected parts, so the hash covers them.
- The two `request_hash` values are equal.
- Any per-submit salted field (e.g. a `job_name` minted with a uuid) differs
  between the children, and the hash excludes it. A field like that cannot be
  rederived after a restart, so it must be persisted with the marker.

**Twin test files.** When two code paths share this contract, harden both test
files in the same change; a fix applied to one twin (seeds, timeout) easily
leaves the other with the weaker unseeded loop.
