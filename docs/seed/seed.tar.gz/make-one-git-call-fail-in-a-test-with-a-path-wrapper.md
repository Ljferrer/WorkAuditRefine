---
name: make-one-git-call-fail-in-a-test-with-a-path-wrapper
description: "To test a single git failure arm, put a git wrapper first on PATH that exits 128 for the exact call and delegates every other call"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - PATH shim
    - fault injection
    - git wrapper
    - exit 128
    - failure arm test
    - prove it red
  slug: make-one-git-call-fail-in-a-test-with-a-path-wrapper
  tags:
    - git
    - tests
    - shell
---

# Make one git call fail in a test with a PATH wrapper

A failed-git arm (for example a failed `rev-list` walk) can look untestable. It is not.

**How to apply:**
- Put a `git` wrapper (a node script works) first on `PATH`. It exits 128 only for the exact call, for example `rev-list` plus `--first-parent` plus `--merges`.
- Delegate every other call to the real git.
- Run the exact command text through `bash -c` and assert a non-zero status.
- Prove the test red: rewrite the capture back to the `for m in $(...)` form and assert that the exit is 0.

**Why:** a wrapper that fails only the targeted invocation exercises the error arm without breaking the setup calls around it.
