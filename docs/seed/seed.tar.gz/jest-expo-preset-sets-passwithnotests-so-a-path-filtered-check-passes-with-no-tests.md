---
name: jest-expo-preset-sets-passwithnotests-so-a-path-filtered-check-passes-with-no-tests
description: "The jest-expo preset sets passWithNoTests, so a path-filtered jest check passes with no test file until jest.config.js overrides it."
metadata:
  node_type: memory
  type: project
  keywords:
    - jest-expo
    - passWithNoTests
    - No tests found
    - path filter
    - jest exit 0
    - missing test file
  provenance: code-verified
  slug: jest-expo-preset-sets-passwithnotests-so-a-path-filtered-check-passes-with-no-tests
  tags:
    - jest
    - gate
    - expo
---

# The jest-expo preset hides a missing test file

## Fact
The jest-expo preset sets `jestPreset.passWithNoTests = true` in `node_modules/jest-expo/jest-preset.js`.
Jest merges preset keys under the project config.
So `npx jest src/<pkg>/<module>` exits 0 with "No tests found" if the test file is absent or misnamed.

## Why it matters
A check that is a path-filtered jest run is meant to fail until the work is done.
With the preset default, a task that forgets or misnames its test file reads as green.
A gate running `jest --ci` also stays green if every test is deleted.

## Fix
Set `passWithNoTests: false` in `jest.config.js`.
Add a test that runs `jest --ci src/no-such-module` in a child process and expects exit 1 and the text "No tests found".
Delete the override and that test goes red.
The test asserts the real exit code, which rules out a jest CLI default that differs from the preset.

## How to apply
When a plan names a path-filtered test runner as a check, prove the runner fails on zero matches.
Do this before any task owns a test file.
