---
name: llm-caller-response-type-based-text-extraction
description: "Read an Anthropic response's text from the first type=='text' block, not content[0]; positional content[0]['text'] readers break on thinking-first replies"
metadata:
  node_type: memory
  type: project
  keywords:
    - "content[0]"
    - "type == 'text'"
    - thinking block
    - extended thinking
    - positional read
    - first_text_block
    - thinking-only reply
    - KeyError text
    - Anthropic Messages API
    - drift guard
  provenance: code-verified
  slug: llm-caller-response-type-based-text-extraction
  tags:
    - anthropic-api
    - response-parsing
---

## Rule

Read an Anthropic Messages API response's text from the first `type == 'text'`
block, never from `content[0]`. A model with thinking enabled can lead with a
`thinking` block, which has no `text` key.

Keep one shared definition, e.g. `first_text_block(content)` in
`<pkg>/message_utils.py`: return the first dict block with `type == 'text'`,
else `content[0]`. That fallback preserves each caller's existing missing-text
handling; callers must check `len(content) > 0` first. Import it everywhere;
never re-inline a private copy. Drift-guard tests can assert no private copies
survive and no positional `content[0]` reads remain.

**Why:** a positional read in a shared request wrapper stamped a placeholder
(`'...'`) on a thinking-first reply and marked it filtered. A downstream refusal
check read that flag, so a good reply triggered a false escalation retry. A
caller doing a raw `content[0]['text']` read on a thinking-capable model gets a
`KeyError`, not a placeholder.

**How to apply:** before moving any call site onto a thinking-capable model,
grep for `content[0]` / `['content'][0]['text']` and switch each to the shared
helper.

## Exception: a caller that needs "no text" to read as no text

The fallback-to-`content[0]` helper is wrong for a caller that must distinguish
a thinking-only reply. If the wrapper stamped `'text': '...'` on the leading
block, the shared helper hands that caller the string `'...'`, which then fails
as malformed output instead of being treated as "no text" (and retried with a
generic correction). Such a caller uses a local helper that returns the first
`type == 'text'` block's text and `None` when none exists, with no fallback.

**How to apply:** do not "tidy" that local helper onto the shared one. Before
moving any caller onto the shared helper, check whether it needs a no-text reply
to read as no text rather than as a placeholder.
