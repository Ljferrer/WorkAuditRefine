---
name: stack-env-must-be-read-by-every-lambda-it-is-passed-to
description: A Lambda handler that ignores the table env the stack passes works only while the stack keeps fixed table names.
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - environment variable
    - table name
    - authorizer
    - tableName
    - DynamoDB
    - dead env
    - stack test
    - injection seam
  slug: stack-env-must-be-read-by-every-lambda-it-is-passed-to
  tags:
    - infra
    - lambda
    - pattern
    - testing
---

Pass the env and read it, or stop passing it.

**The failure:**
- The stack passed three table-name variables to an authorizer Lambda.
- The authorizer handler called its table helper with no names, so it used hard-coded default names from a shared module.
- The deploy still worked because the stack creates each table under the same default name.
- If the stack dropped the fixed table names, only the authorizer would read a missing table, and every token check would fail.
- The stack test counts tables and never names them, so it would not catch this.

**Why:** a dead env variable hides a hard dependency on default names.

**How to apply:**
- The handler reads each variable through a guard that throws when one is missing.
- Any code that still uses the default names, such as an operator CLI, is safe only while the stack sets explicit `tableName` values.
- Test limit: the handler test covers only the missing-variable throw, because the handler builds a real `DynamoDBClient` with no injection seam. Name such a test for what it proves, not for a success path it never asserts.
