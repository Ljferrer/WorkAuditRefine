---
name: stack-env-must-be-read-by-every-lambda-it-is-passed-to
description: A Lambda handler that ignores the table env the stack passes works only while the stack keeps fixed table names.
metadata:
  node_type: memory
  type: project
  keywords:
    - environment variable
    - table name
    - authorizer
    - tableName
    - DynamoDB
    - dead env
    - stack test
    - injection seam
  provenance: code-verified
  slug: stack-env-must-be-read-by-every-lambda-it-is-passed-to
  tags:
    - infra
    - lambda
    - pattern
    - testing
  created: 2026-10-27
---

# Pass the env and read it, or stop passing it

## The failure
- The stack passed three table-name variables (`<PROJECT>_TABLE_*`) to an authorizer Lambda.
- The authorizer handler called its table helper with no names, so it used hard-coded default names from a shared module.
- The deploy still worked because the stack creates each table under the same default name.
- If the stack dropped the fixed table names, only the authorizer would read a missing table, and every token check would fail.
- The stack test counts tables and never names them, so it would not catch this.

## The fix
- The handler reads each variable through a guard that throws when one is missing.
- Any code that still uses the default names, such as an operator CLI, is safe only while the stack sets explicit `tableName` values.

## Test limit
- The handler test covers only the missing-variable throw.
- The handler builds a real `DynamoDBClient` and has no injection seam, so a cheap success-path test does not exist.
- Name such a test for what it proves. A title that claims a success path it never asserts misleads the reader.
