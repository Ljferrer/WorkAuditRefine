---
name: shared-manifest-rewrite-fail-loud-on-unreadable-read
description: "Falling back to {} on a failed read before rewriting a shared JSON blob silently deletes the keys other writers own"
metadata:
  node_type: memory
  type: project
  keywords:
    - read-modify-write
    - shared JSON blob overwrite
    - manifest
    - ClientError None fallback
    - S3 get_object
    - fail loud
    - transient error
    - partial rewrite
  provenance: agent-unverified
  slug: shared-manifest-rewrite-fail-loud-on-unreadable-read
  tags:
    - s3
    - error-handling
    - gotcha
---

## Rule

When a handler rewrites only some keys of a shared, multi-writer JSON blob (a
manifest, a metadata object, a config file another process also writes), an
unreadable read must raise. Never fall back to `{}` or an empty default. `{}`
looks like "the blob never existed", so a transient read failure on a blob
that does exist erases the other writers' keys on the next write. Any helper
that collapses "transient failure" and "genuinely absent" into one falsy
return is unsafe as the read half of a partial rewrite. A common example is
an S3 read wrapper that returns `None` on any `botocore` `ClientError`,
throttles and transient 5xx included.

## Instance

A `<handler>` read a shared per-record manifest with such a wrapper, did
`manifest = loads(raw) if raw else {}`, and re-uploaded only its own two
lists. A transient read failure dropped a key another handler had written
there for a downstream consumer.

The fix read with `s3_client.get_object(...)` directly, so a `ClientError`
raises, and asserted that the other writer's key is present in the manifest
before the upload.

**Why:** a read helper that maps every error to `None` turns a throttle into
silent data loss on the next partial write.

**How to apply:** in a read-modify-write of a blob other writers share, read
with a call that raises on error (distinguish `NoSuchKey` explicitly if
absence is legal), and assert that a key another writer owns is present
before the upload.
