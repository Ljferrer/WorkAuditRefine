---
name: shell-digit-only-value-extraction-truncates-legal-js-numeric-literal-forms
description: "A `[0-9]+`-only grep/sed extraction of a JS numeric value truncates 100_000, 0x13880 and 1e5, so a ceiling-raise check can fail open"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - numeric separator
    - JS numeric literal
    - sed digit extraction
    - grep digit regex
    - fail-open check
    - value truncation
    - hex literal
    - exponent literal
    - budget ceiling raise
    - underscore separator
  slug: shell-digit-only-value-extraction-truncates-legal-js-numeric-literal-forms
  tags:
    - shell
    - regex
    - gotcha
---

# `[0-9]+`-only value extraction from a JS source file misreads legal numeric forms

**Rule.** A shell script that pulls a number out of JS source with a bare `[0-9]+` regex stops at the first non-digit. JS accepts a numeric separator (`100_000`), hex (`0x13880`) and exponent (`1e5`). They read as `100`, `0` and `1`.

**Example.** A check extracts a budget ceiling with `sed -nE "s/.*${field}:[ ]*([0-9]+).*/\1/p"`. A raise from `hard: 79_872` to `hard: 79_900` reads `79` before and after. The `-gt` comparison is false, no raise is recorded, and the check exits 0 with no citation required. A raise that changes the truncated prefix (`79_872` to `90_112`) is still caught, so the exposure is narrow.

**Why:** the failure is silent and lands on exactly the change the check exists to catch. It is latent when no value in the file uses these forms today.

**How to apply:** before trusting a `[0-9]+` extraction of a source-code number, check whether the language allows separators, hex/octal/binary prefixes or exponents. Then do one of:
- Widen the regex to match those forms, and reject them or route them to default-deny.
- Enforce a plain-integer-only convention with a shape assertion on the guarded file.
