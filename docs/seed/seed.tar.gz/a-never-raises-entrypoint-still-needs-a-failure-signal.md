---
name: a-never-raises-entrypoint-still-needs-a-failure-signal
description: "A never-raises entrypoint needs a degraded sentinel or non-zero exit for an item-level failure, and must resolve its status output location first"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - never-raises
    - degraded sentinel
    - parse failure
    - offline fixture run
    - exit code
    - OK token
    - silent fallback
    - status write
  slug: a-never-raises-entrypoint-still-needs-a-failure-signal
  tags:
    - testing
    - fixture
    - pattern
---

A fixture or comparison entrypoint that must never raise, so one bad item cannot crash the whole sweep, still needs a failure signal for an item-level failure.

**The failure.** A host-run fixture tool parsed each page's output the same way the production handler does. A parse exception on a non-blank page set the parsed object to `None`, yet the tool printed its OK token and returned exit 0. A page could silently fall back to an empty result with no signal to the caller.

**The fix.**
- Add a `DEGRADED` token and a `degraded` list of item keys.
- Have `run()` return `(count, degraded)`.
- Have `main()` print `DEGRADED items=<keys>` and return a non-zero exit when any non-blank item failed to parse, instead of the OK token.

**Resolve the status output first.** Resolve the output bucket and key as the first statements in the single try block. Otherwise an early failure skips the status write that the alarm design depends on.

**Why:** a caller that ignores the exit code and diffs two output directories can score a false match on two empty results. The non-zero exit and the DEGRADED token are the intended stop. They are not a guarantee against every downstream misuse.

**How to apply:** when writing a never-raises entrypoint, give item-level failures a distinct token and exit code, and do the status-location work before anything that can fail.
