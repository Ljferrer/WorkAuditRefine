---
name: ast-one-home-guard-needs-load-context-not-just-call
description: "An AST one-home guard must flag every Load-context name, attribute and ImportFrom of the helper, not only ast.Call"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  slug: ast-one-home-guard-needs-load-context-not-just-call
  keywords:
    - AST guard
    - ast.Call only
    - Load context
    - one-home invariant
    - sorted key argument escape
    - ImportFrom alias
  tags:
    - testing
    - ast
---

## Fact

A unit test enforces a design rule: `<shared_helper>()` has one home,
`<OwnerClass>`. The guard's walker treats every `ast.Name` and
`ast.Attribute` read plus every `ast.ImportFrom` of `<shared_helper>` as a
reference, not only `ast.Call` nodes.

A Call-only guard misses four forms:

- `sorted(x, key=<shared_helper>)`: the name is a `key=` keyword argument,
  not a call target.
- `list(map(<shared_helper>, xs))`: the name is a positional argument.
- An aliased `from <module> import <shared_helper> as h`.
- A `<module>.<shared_helper>` attribute read.

The guard has a parametrized negative-control test that checks all four
escape shapes are caught. It also has a positive control that the scan
still reaches `<OwnerClass>`'s own calls.

## How to apply

When writing an AST-based "this symbol has one home" guard for any helper,
walk for every `Load`-context `ast.Name`, every `ast.Attribute`, and every
`ast.ImportFrom` naming the symbol under any alias. A Call-only walk lets a
`key=`, `map`, or aliased-import reference through silently. Pair the guard
with a negative-control test that exercises each of those forms, and a
positive control that the scan still reaches the one allowed caller.
