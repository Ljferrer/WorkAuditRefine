---
name: git-status-in-a-live-sibling-worktree-needs-optional-locks-off
description: "git status refreshes a stale index under index.lock, so a read-only status loop over live worktrees needs GIT_OPTIONAL_LOCKS=0"
metadata:
  node_type: memory
  slug: git-status-in-a-live-sibling-worktree-needs-optional-locks-off
  type: project
  keywords:
    - GIT_OPTIONAL_LOCKS
    - no-optional-locks
    - index.lock
    - git status
    - stale index
    - sibling worktree
    - read-only git
    - hook side effect
    - fingerprint
  provenance: code-verified
  tags:
    - hooks
    - git
    - worktree
    - concurrency
  created: 2026-10-23
---

# A "read-only" `git status` is not read-only: it can lock a live worker's index

**Rule.** When a hook or script runs `git status` in worktrees it does not own, export `GIT_OPTIONAL_LOCKS=0` (git's `--no-optional-locks`). Without it, `status` refreshes a stat-stale index and writes it back under `<gitdir>/index.lock`. A concurrent `git add`, `git commit` or `git rebase` in that worktree then dies with `index.lock: File exists`.

**Why it matters.** A guard hook that fingerprints worktree state can run `status` in every task worktree, including ones where other agents are working. The status output is the same either way, so the opt-out costs nothing.

**Test insight (the oracle matters).** A pre-existing `index.lock` is NOT the oracle. `git status` skips the refresh silently when it cannot take the lock, in both modes, so that test row never goes red. The working oracle:
- Give a tracked file an old mtime (content unchanged) to stale the index.
- Run each code path that calls `git status`.
- Compare `cksum` of the index before and after.
- Run a plain `git status` afterward as the sensitivity check: it must write the stale index, or the oracle is vacuous.
