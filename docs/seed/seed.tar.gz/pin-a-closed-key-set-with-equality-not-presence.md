---
name: pin-a-closed-key-set-with-equality-not-presence
description: "When a spec says no other keys change, pin the whole key set with ==, because a presence check lets an extra key leak in"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - closed set assertion
    - key set equality
    - presence-only check
    - no other key changes
    - leaked key
    - CDK synth test
    - task definition parameters
    - override env names
  slug: pin-a-closed-key-set-with-equality-not-presence
  tags:
    - testing
    - cdk-synth
    - test-fidelity
---

When a spec says "no key changes beyond the named additions," pin the closed key set with equality:

```python
assert set(run['Parameters']) == EXPECTED_PARAMETER_KEYS
```

Do the same for other closed sets, such as override env names.

**Why:** a check that only asserts the named keys are present (`in`, or a presence check) lets an unrelated key leak in without failing.

**How to apply:** when a requirement says "no other key changes," compare the full set with `==`. Never use `in` or a presence check for that claim.
