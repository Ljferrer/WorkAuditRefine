---
name: bash-case-star-crosses-slash-so-a-glob-is-neither-a-path-anchor-nor-globstar
description: "In a bash case pattern, * matches / too, so a glob is not a path anchor and **/ is not globstar; fences need a '..' check and an absolute arm, file conventions need a root plus nested pair"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - case glob
    - fnmatch
    - star crosses slash
    - path fence
    - relative path bypass
    - absolute path arm
    - dot-dot segment
    - globstar
    - root-level miss
    - test_ prefix pattern
  slug: bash-case-star-crosses-slash-so-a-glob-is-neither-a-path-anchor-nor-globstar
  tags:
    - bash
    - glob
    - guard
    - testing
---

In a bash `case` pattern (fnmatch without `FNM_PATHNAME`), `*` matches `/` as well. Two consequences follow, one for path fences and one for file-name conventions.

**Why:**
- A leading `*` matches any prefix, a relative one too. A fence like `*/.claude/projects/*/memory` admits `x/.claude/projects/s/memory`, and it admits `/a/.claude/projects/s/memory/archive/memory`, because the last segment is `memory` again. "A path beneath the memory dir is denied" overclaims; the true rule is "denied unless the last segment is `memory` again".
- `**/` is not globstar. It demands at least one slash, so `**/*.test.ts` misses a root-level `foo.test.ts`.
- `*` already crosses `/`, so a suffix convention (`*.test.ts`, `*_test.go`, `*Test.java`) is depth-agnostic as one token.
- A prefix convention matches only one depth. `test_*.py` matches only root-level files and `*/test_*.py` only nested ones.

**How to apply:**
- For a path fence, run three checks in order before trusting the glob:
  - A `..` check on the value wrapped in `/`, so `case "/$val/" in *"/../"*` sees a leading or trailing `..` as a segment.
  - An absolute-path arm, `/*) ;;`, denying anything else.
  - Only then the glob, tolerating one trailing `/`.
- Describe the rule as "matches", not "is under".
- For prefix conventions, write a root plus nested pair: `test_*.py */test_*.py *_test.py`. Never "fix" it with `*test_*.py`: `latest_results.py` contains `test_`, so it over-matches and gives a false pass. Never write `**/` tokens.
- Test each of: relative with a leading component, nested path ending in the anchor segment, trailing slash, and `..` at the start, middle and end. Put the bypass shape in the test row, not only the word in the label: a row named "relative path denied" with `.claude/projects/s/memory` has no leading component and never reaches the bypass.
- Prove any token set with a harness that mirrors the matcher:

```sh
m() { local f="$1" hit=no; set -f; for pat in $2; do case "$f" in $pat) hit=yes; break;; esac; done; set +f; echo "$f vs $2 -> $hit"; }
m pkg/tests/test_a.py 'test_*.py */test_*.py *_test.py'   # yes
m foo.test.ts '**/*.test.ts'                              # no  (root-level miss)
m latest_results.py '*test_*.py'                          # yes (the over-match trap)
```
