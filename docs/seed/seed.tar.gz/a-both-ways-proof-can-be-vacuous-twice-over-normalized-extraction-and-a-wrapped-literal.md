---
name: a-both-ways-proof-can-be-vacuous-twice-over-normalized-extraction-and-a-wrapped-literal
description: "A construct-scoped assert extracted from norm()-joined text silently yields '', and a scratch-deletion proof whose literal wraps across a source line is a no-op — either one turns a both-ways proof into theatre"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - both-ways proof
    - construct-scoped extraction
    - norm collapse
    - non-vacuity guard
    - scratch deletion
    - wrapped literal
    - vacuous assert
  slug: a-both-ways-proof-can-be-vacuous-twice-over-normalized-extraction-and-a-wrapped-literal
---

Two independent ways the same verification came out green while proving nothing.

1. **Extraction over normalized text.** Suppose a suite's `norm()` maps every line through a comment-prefix strip and joins with spaces, so headings and newlines do not survive it. A section extraction written as `norm(text).match(/## Heading[\s\S]*?(?=\n## |$)/)` returns `''`. The scoped `assert.match('', /literal/)` fails loudly only because a **non-vacuity guard** (`assert.ok(span.length > 200, ...)`) was added in the same edit. Without that guard the row would go green while asserting over an empty string. **Extract from the RAW text, then normalize the extracted span.**

2. **A scratch deletion whose literal wraps.** A both-ways proof deleted a phrase from the target section with a plain string replace, but the source wraps the phrase across a line break (`budget\n  exhaustion`). The edit was a **no-op** and the suite stayed green. That green was read, briefly, as confirming the vacuity under investigation. Scratch edits over prose must be **wrap-aware** (`re.sub(r'a\s+b\s+c', ...)`). A proof that produces no diff is not a proof, so run `git diff --stat` on the scratch state before trusting its result.

**Why:** a green result from an empty input or an unchanged file is indistinguishable from a real pass.

**How to apply:** a both-ways proof owes two checks of its own: that the scratch edit actually changed bytes, and that the assert's input is non-empty.
