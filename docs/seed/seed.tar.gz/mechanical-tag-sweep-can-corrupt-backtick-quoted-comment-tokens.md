---
name: mechanical-tag-sweep-can-corrupt-backtick-quoted-comment-tokens
description: "Mechanical tag sweep can corrupt backtick tokens in // comments"
metadata:
  node_type: memory
  type: project
  keywords:
    - find/replace sweep
    - mechanical tagging
    - comment corruption
    - backtick-quoted identifier
    - sed global replace
    - comment drift
  slug: mechanical-tag-sweep-can-corrupt-backtick-quoted-comment-tokens
  provenance: agent-unverified
  tags:
    - gotcha
    - comment-drift
    - mechanical-sweep
---

A global find/replace that tags every call of a construct (for example `` agent(`...`) `` to `` agent(tag`...`) ``) has no syntax awareness. It also matches the same text inside a `//` comment: `` from `a` + `b` here `` becomes `` from `a` + tag`b` here ``. The damage is inert but real prose drift, and tests cannot see it.

**How to apply:** after a sweep meant for executable sites only, grep the diff for the token pattern inside `//` or `#` comment lines and prose files. Revert each collision by hand.
