---
name: normalize-a-json-args-input-by-parsing-strings-then-guarding-for-an-object
description: "Normalize an args input by parsing it when it is a string, then guard that the result is a non-null object, because a try/catch alone lets null and scalars through"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - args normalization
    - JSON.parse scalar
    - JSON-stringified args
    - null destructure
    - TypeError
    - object guard
    - Object.keys(null)
    - try catch gap
    - parse shim
  slug: normalize-a-json-args-input-by-parsing-strings-then-guarding-for-an-object
  tags:
    - args-normalization
    - json-parse
    - validation
    - gotcha
---

## Fact

An args input can arrive as a JSON string even when it is documented as an object. A harness can hand a script its args global JSON-encoded. A script that trusts the doc then fails at its first property access, for example `undefined is not an object (evaluating 'args.<key>.<method>')`.

Parsing alone is not enough. A `try/catch` around `JSON.parse(args)` catches a `SyntaxError` on malformed JSON, but lets valid JSON scalars through: `'null'`, `'true'`, `'5'`. `JSON.parse('null')` returns `null` with no throw, and `const { a } = null` then throws a raw `TypeError` that skips any domain error guard downstream.

The same gap hits config validation. A validator that guards one block with an object check but runs `Object.keys(c.field)` on another throws an uncaught `TypeError` when a hand-edited config sets that field to `null`, instead of returning a clean validation error.

## Pattern that fails

```js
let A;
try {
  A = typeof args === 'string' ? JSON.parse(args) : (args ?? {});
} catch { A = {}; }
const { planFile } = A;  // TypeError if A is null/5/true
```

## Correct pattern

```js
const parsed = typeof args === 'string' ? JSON.parse(args) : args;
A = (typeof parsed === 'object' && parsed !== null) ? parsed : {};
```

For a config field: `if (!isObj(c.field)) { errors.push('field must be an object'); }` before the loop.

**Why:** the catch block handles only malformed text. Null and scalars pass it and crash later with a raw error.

**How to apply:** open every script that reads an args global with the parse-if-string shim, or skip args and bake constants in. Always follow the parse with a `typeof x === 'object' && x !== null` guard before you destructure or call `Object.keys`. Add regression cases for `null` and a scalar string.
