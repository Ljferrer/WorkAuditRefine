---
name: a-lint-rule-id-fixture-proves-the-rule-fired-not-each-pattern
description: "A violation fixture checked by rule id proves the rule fired, not that each banned pattern fires, so add one row per pattern by spawning eslint on a virtual path"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - eslint test
    - stdin-filename
    - rule id fixture
    - pattern coverage
    - no-restricted-imports
    - lint config test
  slug: a-lint-rule-id-fixture-proves-the-rule-fired-not-each-pattern
  tags:
    - eslint
    - guardrails
    - tests
---

# A lint rule-id fixture proves the rule fired, not each pattern

A violation fixture checked by rule id (`no-restricted-globals`, `no-restricted-imports`, `no-console`, `import/no-restricted-paths`) proves only that the rule fired. It does not prove that each pattern inside the rule fires.

A fixture that imports only plain forms such as `react-native` gives no proof for scoped pattern entries such as `@react-native/*`, or for a pattern that bans one context file. A commit message that claims otherwise is wrong.

`no-restricted-globals` never sees an imported `fetch` binding. Ban such an import by name in the import rule. A deep import that re-exports `fetch` from outside the fenced directory stays open.

**How to apply:**
- Add a test row to an ESLint config test whenever you add a pattern.
- The config test spawns the real `eslint` with `--stdin --stdin-filename <virtual path> --format json`.
- The virtual path decides which config blocks apply, so one test can probe any zone without a real file.
- Put the test outside the fenced source directories. A network-name fence would otherwise ban the names the test must write.
