---
name: grep-q-under-pipefail-can-sigpipe-its-producer-and-read-as-no-match
description: "Under pipefail, `cmd | grep -Fxq` can SIGPIPE cmd on large output, so the pipeline returns 141 and an if-caller reads no match"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - SIGPIPE
    - pipefail
    - grep -Fxq early exit
    - draining awk idiom
    - false negative
    - exit 141
    - git worktree list --porcelain
  slug: grep-q-under-pipefail-can-sigpipe-its-producer-and-read-as-no-match
  tags:
    - shell-scripts
    - pipefail
---

# `cmd | grep -q` under `set -o pipefail` can read a SIGPIPE as "no match"

**Rule.** Under `set -o pipefail`, `grep -q` (or `-Fxq`) exits on its first match. Once the producer's output exceeds the pipe buffer (about 64 KB), the producer takes a SIGPIPE and the pipeline returns 141. An `if cmd | grep -Fxq ...; then` caller reads that as "not found". That is a false negative, not an error. `git worktree list --porcelain` with several hundred worktrees is one case.

**Fix.** Drain the whole input. Use an awk pass with a flag variable and an END-block exit, with no early return.

**Why:** the failure only shows at large output sizes, so small fixtures never reproduce it.

**How to apply:** for any pipeline consumer that exits early (`grep -q`, `head -1`), check whether it runs under `pipefail` over a producer that can be large. If so, drain it with awk, or capture the output first and test it.
