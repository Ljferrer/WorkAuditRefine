---
name: git-revert-no-commit-folds-a-staged-index-into-the-commit-so-guard-the-index-and-check-write-tree
description: "git revert --no-commit skips the dirty-index refusal, so staged content rides into the revert commit"
metadata:
  node_type: memory
  type: project
  keywords:
    - revert --no-commit
    - dirty index
    - staged leftovers
    - write-tree
    - tree mismatch
    - range revert
  provenance: code-verified
  slug: git-revert-no-commit-folds-a-staged-index-into-the-commit-so-guard-the-index-and-check-write-tree
  tags:
    - git
    - automation
    - revert
  created: 2026-10-29
---

# `git revert --no-commit` commits whatever is staged

**Fact.** A committing `git revert --no-edit <sha>` refuses a dirty index.
`git revert --no-commit <a>..HEAD` does not refuse: git-revert(1) says the index need not match HEAD.
The revert starts from the current index, so staged leftovers fold into the next `git commit`.
A script that then echoes a success token reports a tree that is not the one it claims.

**How it fails.** An automated revert moved from a tip-only `revert --no-edit` to a range `revert --no-commit <approved>..HEAD`.
The guarantee it was meant to keep: the revert tree equals the last approved tree.
The real trigger is a dead job that ran `git add` before its commit failed.
A `git checkout -- .` cleanup does not unstage, so the staged content survives it.
The revert tip then became the baseline for the next comparison, so the leaked content sat outside every later diff.

**The fix (two guards, different jobs).**
- Before the revert: if `git diff --cached --quiet HEAD` fails, print a failure token such as `INDEX-DIRTY` and touch nothing.
- After the revert, before the commit: commit only if `git write-tree` equals `<approved>^{tree}`, else print a failure token such as `TREE-MISMATCH`.
- Check `write-tree` (the index the commit would record), not `HEAD^{tree}` after the fact, so a bad tree is never committed.
- Every consumer of the script's output must map both tokens to its failure path.

**Test lesson.** A real-git fixture that proves tree equality on a clean index cannot fail on this bug.
Add a fixture that stages a foreign file first, and assert no success token and an unchanged HEAD.

The same trap applies to `git cherry-pick -n` and any other `--no-commit` sequencer verb (unverified generalization).
