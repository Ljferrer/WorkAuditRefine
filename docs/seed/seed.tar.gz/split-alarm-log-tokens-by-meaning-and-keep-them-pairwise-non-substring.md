---
name: split-alarm-log-tokens-by-meaning-and-keep-them-pairwise-non-substring
description: "Never-raises handlers: split log tokens by meaning, keep them non-substring for MetricFilters, mirror the constants across files"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - never-raises handler
    - log token split
    - MetricFilter literal matching
    - CloudWatch alarm design
    - defect vs expected-state
    - lazy alarm
    - alarm posture
    - N-way pairwise non-substring
  slug: split-alarm-log-tokens-by-meaning-and-keep-them-pairwise-non-substring
  tags:
    - observability
    - cloudwatch
    - alarm-design
    - step-functions
---

A never-raises handler (every failure still writes a status file and returns 200) that logs one alarm token for different meanings should split it into literal tokens, one per meaning. Each gets its own `logs.MetricFilter` and `cloudwatch.Alarm`:

- A defect token (for example `<STEP>_FAILED`, `<STEP>_DB_WRITE_FAILED`) gets a tight posture: short period, low threshold, one datapoint.
- An expected-state token (for example `<STEP>_NO_INPUT`) gets a lazy posture: long period, higher threshold, two datapoints. A single hit is normal pipeline ordering; only a sustained rate pages.

**Pairwise non-substring is load-bearing.** `FilterPattern.literal` matches any event containing the term, so if one token contained another, both filters would count it. With N tokens, every pair must be non-substring. Add a unit test (for example `test_alarm_tokens_pairwise_non_substring`) that checks the whole token set.

**Mirror comments on both sides.** The handler defines the constants and the stack defines the filters. Put a comment on each side naming the other, so the pair changes together.

**Why:** one token for two meanings either pages on normal ordering or hides real defects, and a substring overlap corrupts both metrics.

**How to apply:** when adding a log token to an alarm family, keep it non-substring of every sibling, extend the pairwise test, and update the mirror comment on each side.
