---
name: find-the-merge-of-a-branch-tip-with-a-bounded-first-parent-walk
description: "Find the merge commit that brought in a branch tip by walking rev-list --first-parent --merges tip..target, never the whole history"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - merge commit lookup
    - first-parent
    - rev-list --merges
    - second parent
    - bounded walk
    - tip..integration
  slug: find-the-merge-of-a-branch-tip-with-a-bounded-first-parent-walk
  tags:
    - git
    - shell
---

# Find the merge of a branch tip with a bounded first-parent walk

To find the merge commit M whose second parent is a branch tip, walk `git rev-list --first-parent --merges "$tip..<target>"`.

**Why:** M can never be an ancestor of the tip, so the `tip..target` bound never loses it. An unbounded walk costs one `rev-parse` spawn per first-parent merge in history.

**How to apply:**
- Always bound the walk with `"$tip..<target>"`.
- A branch already at the target tip gets an empty walk. Treat that as "no merge", not as an error.
- Capture the walk's output before looping over it, so a failed walk is not read as a count of 0.
