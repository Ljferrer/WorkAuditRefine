---
name: jq-empty-fallback-folds-false-null-and-empty-so-a-presence-gate-needs-has-and-a-type-check
description: "A hook that reads a key with jq // empty and gates on non-empty lets a present empty, null, false or array value pass"
metadata:
  node_type: memory
  type: project
  keywords:
    - jq // empty
    - present but empty
    - presence versus value
    - jq has
    - non-string tool_input
    - array embeds path segment
    - hook input guard
    - fail-closed hook
    - jq -r prints JSON text
  provenance: code-verified
  slug: jq-empty-fallback-folds-false-null-and-empty-so-a-presence-gate-needs-has-and-a-type-check
  tags:
    - hooks
    - shell
    - input-validation
  created: 2026-10-22
---

# Gate a hook input check on key presence and value type, not on a non-empty value

**The shape.** The rule was: when an output-path key is present, deny unless its value carries the segment `/<allowed-dir>/`. The first hook read each key with `jq -r ".tool_input.$key // empty"` and tested `[ -n "$val" ]`. The `//` operator turns `null` and `false` into `empty`. A present `""` passes through `//` but prints nothing, so `[ -n ]` drops it too. Together they read all three as "absent". So a present key with an empty, null or false value skipped the check and the hook exited 0. If a tool resolves an empty path against its own working directory, the write lands outside the allowed dir.

**A second hole in the same line.** `jq -r` prints an array or object as JSON text. An array such as `["/x/<allowed-dir>/a","/tmp/evil"]` prints text that contains the segment and no `..` segment, so the substring test passes.

**The fix.** Test presence with `jq -e --arg k "$key" '(.tool_input|type)=="object" and (.tool_input|has($k))'`. Then read the value's `type` and require `string` and non-empty, else deny. Deny a `tool_input` that is neither absent nor an object before the loop. Test rows pin the empty-string, non-string and non-object cases.

**Rule.** A "when present" rule needs a presence test (`has`), a type test and then the value test. Never infer presence from the value. A fail-closed hook must not lean on the tool's own schema to reject odd types.
