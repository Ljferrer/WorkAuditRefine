---
name: seed-ecs-config-or-true-swallows-write-failures
description: "A `func || true` under set -e hides real write failures inside func, so the script can report false success"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  slug: seed-ecs-config-or-true-swallows-write-failures
  keywords:
    - "|| true"
    - set -e
    - errexit
    - silent failure
    - non-zero as signal
    - postcondition check
    - bash idiom
  tags:
    - bash
    - shell-scripting
---

## Rule (bash)

Under `set -e`, `cmd || true` disables errexit for the whole evaluation of
`cmd`, not only its final exit status. If `cmd` is a function, every command
inside it (`mkdir`, `touch`, a `>>` redirect) can fail silently, and the
script goes on to report success.

This bites when a function's non-zero exit is also a normal signal. In a
`<setup>.sh` script, a `<seed_config>` function ends with
`[ -n "$changed" ]` ("nothing to write" is false, not an error), so callers
wrap it `<seed_config> || true`. That also hid a failed write to the config
file that must hold a required setting line.

Fixed in #<issue>: a `<verify_config>` function greps `-qxF` for each
required line after the seed call and calls `fail` when one is missing.

**Why:** `|| true` cannot tell "expected false" from "a real command inside
failed". It silences both.

**How to apply:**
- Do not wrap a function in `|| true` when its non-zero is an expected
  signal and its body has commands whose failure should be fatal.
- When the two must stay separate, check the write's postcondition
  explicitly afterward, or return "did we need to write" and "did the write
  succeed" as separate values.
- When auditing a `set -euo pipefail` script, grep for `|| true` and read
  what the wrapped command runs.
