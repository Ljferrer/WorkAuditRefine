---
name: cdk-stack-needs-a-resource-count-guard-near-the-cfn-500-limit
description: "A large CDK stack can hit CloudFormation's 500-resource limit, so pin each stack to a resource budget in a unit test and move monitors to a sibling stack for headroom"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  slug: cdk-stack-needs-a-resource-count-guard-near-the-cfn-500-limit
  keywords:
    - CloudFormation 500 resource limit
    - resource count
    - resource budget
    - stackResourceLimit
    - synth fails past 500
    - MetricFilter
    - Alarm
    - headroom
    - monitoring sibling
    - metric filter quota per log group
  tags:
    - cdk
    - cloudformation
    - testing
---

## Fact

`<ExampleStack>` hit CloudFormation's 500-resource limit once, when a per-chain copy of a Lambda set reached 501 resources.
Sharing one Lambda set across both chains fixed it.

`cdk synth` fails past 500 with `ValidationError: Number of resources in stack ... is greater than allowed maximum of 500`.
The context key `@aws-cdk/core:stackResourceLimit` sets that maximum.
The pipeline's Synth step fails there, before any deploy, but only after merge if PR CI does not synthesize.
The limit applies to each stage's template on its own.

A unit test now pins every stack to a `RESOURCE_BUDGET` constant.
It synthesizes every deployed stage with the same flags as production, so its counts match the deployed templates.
It carries a positive control, so the assert cannot pass vacuously.

Monitoring was the largest block of resources.
Every MetricFilter, Alarm, CompositeAlarm, Dashboard and QueryDefinition that watches `<ExampleStack>` now deploys from a monitoring sibling stack.
Each build site stays in the original stack's code and names what it watches by literal name, with no CloudFormation export.
A per-token idiom spends headroom fast, because it builds one MetricFilter and one Alarm per token.

A second ceiling sits below the stack limit. CloudWatch Logs allows 100 metric filters per log group, and AWS does not raise that quota.

## How to apply

If a change adds Lambdas, filters or alarms to a stack near the limit, run the resource-budget test before you push.
If it fails, cut resources or move them. Raise `RESOURCE_BUDGET` only with a plan to cut.

A new Lambda costs its function, a role, a default policy and any exports, plus an EventInvokeConfig unless its config drops the retry setting.
Do not cut exports to save resources when downstream repos read them.
Keep the log group read that creates the log retention resource, because dropping it drops retention.
If a change adds filters to any log group, also run a test that counts filters per log group against a filter budget.
