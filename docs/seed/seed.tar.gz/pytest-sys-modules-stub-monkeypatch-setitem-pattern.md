---
name: pytest-sys-modules-stub-monkeypatch-setitem-pattern
description: "Stub heavy third-party deps into sys.modules via monkeypatch.setitem, not a bare assignment, or the stub leaks past the test into later by-path handler imports in the same pytest session"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - sys.modules
    - monkeypatch.setitem
    - pytest fixture
    - test isolation leak
    - dependency stub
    - importlib
    - hermetic unit test
  slug: pytest-sys-modules-stub-monkeypatch-setitem-pattern
  tags:
    - testing
    - pytest
    - python
    - pattern
---

## The pattern

A fixture imports a handler module, `<handler_module>`, "by path" for a smoke test. That module has many heavy third-party deps the test does not need. The fixture stubs each dep with `monkeypatch.setitem(sys.modules, mod_name, stub)` instead of a bare `sys.modules[mod_name] = stub` assignment. Every stub is then reverted automatically at test teardown.

The fixture also tracks whether the target module itself was freshly imported:

```python
fresh = '<handler_module>' not in sys.modules
# ... import by path ...
if fresh:
    request.addfinalizer(lambda: sys.modules.pop('<handler_module>', None))
```

It pops the module only when this test caused the import. A module another test already needs stays resident.

**Why:** a bare `sys.modules[x] = stub` assignment, or a raw `del sys.modules[x]`, persists for the rest of the pytest **session**, not just the test file. A leaked stub from one test module broke later by-path handler imports elsewhere in the same session. The import resolved to the stale stub instead of the real module.

**How to apply:** any test that stubs a dependency via `sys.modules` for a by-path or `importlib` import (not a normal `from x import y`) should use `monkeypatch.setitem` / `monkeypatch.delitem` and a fresh-import-tracking finalizer, not a bare dict assignment. Also patch the module namespace the callee actually reads the symbol from, not another module's copy of the imported name.
