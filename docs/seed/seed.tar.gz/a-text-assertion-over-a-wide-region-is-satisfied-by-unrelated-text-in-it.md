---
name: a-text-assertion-over-a-wide-region-is-satisfied-by-unrelated-text-in-it
description: "A token or count assertion over a broad text region passes on other text in that region, so scope it to the item's own span"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - count threshold
    - padding line
    - anchor slice
    - substring token
    - self-satisfying region
    - compound label
    - grep -c over-count
    - per-item span
  slug: a-text-assertion-over-a-wide-region-is-satisfied-by-unrelated-text-in-it
  tags:
    - testing
    - assertion-strength
    - drift-guard
---

**Rule:** an `includes` or count check over a whole surface, or over an anchor-sliced region, can be satisfied by an intro line, the anchor's own words, unrelated prose, or a compound label that contains the target. Assert per item, on the item's own anchored span.

Shapes:

- **A count threshold inflated by a padding line.** A test meant to lock "each of N items keeps property P" is written as one count assertion (`count >= N`) over the whole surface. If the surface also has an unrelated line that repeats the same phrase (an intro sentence that restates the qualifier before the listed items), the true count is N+1. A regression that drops P from exactly one item still leaves the count at N, so the test stays green. Fix: raise the threshold to the true total, or better, assert P within each item's own anchored span.
- **A region that satisfies a substring of its own anchor.** A test builds its region as `text.slice(text.indexOf(ANCHOR_PHRASE), end)`, so the region always begins with the anchor. It then asserts `region.includes(t)` for a family of tokens. If a token is a substring of the anchor (for example, `'retire'` when the anchor is `'retired-token sweep'`), that assertion cannot fail once the anchor's presence passes. A red proof that deletes the whole sentence still goes red through the other tokens, which hides the inert ones. A partial reword that drops only the inert tokens passes silently.
- **Unrelated prose in the region.** A token can be satisfied by other text in the same sliced region (for example, a routing sentence's own "consolidated" satisfying a check for `'consolidate'`).
- **A compound label in a count grep.** A compound label built from two labels (`a/b`, `a+b`, `a,b`) is a superset string of each one, so a later `grep -c '<label> <suffix>'` for one label can over-count the compound line.

**Why:** an assertion that other text in its region can satisfy cannot catch the defect it names.

**How to apply:** for "each of N items has P," count every occurrence of P's phrase on the surface, including intro and summary lines, or switch to a per-item anchored check. For an anchor-sliced region, slice to the first sentence end, assert an anchored multi-word phrase, and drop any token that is a substring of the anchor. For compound labels, pick a joint alias or a delimiter that cannot form a superset of any label grepped elsewhere.
