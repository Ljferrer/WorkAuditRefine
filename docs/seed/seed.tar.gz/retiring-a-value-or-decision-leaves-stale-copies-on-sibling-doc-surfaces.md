---
name: retiring-a-value-or-decision-leaves-stale-copies-on-sibling-doc-surfaces
description: "Flipping a default or superseding a decision fixes one doc surface and strands the rest, so sweep all surfaces and assert the old value is absent"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - stale prose
    - config table
    - schema example
    - old value absent
    - cross-reference drift
    - superseded ADR
    - stale pointer
    - doc sweep
    - scope narrowing
  slug: retiring-a-value-or-decision-leaves-stale-copies-on-sibling-doc-surfaces
  tags:
    - documentation
    - defaults
    - adr
    - plan-completeness
---

# Retiring a value or decision leaves stale copies on sibling doc surfaces

**Rule.** A default, a guardrail statement, or a decision lives on several surface types:
- the authoritative preset or config table,
- field-reference prose ("the current default is X"),
- illustrative JSON or schema examples,
- consuming files that copy and annotate it,
- inbound cross-references in sibling sections of the same doc,
- other pointers to a superseded decision record, such as a setup bullet that still names the old one.

A gate that only asserts the new value is present in the authoritative table passes while the rest go stale. It must also assert the old value is absent.

**Why:** a fix scoped to the one row or table the task targets leaves sibling rows that cite the retired value or decision. A note that scopes the change to "no other rows" is not a barrier once the file is already touched. Sibling prose also drifts, such as a sentence that still describes a feature as it stood before a later change, or a status paragraph that calls landed work "next".

**How to apply:**
- A "flip or narrow default X" task must list every surface type, or state "update all references across the doc and any file that annotates it". Use the same discipline when a statement's scope is narrowed by a carved exception, not just when its value flips.
- When a change supersedes a decision record, grep the README and `docs/` for the old record's filename and for the retired claim. Fix every hit in the same change.
