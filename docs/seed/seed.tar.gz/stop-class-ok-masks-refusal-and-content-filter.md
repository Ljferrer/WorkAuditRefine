---
name: stop-class-ok-masks-refusal-and-content-filter
description: "A binary truncated/ok classifier over an LLM finish_reason maps refusals and content filters to 'ok', so a retry keyed on 'ok' misses them"
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - stop_class
    - finish_reason
    - stop_reason
    - TRUNCATED_FINISH_REASONS
    - content_filter
    - refusal
    - retry selector
    - truncation retry
  slug: stop-class-ok-masks-refusal-and-content-filter
  tags:
    - llm-caller
    - stop-class
    - truncation-retry
---

An LLM-caller helper added a `stop_class` field to its result envelope for a
truncation-retry selector. The classifier was:

```python
TRUNCATED_FINISH_REASONS = frozenset({'max_tokens', 'length'})

def stop_class_for(finish_reason):
    return 'truncated' if finish_reason in TRUNCATED_FINISH_REASONS else 'ok'
```

This is a **closed binary**, not a three-way classification. Every
`finish_reason` / `stop_reason` outside the truncation set (`stop`,
`end_turn`, `refusal`, `content_filter`, anything else) becomes `'ok'`.
`stop_class` alone cannot tell a real answer from a refused or filtered reply.
The refusal/filter signal must come from somewhere else (for example a
`filtered` flag computed from `'filter'`/`'refusal'` in the finish reason, or
an `is_refused(...)` helper).

**Why:** a retry selector that checks only `stop_class == 'ok'` will
"succeed" on a refused or filtered reply.

**How to apply:** any caller that keys behavior off a truncated/ok class must
also check a refusal/filter signal before trusting `'ok'`, e.g.
`return stop_class == 'ok' and not is_refused(...)`. Better still, make the
classifier three-way (`truncated` / `refused` / `ok`) so the collapse cannot
happen.
