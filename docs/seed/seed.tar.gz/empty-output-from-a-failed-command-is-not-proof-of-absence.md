---
name: empty-output-from-a-failed-command-is-not-proof-of-absence
description: "A proof of absence built on command output passes on a command error when stderr and exit status are swallowed (2>/dev/null || true, or grep -c over a failed producer)"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - proof of absence
    - git log error swallowed
    - 2>/dev/null || true
    - false empty proof
    - unresolvable base
    - orphan branch deletion
    - grep -c vacuous zero
    - failed producer
    - exit status
  slug: empty-output-from-a-failed-command-is-not-proof-of-absence
  tags:
    - shell
    - gotcha
    - safety-critical
---

A check that treats empty output as "nothing there" also passes when the command failed.

```sh
orphan_commits="$(git log --oneline "$base..$branch" 2>/dev/null || true)"
if [ -z "$orphan_commits" ] && ! git ls-remote --exit-code origin "refs/heads/$branch" ...
```

`2>/dev/null || true` turns any `git log` failure into empty stdout. If `$base` is a typo or absent, `git log` exits non-zero, `[ -z "$orphan_commits" ]` passes, and a self-heal step can delete (`git branch -D`) a branch that carries unique commits. An unreachable origin reading as "absent" in a second proof, built the same way, makes it worse.

The same kernel hits count floors. A `grep -c` over the output of a failed producer reads empty input and prints `0`, which looks like genuine absence.

**Why:** the swallow pattern collapses "command failed" and "command succeeded with an empty result" into one branch. A safety proof built on it can destroy work or report a false pass.

**How to apply:**
- Before trusting an empty-output proof from a command that can also fail, verify the input resolves first: `git rev-parse --verify --quiet "$base"`, and die loud on failure.
- Or capture the exit status separately from the output. Never let `2>/dev/null || true` (or any `... || true`) stand in for the proof.
- For a count floor, check that the producer succeeded and that its dump is non-empty (check its exit code and `wc -c`) before trusting a `0`.
- This applies to any proof of absence built on shell command output.
