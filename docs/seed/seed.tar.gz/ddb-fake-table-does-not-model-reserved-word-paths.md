---
name: ddb-fake-table-does-not-model-reserved-word-paths
description: A hand-written fake DynamoDB table in unit tests accepts bare reserved-word attribute paths that live DynamoDB rejects
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - fake DynamoDB
    - reserved word
    - ExpressionAttributeNames
    - ValidationException
    - test oracle gap
    - condition expression
    - update expression
  slug: ddb-fake-table-does-not-model-reserved-word-paths
  tags:
    - testing
    - dynamodb
    - fixture
---

A hand-written fake DynamoDB table used as the only test oracle for condition and update expressions does not check reserved words. This happens when no emulator such as moto is installed. The fake's own docstring says reserved-word checks are not modeled.

A bare attribute path such as `status`, `name` or `ttl` passes the fake. Live DynamoDB rejects the same expression with `ValidationException`.

**Why:** many wrappers around DynamoDB writes swallow errors so a storage problem never fails the caller. A live rejection then degrades durability with no test signal and no user-visible failure.

**How to apply:**
- Name every attribute in a new condition or update expression through `ExpressionAttributeNames` placeholders such as `#status` and `#name`. Never write a bare attribute path. Review this by eye, since no test catches it.
- Before trusting the fake for any other rule, read its docstring for the list of behaviors it skips. Treat each skipped behavior as unverified until a live run confirms it.
- A cheap guard is a test that scans the expression strings your code builds and fails on any reserved word used as a bare path. A better guard is an emulator that enforces reserved words.
