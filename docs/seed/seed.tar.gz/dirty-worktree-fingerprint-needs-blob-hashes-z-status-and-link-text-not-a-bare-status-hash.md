---
name: dirty-worktree-fingerprint-needs-blob-hashes-z-status-and-link-text-not-a-bare-status-hash
description: "A bare git status hash misses a second edit to a dirty file, so fingerprint blob hashes from a -z status"
metadata:
  node_type: memory
  type: project
  keywords:
    - worktree fingerprint
    - git status porcelain
    - hash-object
    - stdin-paths
    - symlink
    - readlink
    - no-filters
    - status -z
    - tamper detection
    - content-sensitive
  provenance: code-verified
  slug: dirty-worktree-fingerprint-needs-blob-hashes-z-status-and-link-text-not-a-bare-status-hash
  tags:
    - hooks
    - git
    - audit
    - fingerprint
---

# To detect change in a dirty worktree, hash content, not just the status text

**Rule.** `git status --porcelain` text is identical before and after a second edit to an already-modified file. Fingerprint HEAD, the `-z` status bytes, and a blob hash of every path status lists.

**Details that matter:**
- Use `status -z`. The newline form C-quotes a path with a space, a double quote, a backslash or a control byte, even under `core.quotePath=false`, and such a path cannot then be hashed.
- A rename or copy record carries its source path as an extra NUL field. Skip that field and name the new path.
- Use `git hash-object --no-filters`. A clean filter would run (git-lfs writes under `.git/lfs`), and an eol filter would hide a line-ending-only edit.
- Batch with `--stdin-paths`, one call per worktree. That reader ends a path at a newline, strips a trailing CR, and C-unquotes a line starting with a double quote (it dies on a raw name). Give such paths their own `hash-object -- <path>` call.
- Test `-L` before `-f`. `hash-object` follows a symlink and reads the target. A retarget to a same-content file would then go undetected, and a link to a directory reads as absent. Hash `link-` plus the sha256 of `readlink` text instead.
- Also hash the paths `git ls-files -v` flags, beyond HEAD, status and the blob list.

**How to test the symlink arm.** A retarget must change the fingerprint. That alone does not prove the target is never read. Add a second test: change a link's out-of-worktree target and expect the check to pass. It goes red if the `-L` arm follows the link.
