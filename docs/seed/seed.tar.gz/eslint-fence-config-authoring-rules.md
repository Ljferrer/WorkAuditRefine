---
name: eslint-fence-config-authoring-rules
description: "ESLint flat-config import-ban blocks replace earlier rule options, so each subset block repeats its parent zones and exemptions go in ignores."
metadata:
  node_type: memory
  type: project
  provenance: code-verified
  keywords:
    - eslint flat config
    - import/no-restricted-paths
    - no-restricted-imports
    - fence
    - guardrail
    - ignores vs except
    - rule options replace
  slug: eslint-fence-config-authoring-rules
  tags:
    - eslint
    - guardrails
---

# How to author ESLint import fences

A fence is an ESLint rule block that bans certain imports or globals in part of a codebase.

- Flat config replaces a rule's options when a later block matches the same file. It never merges them.
- So each block whose files are a subset of an earlier block must repeat the earlier zones and restricted imports. Keep each fence in one constant (such as `<FENCE>_PATHS` or `<FENCE>_PATTERN`) and spread it into every block that needs it.
- A new block that sets `no-restricted-imports` or `import/no-restricted-paths` for a fenced directory must repeat those constants. If it does not, it silently drops those fences for its files.
- A target-file exemption goes in the block's `ignores`. It never goes in `except`, because `except` cannot exempt a target file.
- `except` is fine when it names a from-path, for example `except: ['./<adapter>.ts']` against `from: './<pkg>'`.
- `import/no-restricted-paths` is resolver based. An import the resolver cannot resolve is skipped silently.

**Why:** a block that looks additive replaces the fences above it, and nothing reports the loss.

**How to apply:** whenever you add a block for a subset of files, diff its rule options against every earlier block that matches those files.
