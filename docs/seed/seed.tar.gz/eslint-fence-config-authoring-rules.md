---
name: eslint-fence-config-authoring-rules
description: "ESLint flat-config import-ban blocks replace earlier rule options, so each subset block repeats its parent zones and exemptions go in ignores."
metadata:
  node_type: memory
  slug: eslint-fence-config-authoring-rules
  type: project
  keywords:
    - eslint flat config
    - import/no-restricted-paths
    - no-restricted-imports
    - fence
    - guardrail
    - ignores vs except
    - rule options replace
    - eslint config test
    - eslint --stdin-filename
  provenance: code-verified
  tags:
    - eslint
    - guardrails
    - gate
  created: 2026-10-27
---

# How to build ESLint import fences, and what they do not prove

A fence here means an ESLint rule block that bans certain imports or globals in part of a codebase.

## Authoring rules
- Flat config replaces a rule's options when a later block matches the same file. It never merges them.
- So each block whose files are a subset of an earlier block must repeat the earlier zones and restricted imports. Keep each fence in one constant (such as `<FENCE>_PATHS` or `<FENCE>_PATTERN`) and spread it into every block that needs it.
- A new block that sets `no-restricted-imports` or `import/no-restricted-paths` for a fenced directory must repeat those constants. If it does not, it silently drops those fences for its files.
- A target-file exemption goes in the block's `ignores`. It never goes in `except`, because `except` cannot exempt a target file.
- `except` is fine when it names a from-path, for example `except: ['./<adapter>.ts']` against `from: './src/<pkg>'`.
- `import/no-restricted-paths` is resolver based. An import the resolver cannot resolve is skipped silently (a review claim, not probed).

## What the fences do not prove
- A violation fixture checked by rule id (`no-restricted-globals`, `no-restricted-imports`, `no-console`, `import/no-restricted-paths`) proves only that the rule fired. It does not prove that each pattern inside the rule fires.
- A fixture that imports only plain forms such as `react-native` gives no proof for scoped pattern entries such as `@react-native/*` or `@react-native-async-storage/*`, or for a pattern that bans one context file. A commit message that claims otherwise is wrong.
- Fix: add a test row to an ESLint config test whenever you add a pattern.
- `no-restricted-globals` never sees an imported `fetch` binding. So `expo/fetch` has to be banned by name in the import rule. A deep import that re-exports `fetch` from outside the fenced directory stays open.

## The oracle test pattern
- A config test spawns the real `eslint` with `--stdin --stdin-filename <virtual path> --format json`.
- The virtual path decides which config blocks apply, so one test can probe any zone without a real file.
- Put the test outside the fenced source directories. A network-name fence would otherwise ban the names the test must write.
- A nested `jest` spawn in such a file set `JEST_WORKER_ID: undefined` in its env. The reason was not recorded.
