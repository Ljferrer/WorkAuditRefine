---
name: shell-test-suite-must-sanitize-ambient-env-var-convention-before-fixture-cases
description: "Shell tests of an env-var-triggered code path must unset that var before pre-existing fixture cases — an ambient developer/CI export silently activates it"
metadata:
  node_type: memory
  type: project
  provenance: agent-unverified
  keywords:
    - ambient env var
    - test hermeticity
    - env var convention
    - shell test sanitation
    - fixture leakage
    - unset before cases
    - test isolation
  slug: shell-test-suite-must-sanitize-ambient-env-var-convention-before-fixture-cases
  tags:
    - shell
    - testing
    - hermeticity
    - pattern
---

**Pattern:** A script that reads an env var as an implicit config channel, with no CLI flag and "if set, behavior changes", creates a hazard for its own test suite. If any other doc or playbook in the same repo teaches an operator to `export` that same var, a developer's ambient shell, or a CI job that sources such a playbook, silently arms the new code path inside test cases that were never designed to exercise it. Those cases read as false failures, or worse false passes, with no code change.

**Fix:** the test file must `unset <VAR>` immediately after any environment guard (for example right after confirming the script under test exists) and before the first fixture case runs. Never rely on the ambient shell being clean. If any pre-existing case builds fixtures that assert success or failure contingent on the var being absent or empty, name that dependency in a comment in the test file. Deleting the `unset` line is otherwise invisible in CI, which never carries the ambient export, and only reproduces in a developer shell that followed the export-teaching playbook.

**When to apply:** any shell test suite whose script under test reads an env var by convention rather than an explicit flag, where a different doc teaches operators to export that same var name for a legitimate workflow.
