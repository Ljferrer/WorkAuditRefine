---
name: lambda-layer-wheels-built-native-to-arm-synth-host
description: "Lambda layers bundled with a native pip on an arm64 build host ship aarch64 wheels to x86_64 Lambdas; cross-install for the declared architecture"
metadata:
  node_type: memory
  type: project
  keywords:
    - lambda layer
    - pydantic_core
    - aarch64
    - arm64 CodeBuild
    - pip --platform
    - only-binary
    - wheel platform tag
    - Runtime.ImportModuleError
    - CDK bundling
  provenance: code-verified
  slug: lambda-layer-wheels-built-native-to-arm-synth-host
  tags:
    - cdk
    - lambda-layers
    - pipeline
    - build-architecture
---

A CDK synth project ran on an arm64 CodeBuild image (`LinuxArmBuildImage`). The shared `create_layer` helper ran a native `pip install` inside the bundling container, so every layer with a compiled dependency shipped aarch64 wheels while it declared `x86_64`. The first x86_64 zip Lambda to attach such a layer failed at module load: `No module named 'pydantic_core._pydantic_core'`. A numpy layer carried an aarch64 build the same way.

Fix: `create_layer` now cross-installs with `pip install --platform <manylinux tag for arch> --python-version <runtime> --implementation cp --only-binary=:all:`, keyed off the layer's declared architecture.

**Why:** the bundling container runs native to the build host, and no synth test can see a wheel's platform tag. Layers with only pure-Python deps (boto3, Faker) never showed it.

**How to apply:** When a layer with a compiled dependency is first attached to a zip Lambda, add a canary that invokes the function once in a dev stage. A synth test proves the attachment, never the wheel. With `--only-binary=:all:`, a pinned dependency that has no wheel for the target (e.g. an old `faiss-cpu` on cp312) fails the bundle loudly instead of building for the wrong host.
